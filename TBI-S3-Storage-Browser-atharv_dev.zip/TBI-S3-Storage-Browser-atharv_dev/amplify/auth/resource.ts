import { defineAuth, secret } from '@aws-amplify/backend';

/**
 * Define and configure your auth resource
 * @see https://docs.amplify.aws/gen2/build-a-backend/auth
 */
export const auth = defineAuth({
  loginWith: {
    email: true,
    externalProviders: {
      oidc: [
        {
          name: 'PROVIDER-AZUREAD',
          clientId: secret('API_CLIENT_ID'),
          clientSecret: secret('API_CLIENT_SECRET'),
          issuerUrl: 'https://login.microsoftonline.com/6cb1dbc6-7381-40a3-891c-4c5ed7c80ff9/v2.0',
        },
      ],
      logoutUrls: ['http://localhost:5173/', 'https://main.d1dgn0zrt9tb32.amplifyapp.com'],
      callbackUrls: [
        'http://localhost:5173/personal',
        'https://main.d1dgn0zrt9tb32.amplifyapp.com',
      ],
    },
  },
  groups: ['DEM-Agent']
});
