import { apiClient } from "./client";

export const FileViewDownloadAPI = {
    getSignedUrl(key: string[], mode: 'view' | 'download', owner_id?: string) {
    return apiClient
      .post('/signedUrl', { key, mode, owner_id })
      .then(res => res.data.url);
  }
}

