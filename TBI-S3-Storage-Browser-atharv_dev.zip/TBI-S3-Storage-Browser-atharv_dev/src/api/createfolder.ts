import { AxiosResponse } from "axios";
import { apiClient } from "./client";


interface CreateFolderPayload {
    parent_path: string,
    folder_name: string,
    user_name: string,
    user_role: string,
    email: string
}

export const CreateFolderAPI = {
    createFolder(payload: CreateFolderPayload): Promise<AxiosResponse> {
        return apiClient.post('/create-folder',  payload ).then(res => res)
    } 
}



