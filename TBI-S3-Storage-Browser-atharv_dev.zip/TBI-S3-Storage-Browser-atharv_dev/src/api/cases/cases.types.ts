export type EvidenceFileCategory =
  | 'phone_extraction'
  | 'digital_forensics_work_file'
  | 'digital_forensics_work_product'
  | 'other';

/**
 * ✅ NEW: unified processing status type (safe addition)
 */
export type ProcessingStatus =
  | 'NOT_REQUESTED'
  | 'IN_PROGRESS'
  | 'COMPLETED'
  | 'FAILED';

export interface Case {
  user_name: string;
  case_number: string;
  source_key: string;
  case_title: string;
  case_agents: string;
  jurisdiction: string[];
  shared_to: SharedTo[];
  email: string;
  size: number;
  updated_at: string;
  division: string;
  unit: string;
  squad?: string;
  created_by_role: string;
  created_at: string;
  created_by: string;
}

export interface DeleteEvidencePayload {
  objectKeys: string[];
}

export interface SharedTo {
  email: string;
  permissions: Permissions;
  shared_at: string;
  user_id: string;
}

export interface Permissions {
  read: boolean;
  write: boolean;
}

export interface CreateCasePayload {
  user_name: string;
  email: string;
  case_number: string;
  case_title: string;
  case_agents: string;
  jurisdiction: string;
  source_key: string;
  division: string;
  unit: string;
  squad?: string;
}

export interface CasePermissions {
  read: boolean;
  write: boolean;
}

export interface ReceivedCase {
  userId: string;
  count: number;
  cases: ShareCaseToPayload[];
}

export interface ShareCaseToPayload {
  receiver_user_id: string;
  case_number: string;
  gsi1pk: string;
  gsi1sk: string;
  owner_user: string;
  receiver_user: string;
  receiver_email: string;
  case_title: string;
  jurisdiction?: string[];
  case_agents?: string;
  size?: number;
  source_key: string;
  owner_email?: string;
  division?: string;
  unit?: string;
  squad?: string;
  permissions: CasePermissions;
  shared_at: string;
  updated_at?: string;
  shared_by: string;
  shared_by_role: string;
  shared_by_email: string;
}

export interface ReceiveCasePayload {
  user_name: string;
}

/**
 * ============================================================
 * ✅ NEW: Versioning types (SAFE additions, no breaking changes)
 * ============================================================
 */

/** One transcription attempt/version info (stored under transcribe_versions.v1/v2/...) */
export interface TranscribeVersionInfo {
  status?: ProcessingStatus;
  jobName?: string;
  jsonKey?: string; // output bucket key (derived/...)
  txtKey?: string;  // output bucket key (derived/...)
  pdfKey?: string;  // amplify bucket key (private/..._v1_transcript.pdf)
  startedAt?: number;
  completedAt?: string;
  detectedLanguageCodes?: string[];
  error?: string;
}

/** Map: { v1: {...}, v2: {...} } */
export type TranscribeVersionsMap = Record<string, TranscribeVersionInfo>;

/** One translation version info (stored per language under translate.<lang>.versions.v1/v2/...) */
export interface TranslateVersionInfo {
  status?: ProcessingStatus;
  txtKey?: string; // output bucket key (derived/...)
  pdfKey?: string; // amplify bucket key (private/..._en_v1_translate.pdf)
  completedAt?: string;
  sourceType?: 'TRANSCRIBE' | 'TEXTRACT';
  sourceFileNamePath?: string;
  sourceTranscriptVersion?: number | null;
  error?: string;
}

/** Per language node: translate.en.latest_version, translate.en.versions */
export interface TranslateLanguageNode {
  latest_version?: number;
  versions?: Record<string, TranslateVersionInfo>;
}

/** Map of language -> node (en/es/ar/...) */
export type TranslateMap = Record<string, TranslateLanguageNode>;

/**
 * ============================================================
 * ✅ Your OLD EvidenceItem (KEEP EXACTLY, only ADD OPTIONAL fields)
 * ============================================================
 * This is used by /cases/{caseNumber}/evidence (old API flow).
 * We keep evidence_number/source_key/uploaded_at required to avoid conflicts.
 */
export interface EvidenceItem {
  PK?: string;
  SK?: string;

  case_number?: string;
  evidence_number: string;
  evidence_type?: string;
  file_category: EvidenceFileCategory;
  description: string;
  source_key: string;
  uploaded_at: string;
  uploaded_by?: string;
  content_type?: string;

  // Existing pipeline fields (kept)
  transcribeStatus?: ProcessingStatus;
  translateStatus?: ProcessingStatus;
  translationPdfKeyEn?: string;
  translateError?: string;
  shared_case_numbers?: string[];

  /**
   * ✅ NEW OPTIONAL fields (won't break old code)
   * Used by the new two-button + versioning approach.
   */
  file_id?: string;

  transcribe_latest_version?: number;
  transcribeJobName?: string;
  transcribeJsonKey?: string;
  transcribeMode?: string;
  languageOptions?: string[];
  detectedLanguageCodes?: string[];
  transcribeError?: string;
  transcribeStartError?: any;
  transcribe_versions?: TranscribeVersionsMap;

  translateTarget?: string;
  translationTextKeyEn?: string;

  // new structure that stores translations for many languages
  translate?: TranslateMap;
}

/**
 * ============================================================
 * ✅ NEW: EvidenceIndexItem (your new table: case_number + file_name_path)
 * ============================================================
 * This matches the attributes you posted for TBI_Dems_EvidenceIndex:
 * case_number (PK), file_name_path (SK), s3_key, name, size, user_id...
 * Used by useEvidence(currentPath) hook. 
 */
export interface EvidenceIndexItem {
  case_number: string;           // PK
  file_name_path: string;        // SK (PARENT#.../#NODE#...)
  s3_key: string;                // amplify private key
  name: string;                  // filename
  type: string;                  // FILE/FOLDER
  size?: number | string;

  description?: string;
  email?: string;
  user_id?: string;
  user_name?: string;
  user_role?: string | null;

  created_at?: string;
  last_modified?: string;
  modified_by?: string;
  modified_by_email?: string;

  // optional legacy evidence number if still present
  evidence_number?: string;

  // ✅ Two-button pipeline status fields (optional)
  file_id?: string;

  transcribeStatus?: ProcessingStatus;
  transcribe_latest_version?: number;
  transcribe_versions?: TranscribeVersionsMap;
  detectedLanguageCodes?: string[];

  translateStatus?: ProcessingStatus;
  translateTarget?: string;
  translateError?: string;
  translate?: TranslateMap;
}

export interface EvidenceListResponse {
  items: EvidenceItem[];
  nextCursor?: string | null;
}

export interface EvidenceCreatePayload {
  source_key: string;
  evidence_number?: string;
  evidence_type?: string;
  user_id: string,
  file_category?: EvidenceFileCategory;
  description?: string;
  uploaded_at?: string;
  shared_case_numbers?: string[];
}

export type ShareExternalPayload = {
  case_number: string;
  file: string;
  email: string;
  wrapped_url: string;
  case_title?: string;
  case_agents?: string;
  jurisdiction?: string[];
  owner: string;
  owner_email?: string;
  division?: string;
  unit?: string;
  squad?: string;
  permissions: {
    read: boolean;
    write: boolean;
  };
  shared_at: string;
};

export interface OrgMetricsQuery {
  division?: string;
  unit?: string;
  squad?: string;
  user_id?: string;
}

export interface OrgUnitConfig {
  squads: string[];
}

export interface OrgDivisionConfig {
  units: Record<string, OrgUnitConfig>;
}

export interface OrgConfig {
  divisions: string[];
  org_structure: Record<string, OrgDivisionConfig>;
  file_categories: string[];
}