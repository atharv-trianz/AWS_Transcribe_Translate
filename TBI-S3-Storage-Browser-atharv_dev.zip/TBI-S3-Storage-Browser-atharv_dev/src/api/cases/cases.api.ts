import { apiClient } from "../client";
import {
  Case,
  CreateCasePayload,
  EvidenceListResponse,
  EvidenceCreatePayload,
  ShareCaseToPayload,
  ShareExternalPayload,
  ReceivedCase,
  OrgMetricsQuery,
  OrgConfig,
} from "./cases.types";

export const CasesAPI = {
  getAll(user_id?: string): Promise<Case[]> {
    return apiClient.get('/cases', {params: user_id ? { user_id } : undefined,}).then(res => res.data);
  },

  createCase(payload: CreateCasePayload): Promise<Case> {
    return apiClient.put("/cases", payload).then((res) => res.data);
  },

  shareCaseTo(payload: ShareCaseToPayload[]): Promise<void> {
    return apiClient.post("/share-case-to", payload).then((res) => res.data);
  },

  shareExternal(payload: ShareExternalPayload): Promise<void> {
    return apiClient.post("/share-external", payload).then((res) => res.data);
  },

  getReceivedCaseByUser(userId: string): Promise<ReceivedCase> {
    return apiClient
      .get("/get-received-case", { params: { user_id: userId } })
      .then((res) => res.data);
  },

  getConfig(): Promise<OrgConfig> {
    return apiClient.get("/cases/config").then((res) => res.data);
  },

  getCaseEvidence(caseNumber: string, cursor?: string): Promise<EvidenceListResponse> {
    const params = cursor ? { cursor } : {};
    return apiClient
      .get(`/cases/${caseNumber}/evidence`, { params })
      .then((res) => res.data);
  },

  createEvidence(caseNumber: string, payload?: EvidenceCreatePayload): Promise<void> {
    return apiClient
      .post(`/cases/${caseNumber}/evidence`, { payload })
      .then((res) => res.data);
  },

  deleteEvidence(caseNumber: string, objectKeys: string[]): Promise<void> {
    return apiClient
      .delete(`/cases/${caseNumber}/evidence`, { data: { objectKeys } })
      .then((res) => res.data);
  },

 
  /**
   * Start or Retry Transcription for an AUDIO/VIDEO file.
   * Backend expects file_name_path (DDB sort key) and optional force flag.
   *
   * Route: POST /cases/{caseNumber}/evidence/transcribe
   */
  
startTranscribe(
    caseNumber: string,
    fileNamePath: string,
    force: boolean = false,
    enhanced: boolean = false
  ): Promise<any> {
    return apiClient
      .post(`/cases/${caseNumber}/evidence/transcribe`, {
        file_name_path: fileNamePath,
        force,
        enhanced,
      })
    .then((res) => res.data);
  },

  startTranslate(
    caseNumber: string,
    fileNamePath: string,
    targetLang: string,
    force: boolean = false
  ): Promise<any> {
    return apiClient
      .post(`/cases/${caseNumber}/evidence/translate`, {
        file_name_path: fileNamePath,
        targetLang,
        force,
      })
      .then((res) => res.data);
  },


  getOrgMetrics(query: OrgMetricsQuery): Promise<unknown> {
    return apiClient
      .get("/cases/metrics/org", { params: query })
      .then((res) => res.data);
  },

  linkEvidenceToCases(
    sourceCaseNumber: string,
    evidenceNumber: string,
    targetCaseNumbers: string[]
  ): Promise<void> {
    return apiClient
      .post(`/cases/${sourceCaseNumber}/evidence/${evidenceNumber}/link`, {
        target_case_numbers: targetCaseNumbers,
      })
      .then((res) => res.data);
  },

  getLinkedCasesForEvidence(caseNumber: string, evidenceNumber: string): Promise<string[]> {
    return apiClient
      .get(`/cases/${caseNumber}/evidence/${evidenceNumber}/links`)
      .then((res) => res.data);
  },
};