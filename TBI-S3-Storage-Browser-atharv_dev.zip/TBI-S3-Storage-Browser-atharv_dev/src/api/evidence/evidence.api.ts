import { apiClient } from "../client";

export interface Evidence {
    case_number: string,
    created_at: string,
    description: string;
    email: string,
    evidence_number: string;
    file_name_path: string,
    last_modified: string;
    modified_by: string;
    modified_by_email: string;
    name: string;
    size: string;
    type: string,
    user_id: string,
    user_name: string,
    user_role: string,
    s3_key: string,
    is_deleted?: boolean,
    deleted_at?: string,
    is_restored?: boolean,
}

interface UpdateEvidence {
    case_number: string,
    path: string,
    evidence_number: string,
    description?: string
}
export interface RestoreResult {
    message: string;
    restored: string[];
    not_restorable: { item: string; reason: string }[];
    failed: { item: string; reason: string }[];
}

export const EvidenceAPI = {
    getEvidence(path: string): Promise<Evidence[]> {
        return apiClient.get('/evidence', {params: {
            path: path
        }}).then(res => res.data)
    },
    updateEvidenceMetadata(payload: UpdateEvidence){
        return apiClient.patch('/evidence', payload)
    },
    softDelete(items: { case_number: string; file_name_path: string }[]): Promise<void> {
        return apiClient.patch('/evidence/soft-delete', { items }).then(res => res.data)
    },
    restore(items: { case_number: string; file_name_path: string }[]): Promise<RestoreResult> {
        return apiClient.patch('/evidence/restore', { items }).then(res => res.data)
    },
    getDeletedEvidence(): Promise<Evidence[]> {
        return apiClient.get('/evidence/recycle-bin').then(res => res.data)
    }
}


