export interface User {
    name: string,
    email: string,
    user_role: string,
    user_name: string
}

