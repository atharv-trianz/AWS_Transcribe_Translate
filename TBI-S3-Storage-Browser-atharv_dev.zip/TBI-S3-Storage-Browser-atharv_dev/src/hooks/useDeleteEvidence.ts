import { useMutation, useQueryClient } from '@tanstack/react-query';
import { EvidenceAPI } from '../api/evidence/evidence.api';

export function useDeleteEvidence() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      items,
    }: {
      items: { case_number: string; file_name_path: string }[];
    }) => EvidenceAPI.softDelete(items),

    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['evidence'] });
      queryClient.invalidateQueries({ queryKey: ['recycle-bin'] });
    },
  });
}

export function useRestoreEvidence() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      items,
    }: {
      items: { case_number: string; file_name_path: string }[];
    }) => EvidenceAPI.restore(items),

    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['evidence'] });
      queryClient.invalidateQueries({ queryKey: ['recycle-bin'] });
    },
  });
}
