import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { CasesAPI } from '../api/cases/cases.api';
import type {
  Case,
  CreateCasePayload,
  ShareCaseToPayload,
  ShareExternalPayload,
  OrgMetricsQuery,
  EvidenceCreatePayload,
  OrgConfig,
} from '../api/cases/cases.types';
import { fetchAuthSession } from 'aws-amplify/auth';
import toast from 'react-hot-toast';
import { AxiosError } from 'axios';

export function useCases(user_id?: string) {
  return useQuery<Case[]>({
    queryKey: ['cases', user_id],
    queryFn: () => CasesAPI.getAll(user_id),
  });
}

export function useReceivedCases(userId: string) {
  return useQuery({
    queryKey: ['received-cases'],
    queryFn: () => CasesAPI.getReceivedCaseByUser(userId),
  });
}

export function useCreateCase() {
  const queryClient = useQueryClient();
  return useMutation<Case, AxiosError<{ message: string }>, CreateCasePayload>({
    mutationFn: CasesAPI.createCase,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cases'] });
    },
    onError: (err) => {
      if (err.status === 409) {
        toast.error(err.response?.data?.message ?? 'Case already exists');
      } else {
        toast.error('Something went wrong');
      }
    },
  });
}

export function useShareCaseTo() {
  const queryClient = useQueryClient();
  return useMutation<void, Error, ShareCaseToPayload[]>({
    mutationFn: CasesAPI.shareCaseTo,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cases'] });
    },
  });
}

export function useShareExternal() {
  const API_BASE = import.meta.env.VITE_API_BASE_URL;

  return useMutation({
    mutationFn: async (payload: ShareExternalPayload) => {
      const session = await fetchAuthSession();
      const token = session.tokens?.idToken?.toString();

      const res = await fetch(`${API_BASE}/share-external`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        throw new Error(`Failed to share: ${res.status}`);
      }

      return res.json();
    },
  });
}

export function useOrgConfig() {
  return useQuery<OrgConfig>({
    queryKey: ['org-config'],
    queryFn: CasesAPI.getConfig,
    staleTime: 1000 * 60 * 10,
    retry: 2,
  });
}

export function useOrgMetrics(query: OrgMetricsQuery, enabled = true) {
  return useQuery({
    queryKey: ['org-metrics', query],
    queryFn: () => CasesAPI.getOrgMetrics(query),
    enabled,
  });
}

export function useLinkEvidenceToCases() {
  const queryClient = useQueryClient();
  return useMutation<
    void,
    AxiosError<{ message: string }>,
    { sourceCaseNumber: string; evidenceNumber: string; targetCaseNumbers: string[] }
  >({
    mutationFn: ({ sourceCaseNumber, evidenceNumber, targetCaseNumbers }) =>
      CasesAPI.linkEvidenceToCases(sourceCaseNumber, evidenceNumber, targetCaseNumbers),
    onSuccess: (_, { sourceCaseNumber }) => {
      queryClient.invalidateQueries({ queryKey: ['evidence', sourceCaseNumber] });
    },
    onError: () => {
      toast.error('Failed to link evidence to cases');
    },
  });
}

export function useLinkedCasesForEvidence(
  caseNumber: string,
  evidenceNumber: string,
  enabled = true
) {
  return useQuery<string[]>({
    queryKey: ['evidence-links', caseNumber, evidenceNumber],
    queryFn: () => CasesAPI.getLinkedCasesForEvidence(caseNumber, evidenceNumber),
    enabled: enabled && !!caseNumber && !!evidenceNumber,
  });
}

export function useCreateEvidence(caseNumber: string) {
  const queryClient = useQueryClient();
  return useMutation<void, AxiosError<{ message: string }>, EvidenceCreatePayload>({
    mutationFn: (payload) => CasesAPI.createEvidence(caseNumber, payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['evidence', caseNumber] });
    },
    onError: () => {
      toast.error('Failed to create evidence record');
    },
  });
}
