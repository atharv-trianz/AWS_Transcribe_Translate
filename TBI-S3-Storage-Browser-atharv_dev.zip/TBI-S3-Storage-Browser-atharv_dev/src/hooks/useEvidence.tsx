import { useQuery } from '@tanstack/react-query';

import { EvidenceAPI } from '../api/evidence/evidence.api';

interface Evidence {
    case_number: string,
    created_at: string,
    description: string;
    email: string,
    evidence_number: string;
    file_name_path: string,
    last_modified: string;
    modified_by: string;
    name: string;
    size: string;
    type: string,
    user_id: string,
    user_name: string,
    user_role: string,
}

export function useEvidence(path: string) {
  return useQuery<Evidence[]>({
    queryKey: ['evidence', path],
    queryFn: () => EvidenceAPI.getEvidence(path),
    enabled: !!path,
    refetchOnMount: 'always',
    refetchOnWindowFocus: false,
  });
}

