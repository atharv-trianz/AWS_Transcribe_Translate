import { useMutation, useQueryClient } from "@tanstack/react-query";
import { CreateFolderAPI } from "../api/createfolder";
import toast from "react-hot-toast";
export function useCreateFolder(){
    const queryClient = useQueryClient();
    return useMutation({
        mutationFn: CreateFolderAPI.createFolder,
        onSuccess: () => {
            queryClient.invalidateQueries({
                queryKey: ["evidence"],
            });
        },
        onError: (error) => {
            toast.error(error.message)
        }
    })
}