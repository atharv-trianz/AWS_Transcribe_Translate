import '@aws-amplify/ui-react-storage/styles.css';
import './App.css';
import config from '../amplify_outputs.json';
import {Amplify} from 'aws-amplify';
// import Auth from 'aws-amplify'
import {
  Authenticator,
  TextField,
  useAuthenticator,
} from '@aws-amplify/ui-react';
import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
  useNavigate,
  useLocation,
} from 'react-router-dom';
import { UserContext } from './context/UserContext';
import { Toaster } from 'react-hot-toast';
import { MyStorageBrowser } from './components/MyStorageBrowser';
import { SecureSharePage } from './components/secureSharePage';
import { ExternalLoginPage } from './components/ExternalLoginPage';
import { useEffect, useMemo, useState } from 'react';
import React from 'react';
import { fetchAuthSession } from "aws-amplify/auth";


Amplify.configure(config);
import { ReactNode } from "react";
import { AccessResolver } from './components/utils/AccessResolver';
import Navbar from './components/navbar/navbar'
import { UploadProvider } from './context/UploadContext';

import { signInWithRedirect } from 'aws-amplify/auth';

/* -----------------------------------------
   Auth Guard for External Users (Session Token Based)
------------------------------------------ */
function RequireExternalAuth({ children }: { children: ReactNode}) {
  const navigate = useNavigate();
  const location = useLocation();
  const [isChecking, setIsChecking] = React.useState(true);
  const [isAuthenticated, setIsAuthenticated] = React.useState(false);

  


  useEffect(() => {
    // Auth.federatedSignIn()
    
    // signInWithRedirect({
    //   provider: { custom: 'AzureAD' } // must match the IdP name you configured in your user pool
    // });

    const checkAuth = () => {
      try {
        const token = localStorage.getItem('external_access_token');
        const expiry = localStorage.getItem('external_token_expiry');
        
        if (!token || !expiry) {
          throw new Error('No session');
        }
        
        // Check if token expired
        if (Date.now() > parseInt(expiry)) {
          // Clear expired session
          localStorage.removeItem('external_access_token');
          localStorage.removeItem('external_token_expiry');
          localStorage.removeItem('external_user_email');
          throw new Error('Session expired');
        }
        
        setIsAuthenticated(true);
      } catch {
        const fullUrl = location.pathname + location.search;
      navigate(
        `/external-login?redirect=${encodeURIComponent(fullUrl)}`,
        { replace: true }
      );

      } finally {
        setIsChecking(false);
      }
    };

    checkAuth();
  }, [navigate, location]);

  if (isChecking) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <div>Loading...</div>
      </div>
    );
  }

  return isAuthenticated ? children : null;
}

/* -----------------------------------------
   Auth Guard
------------------------------------------ */
function RequireAuth({ children }: { children: ReactNode }) {
  const { authStatus } = useAuthenticator((context) => [context.authStatus]);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (authStatus === 'unauthenticated') {
      // If trying to access secure-view, redirect to external login
      const isSecureView = location.pathname === '/secure-view';
      const loginPath = isSecureView ? '/external-login' : '/login';
      
      navigate(loginPath, {
        state: {
          from: location.pathname + location.search, // preserve full URL
        },
        replace: true,
      });
    }
  }, [authStatus, navigate, location]);
  if (authStatus === 'unauthenticated') {
    return (
      <Navigate
        to="/login"
        state={{ from: location.pathname + location.search }}
        replace
      />
    );
  }

  if (authStatus !== 'authenticated') {
    return null; // still loading
  }

  return children;
}

/* -----------------------------------------
   Login Page
------------------------------------------ */
function LoginPage() {
  const { authStatus } = useAuthenticator((context) => [context.authStatus]);
  const navigate = useNavigate();
  const location = useLocation();


  
  const errorDescription = useMemo(() => {
    const params = new URLSearchParams(location.search);
    const rawFromQuery = params.get("error_description");

    if (rawFromQuery) {
      return decodeURIComponent(rawFromQuery.replace(/\+/g, " "));
    }

    const fromUrl =
      typeof (location.state as any)?.from === "string"
        ? (location.state as any).from
        : null;

    if (fromUrl && fromUrl.includes("?")) {
      const qs = fromUrl.split("?")[1];
      const fallbackParams = new URLSearchParams(qs);
      const raw = fallbackParams.get("error_description");
      return raw ? decodeURIComponent(raw.replace(/\+/g, " ")) : null;
    }

    return null;
  }, [location]);

  
  // const fromUrl =
  //   typeof (location.state as any)?.from === "string"
  //     ? (location.state as any).from
  //     : null;

      
  // let errorDescription: string | null = null;

  // if (fromUrl && fromUrl.includes("?")) {
  //   const queryString = fromUrl.split("?")[1];
  //   const params = new URLSearchParams(queryString);

  //   const raw = params.get("error_description");
  //   errorDescription = raw
  //     ? decodeURIComponent(raw.replace(/\+/g, " "))
  //     : null;
  // }
  const FRIENDLY_AUTH_ERRORS: Record<string, string> = {
    "Please register using username/password before logging in with SSO.":
      "Your account is not registered yet. Please sign up using email and password first, then use SSO next time.",
  };

  const friendlyMessage =
    (errorDescription && FRIENDLY_AUTH_ERRORS[errorDescription]) ||
    errorDescription;

    
useEffect(() => {
    if (friendlyMessage && location.search) {
      window.history.replaceState({}, document.title, "/login");
    }
  }, [friendlyMessage, location.search]);


  const [loading, setLoading] = useState(false)
  const loginWithAzure = () => {
    setLoading(true)
    signInWithRedirect({
      provider: { custom: import.meta.env.VITE_DEMS_AZURE_AD_NAME } 
    });
  }  
  useEffect(() => {
    if (authStatus === 'authenticated') {
      const from = (location.state as any)?.from || '/personal';
      navigate(from, { replace: true });
    }
  }, [authStatus, navigate, location]);

  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
        background: '#f5f5f5',
      }}
    >
      <Authenticator components={{
          SignUp: {
            FormFields() {
              return (
                
                <>
                  <Authenticator.SignUp.FormFields />
                  <TextField
                    name="given_name"
                    label="First name"
                    required
                  />
                  <TextField
                    name="family_name"
                    label="Last name"
                    required
                  />
                </>

              )
            }
          },
          SignIn: {
          
          Header() {
            return friendlyMessage ? (
              <div
                style={{
                  background: "#fff4e5",
                  color: "#663c00",
                  padding: "12px",
                  borderRadius: 8,
                  marginBottom: 12,
                  fontSize: 14,
                  textAlign: "center",
                  border: "1px solid #ffd8a8",
                }}
              >
                <strong>SSO login blocked</strong>
                <div style={{ marginTop: 6 }}>
                  {friendlyMessage}
                </div>
              </div>
            ) : null;
          },

          Footer() {
            return (
              <div style={{textAlign: 'center', marginTop: 10}}>
                <h4 style={{marginTop:1}}>OR</h4>
                <button
                  type='button'
                  disabled={loading}
                  onClick={loginWithAzure}
                  style={{
                    padding: '10px 20px',
                    cursor: 'pointer',
                    width: '100%',
                    color: 'white',
                    backgroundColor: 'hsl(190, 95%, 30%)',
                    border: 'none',
                    borderRadius: 4,
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "hsl(190, 100%, 15%)")}
                  onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "hsl(190, 95%, 30%)")}
                >
                  {loading ? "Redirecting to Microsoft...": "Login with SSO"}
                </button>
              </div>
            )
          }
          }
      }}
      />
    </div>
  );
}


const asString = (v: unknown): string => {
  if (typeof v === 'string') return v;
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  return ''; // for objects/arrays/undefined
};

const asStringArray = (v: unknown): string[] => {
  if (Array.isArray(v)) return v.map(asString).filter(Boolean);
  // if (typeof v === 'string') return [v];
  
  if (typeof v === 'string') {
      const trimmed = v.trim();

      // handle JSON string array: '["DEM-Administrator"]'
      if (trimmed.startsWith('[')) {
        try {
          const parsed = JSON.parse(trimmed);
          if (Array.isArray(parsed)) {
            return parsed.map(asString).filter(Boolean);
          }
        } catch {
          // fall through if JSON.parse fails
        }
      }

      return [v];
    }

  return [];
};


type UserInfo = {
  email: string;
  user_name: string;
  user_id: string;
  cognitoUsername: string;
  cognitoGroups: string[];
  customRoles: string[];
};


const hasFederatedIdentities = (identities: unknown): boolean => {
  if (Array.isArray(identities)) return identities.length > 0;
  if (typeof identities === 'string') {
    try {
      const parsed = JSON.parse(identities);
      return Array.isArray(parsed) && parsed.length > 0;
    } catch {
      return false;
    }
  }
  return false;
};
  
async function getUserFromToken(): Promise<UserInfo> {
  const session = await fetchAuthSession();
  const payload = session.tokens?.idToken?.payload ?? {};

  const identities = (payload as any).identities;
  const isFederated = hasFederatedIdentities(identities);

  const email = asString((payload as any).email);

  const given = asString((payload as any).given_name);
  const family = asString((payload as any).family_name);
  const fullName = `${given} ${family}`.trim();

  const displayName =
    asString((payload as any).name) ||
    asString((payload as any).preferred_username) ||
    fullName ||
    email;

  
  const cognitoGroups = asStringArray((payload as any)['cognito:groups']);
  const customRolesRaw = asStringArray((payload as any)['custom:roles']);

  const effectiveRoles = customRolesRaw.length > 0 ? customRolesRaw : cognitoGroups;


  return {
    email,
    user_name: isFederated ? displayName : (fullName || email),
    user_id: asString((payload as any).sub),
    cognitoUsername: asString((payload as any)['cognito:username']),
    cognitoGroups,
    customRoles:effectiveRoles
  };
}
/* -----------------------------------------
   Authenticated App Area
------------------------------------------ */
function AuthenticatedApp() {
  const { signOut } = useAuthenticator((context) => [context.user]);
  
const [userInfo, setUserInfo] = useState<UserInfo>({
    email: '',
    user_name: '',
    user_id: '',
    cognitoUsername: '',
    cognitoGroups: [],
    customRoles: []
  });

  // const email =
  //   user?.signInDetails?.loginId || user?.userId || '';
  // const user_name = user?.userId ?? '';

  // getUserFromToken()

  useEffect(() => {
    getUserFromToken().then(res => setUserInfo(res))
  },[])
  console.log('userIfo: ', userInfo)
  return (
    <UserContext.Provider value={{ userInfo, signOut }}>
      <UploadProvider>
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              borderRadius: "12px",
              background: "#252222",
              color: "#fff",
              padding: "16px",
            },
          }}
        />
        <Navbar/>
        <Routes>
          {/* Prevent logged-in users from visiting login */}
          <Route path="/login" element={<Navigate to="/personal" replace />} />

          {/* Default route */}
          <Route path="/" element={<Navigate to="/personal" replace />} />

          {/* 🔓 Secure share route (NOT wrapped in RequireAuth) */}
          <Route path="/secure-view" element={<SecureSharePage />} />
          <Route
            path="/access/:caseId"
            element={
              <RequireAuth>
                <AccessResolver />
              </RequireAuth>
            }
          />

          {/* Protected pages */}
          <Route
            path="/personal"
            element={
              <RequireAuth>
                <MyStorageBrowser />
              </RequireAuth>
            }
          />
        <Route
          path="/temp"
          element={
            <RequireAuth>
              <MyStorageBrowser />
            </RequireAuth>
          }
        />

          <Route
            path="/shared"
            element={
              <RequireAuth>
                <MyStorageBrowser />
              </RequireAuth>
            }
          />

          <Route
            path="/received"
            element={
              <RequireAuth>
                <MyStorageBrowser />
              </RequireAuth>
            }
          />

          <Route
            path="/admin"
            element={
              <RequireAuth>
                <MyStorageBrowser />
              </RequireAuth>
            }
          />
          <Route
            path="/admin-cases-control"
            element={
              <RequireAuth>
                <MyStorageBrowser />
              </RequireAuth>
            }
          />

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/personal" replace />} />
        </Routes>
      </UploadProvider>
    </UserContext.Provider>
  );
}

/* -----------------------------------------
   Root App
------------------------------------------ */
function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Routes OUTSIDE Authenticator.Provider (no Cognito UI) - MUST come FIRST */}
        <Route path="/external-login" element={<ExternalLoginPage />} />
        
        {/* Secure share route - uses external auth (OTP) - MUST come BEFORE wildcard */}
        <Route 
          path="/secure-view" 
          element={
            <RequireExternalAuth>
              <SecureSharePage />
            </RequireExternalAuth>
          } 
        />
        
        {/* Routes INSIDE Authenticator.Provider (Cognito auth) */}
        <Route path="/login" element={
          <Authenticator.Provider>
            <LoginPage />
          </Authenticator.Provider>
        } />
        
        {/* All internal routes go through AuthenticatedApp which has nested Routes */}
        <Route path="/*" element={
          <Authenticator.Provider>
            <AuthenticatedApp />
          </Authenticator.Provider>
        } />
      </Routes>
    </BrowserRouter>
  );
}

export default App;