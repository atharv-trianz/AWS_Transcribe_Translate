import { Box, Button, IconButton, LinearProgress, Popover, Stack, Tooltip, Typography } from '@mui/material'
import { useUploadManager } from '../../context/UploadContext';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { Pause, PlayArrow} from '@mui/icons-material';
import CloseSharpIcon from '@mui/icons-material/CloseSharp';


type Props = {
    anchorEl: HTMLElement | null,
    handleUploadClose: () => void
}

export default function UploadPopover({anchorEl, handleUploadClose}: Props) {
    const { uploads } = useUploadManager();
    const isCheckDownloadStatusOpen = Boolean(anchorEl)
  return uploads.length > 0 ? (
    <Popover
          id={'id'}
          open={isCheckDownloadStatusOpen}
          anchorEl={anchorEl}
          onClose={handleUploadClose}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'center',
          }}
        >
          {/* <Typography sx={{ p: 2 }}>The content of the Popover.</Typography> */}
          <Box sx={{maxWidth: 450, minWidth: 400, maxHeight: 600, p: 0.5}}>
            {[...uploads].slice().reverse().map(upload => (
                        
              <Box 
                key={upload.id}
                sx={{
                  p: 1, m: 1, borderRadius: 1,
                  backgroundColor: "#f1e8e867",
                  // boxShadow: '0 2px 10px rgba(0,0,0,0)',
                  transition: 'all 0.2s ease',
                  "&:hover": {
                    // boxShadow: "0 4px 18px rgba(0,0,0,0)",
                    backgroundColor: '#948a8a1f'
                  }
                }} 
              >
                
                <Box 
                  sx={{
                    display: 'flex', justifyContent: 'space-between', 
                  }}
                >
                  <Box sx={{flex: 1, minWidth: 0}}>
                  <Typography 
                    sx={{
                      fontWeight: 500, 
                      mb: 1, whiteSpace: 'wrap', 
                      overflow: 'hidden', 
                      textOverflow: 'ellipsis',
                    }}
                  >
                    {upload.file.name}
                  </Typography>
                  </Box>
                  <Box >
                    
                    {upload.status !== 'completed' && upload.status !== 'error' && (upload.isPaused ? (  
                    // { upload.status !== 'error' && (upload.isPaused ? (  
                      <Tooltip title='start'>
                        <IconButton onClick={upload.controller.resume}>
                          <PlayArrow />
                        </IconButton>
                      </Tooltip>
                    ) : (
                      <Tooltip title='pause'>
                        <IconButton onClick={upload.controller.pause}>
                          <Pause />
                        </IconButton>
                      </Tooltip>
                    ))}
                    <Tooltip title={upload.status !== 'completed'?'cancel upload': 'remove'}>
                      <IconButton>
                        <CloseSharpIcon onClick={
                          () => {
                            console.log('cancel clicked')
                            upload.controller.cancel()
                            
                          }
                          // console.log('clicked')
                          // upload.controller.cancel()
                          }/>
                      </IconButton>
                    </Tooltip>
                  </Box>
                </Box>
    
                <Box flex={1} sx={{display: 'flex', flexDirection: 'column'}}>
                {<LinearProgress
                  color={upload.status === 'completed'?'success': 'primary'}
                  variant="determinate"
                  value={upload.status === 'completed' ? 100: upload.progress}
                  sx={{
                    height: 4,
                    borderRadius: 20,
                    
                  }}
                />}
    
                <Stack sx={{display: 'flex', justifyContent: 'space-between'}} direction="row">
                  <Box>
                  {upload.status !== 'completed' && (<Typography  fontSize={16} variant="caption">
                      {/* {isPaused ? "Paused" : `${progress}% uploaded`} */}
                      {upload.isPaused || upload.status === 'error'
                        ? "paused"
                        : `${upload.progress}% uploaded`}
                    </Typography>)}
                  
    
                  {upload.status === 'completed' && (
                    <Box sx={{ display: 'flex', alignContent: 'center', marginTop: 1}}>
                      Upload Successful
                      <CheckCircleIcon style={{color: 'green'}} /> 
                    </Box>
                  )}
                  </Box>
                  <Box>
                  {upload.status !== 'completed' && upload.status === "error" && (
                    <Button
                      size='small'
                      variant='outlined'
                      color='error'
                    onClick={upload.controller.retry}>
                      Retry
                    </Button>
                  )}
                  {/* {upload.status !== 'completed' && upload.status !== 'error' && (upload.isPaused ? (  
                    <IconButton onClick={upload.controller.resume}>
                      <PlayArrow />
                    </IconButton>
                  ) : (
                    <IconButton onClick={upload.controller.pause}>
                      <Pause />
                    </IconButton>
                  ))} */}
                  </Box>
                </Stack>
                {/* <Box sx={{display: 'flex', flexDirection: 'row', backgroundColor: 'green'}}> */}
                <Tooltip title='destination path'>
                  <Typography 
                    sx={{
                      fontFamily: 'monospace', 
                      color: 'text.secondary',
                      letterSpacing: '0.5px', 
                      // opacity: 0.65, 
                      fontSize: 12,
                      
                      alignSelf: 'flex-end'
                    }}>
                    {upload.prefix.split('/').splice(2).join('/')}
                  </Typography>
                </Tooltip>
                {/* </Box> */}
                </Box>
                {/* <Divider/> */}
              </Box>
              
              
            ))}
    
          </Box>
        </Popover>
  ) : <Popover
        id={'id'}
        open={isCheckDownloadStatusOpen}
        anchorEl={anchorEl}
        onClose={handleUploadClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'center',
        }}
        sx={{display: 'flex'}}
      >
        <Box sx={{minWidth: 400, maxHeight: 600, p: 1}}>
          <Typography
          variant='caption'
            sx={{
                    
              fontSize: 15,
              justifyContent: 'center',
              alignItems: 'center',
              alignContent: 'center',
            }}
          >
            There is no upload in progress
          </Typography>
        </Box>
      </Popover>
}
