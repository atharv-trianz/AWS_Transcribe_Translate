import { useEffect, useState, useRef } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import {
  ChevronRight, ChevronDown, Folder, FileText, Image, Film, Music,
  FileCode, Download, HardDrive, FileCheck, CheckSquare, Square,
  Briefcase, Users, MapPin, Shield, Clock, Archive, Eye,
  Table, FileType, File,
} from "lucide-react";
import * as XLSX from "xlsx";
import * as mammoth from "mammoth";
import { Case } from "../api/cases/cases.types";
import logo from "../assets/logo.png";

type FileItem = { name: string; key: string; size: number; lastModified: string | null; type: "file" | "folder"; s3_key?: string; folder?: string };

const theme = {
  pageBg:"#f4f6fa",surfaceBg:"#ffffff",sidebarBg:"#ffffff",casePanelBg:"#fffbeb",
  evidenceCardBg:"rgba(22,163,74,0.04)",border:"#e5e7eb",borderStrong:"#d1d5db",
  evidenceBorder:"rgba(22,163,74,0.2)",textPrimary:"#111827",textSecondary:"#374151",
  textMuted:"#6b7280",textTiny:"#9ca3af",textEvidence:"#166534",textMeta:"#374151",
  gold:"#b45309",goldBg:"rgba(180,83,9,0.08)",goldBorder:"rgba(180,83,9,0.2)",
  green:"#16a34a",chevron:"#9ca3af",fileInactive:"#6b7280",fileActiveText:"#b45309",
  fileActiveBg:"rgba(180,83,9,0.07)",fileActiveBorder:"#b45309",folderName:"#374151",
  checkInactive:"#d1d5db",topBarBorder:"#e5e7eb",divider:"#e5e7eb",metaKey:"#9ca3af",
  caseLabelColor:"#92400e",caseKeyColor:"#b45309",caseValColor:"#374151",
  evidenceLabelColor:"#166534",evidenceKeyColor:"rgba(22,163,74,0.7)",
  spinnerColor:"#b45309",emptyIconColor:"#d1d5db",emptyTextColor:"#9ca3af",
  overlayBg:"#f4f6fa",overlayCardBg:"#ffffff",overlayTitle:"#111827",overlayMsg:"#6b7280",
  overlayIconBg:"rgba(180,83,9,0.08)",scrollThumb:"rgba(107,114,128,0.3)",
  scrollThumbHover:"rgba(107,114,128,0.5)",btnPrimaryBg:"#b45309",btnPrimaryText:"#ffffff",
  btnSecBg:"rgba(180,83,9,0.06)",btnSecText:"#b45309",btnSecBorder:"rgba(180,83,9,0.2)",
  previewCaption:"#9ca3af",
};
type Theme = typeof theme;

const Spinner = ({ size=24, color="#c8a96e" }:{size?:number;color?:string}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={{animation:"spin 0.9s linear infinite"}}>
    <circle cx="12" cy="12" r="10" stroke={color} strokeOpacity="0.25" strokeWidth="2.5"/>
    <path d="M12 2a10 10 0 0 1 10 10" stroke={color} strokeWidth="2.5" strokeLinecap="round"/>
  </svg>
);

const getFileIcon = (fileName:string, size=15, color="#6b7a99") => {
  const lower = fileName.toLowerCase();
  if (lower.match(/\.(jpg|jpeg|png|gif|webp|svg|bmp|tiff?|heic|raw|cr2|nef|arw)$/)) return <Image size={size} color={color}/>;
  if (lower.match(/\.(mp4|webm|ogg|avi|mov|mkv|flv|wmv|m4v|3gp|ts|mts|m2ts|divx|xvid|rmvb|vob|mpg|mpeg)$/)) return <Film size={size} color={color}/>;
  if (lower.match(/\.(mp3|wav|aac|flac|m4a|ogg|opus|wma|amr|aiff?|ape|wv|mka)$/)) return <Music size={size} color={color}/>;
  if (lower.match(/\.(xlsx?|xls|xlsm|xlsb|ods|csv)$/)) return <Table size={size} color={color}/>;
  if (lower.match(/\.(docx?|doc|odt|rtf)$/)) return <FileType size={size} color={color}/>;
  if (lower.match(/\.(txt|log|md|nfo|ini|cfg|conf|env|yaml|yml|toml)$/)) return <FileText size={size} color={color}/>;
  if (lower.match(/\.(pdf|json|xml|html|css|js|ts|tsx|jsx|py|sh|bat|sql)$/)) return <FileCode size={size} color={color}/>;
  return <File size={size} color={color}/>;
};

const formatFileSize = (bytes:number):string => {
  if (bytes===0) return "0 B";
  const k=1024, sizes=["B","KB","MB","GB"];
  const i=Math.floor(Math.log(bytes)/Math.log(k));
  return (bytes/Math.pow(k,i)).toFixed(2)+" "+sizes[i];
};

const formatDate = (d:string):string => new Date(d).toLocaleDateString("en-US",{year:"numeric",month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"});

const OverlayScreen = ({icon,title,message,action,t}:{icon:React.ReactNode;title:string;message:string;action?:React.ReactNode;t:Theme}) => (
  <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:"100vh",width:"100vw",margin:0,padding:0,backgroundColor:t.overlayBg,fontFamily:"'DM Sans',system-ui,sans-serif"}}>
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:"1.25rem",padding:"3rem 2.5rem",backgroundColor:t.overlayCardBg,border:`1px solid ${t.borderStrong}`,borderRadius:"14px",maxWidth:"420px",textAlign:"center"}}>
      <div style={{width:80,height:80,display:"flex",alignItems:"center",justifyContent:"center",borderRadius:"50%",backgroundColor:t.overlayIconBg}}>{icon}</div>
      <h2 style={{margin:0,fontSize:"1.35rem",fontWeight:700,color:t.overlayTitle}}>{title}</h2>
      <p style={{margin:0,fontSize:"0.88rem",color:t.overlayMsg,lineHeight:"1.6"}}>{message}</p>
      {action}
    </div>
  </div>
);

const FileRow = ({file,isActive,isChecked,hasEvidence,onSelect,onToggle,t}:{file:FileItem;isActive:boolean;isChecked:boolean;hasEvidence:boolean;onSelect:()=>void;onToggle:()=>void;t:Theme}) => (
  <div style={{display:"flex",alignItems:"center",gap:"0.25rem",backgroundColor:isActive?t.fileActiveBg:"transparent",borderLeft:`2px solid ${isActive?t.fileActiveBorder:"transparent"}`,paddingRight:"0.5rem"}}>
    <button onClick={(e)=>{e.stopPropagation();onToggle();}} style={{background:"none",border:"none",cursor:"pointer",padding:"0.35rem",display:"flex",alignItems:"center",flexShrink:0}}>
      {isChecked?<CheckSquare size={15} color={t.gold}/>:<Square size={15} color={t.checkInactive}/>}
    </button>
    <button onClick={onSelect} style={{display:"flex",alignItems:"center",gap:"0.45rem",flex:1,background:"none",border:"none",cursor:"pointer",padding:"0.45rem 0.5rem",textAlign:"left",fontFamily:"inherit",minWidth:0}}>
      {getFileIcon(file.name,14,isActive?t.fileActiveText:t.fileInactive)}
      <span style={{fontSize:"0.82rem",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",flex:1,color:isActive?t.fileActiveText:t.fileInactive}}>{file.name}</span>
      {hasEvidence&&<FileCheck size={11} color={t.green} style={{flexShrink:0}}/>}
    </button>
  </div>
);

const InfoRow = ({label,value,t}:{label:React.ReactNode;value:string;t:Theme}) => (
  <div style={{display:"flex",flexDirection:"column",gap:"0.15rem",padding:"0.5rem 1rem"}}>
    <span style={{fontSize:"0.62rem",fontWeight:700,letterSpacing:"0.08em",textTransform:"uppercase" as const,color:t.evidenceKeyColor}}>{label}</span>
    <span style={{fontSize:"0.82rem",color:t.textEvidence,lineHeight:"1.4"}}>{value}</span>
  </div>
);

const buildGlobalStyles = (t:Theme) => `
  @import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700&display=swap');
  html,body,#root{margin:0;padding:0;height:100%;width:100%;background-color:${t.pageBg};color:${t.textPrimary};}
  @keyframes spin{to{transform:rotate(360deg);}}
  *{box-sizing:border-box;}button{transition:opacity 0.15s;}button:hover{opacity:0.82;}
  ::-webkit-scrollbar{width:5px;height:5px;}::-webkit-scrollbar-track{background:transparent;}
  ::-webkit-scrollbar-thumb{background:${t.scrollThumb};border-radius:10px;}
  ::-webkit-scrollbar-thumb:hover{background:${t.scrollThumbHover};}
`;

export const SecureSharePage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const t = theme;

  const [selectedFile, setSelectedFile] = useState<FileItem|null>(null);
  const [selectedFiles, setSelectedFiles] = useState<Set<string>>(new Set());
  const [previewUrl, setPreviewUrl] = useState<string|null>(null);
  const [loading, setLoading] = useState(true);
  const [downloadingCurrent, setDownloadingCurrent] = useState(false);
  const [downloadingSelected, setDownloadingSelected] = useState(false);
  const [downloadingFolder, setDownloadingFolder] = useState(false);
  const [isExpired, setIsExpired] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAccessDenied, setIsAccessDenied] = useState(false);
  const [isAccessChecking, setIsAccessChecking] = useState(true);
  const [caseMetadata, setCaseMetadata] = useState<Case|null>(null);
  const [evidenceMetadata, setEvidenceMetadata] = useState<Map<string,any>>(new Map());
  const warningShownRef = useRef(false);

  const prefix = searchParams.get("prefix");
  const API_BASE = import.meta.env.VITE_API_BASE_URL;
  const folderName = prefix?.split("/").filter(Boolean).pop()||"Shared Folder";

  useEffect(()=>{setIsExpired(false);setPreviewUrl(null);warningShownRef.current=false;},[prefix]);

  useEffect(()=>{
    const interval = setInterval(()=>{
      const expiry = localStorage.getItem("external_token_expiry");
      if (!expiry) return;
      const timeLeft = parseInt(expiry)-Date.now();
      if (timeLeft<=5000&&timeLeft>0&&!warningShownRef.current){warningShownRef.current=true;toast.error(`Session expiring in ${Math.ceil(timeLeft/1000)}s`,{duration:5000});}
      if (timeLeft<=0){["external_access_token","external_token_expiry","external_user_email"].forEach(k=>localStorage.removeItem(k));setIsExpired(true);}
    },500);
    return ()=>clearInterval(interval);
  },[navigate]);

  useEffect(()=>{
    const token=localStorage.getItem("external_access_token");
    const expiry=localStorage.getItem("external_token_expiry");
    if (!token||!expiry||Date.now()>parseInt(expiry)){
      ["external_access_token","external_token_expiry","external_user_email"].forEach(k=>localStorage.removeItem(k));
      navigate("/external-login",{state:{from:window.location.pathname+window.location.search},replace:true});
    } else { setIsAuthenticated(true); }
  },[navigate]);

  useEffect(()=>{
    const validate=async()=>{
      if (!isAuthenticated||!prefix) return;
      try{
        setIsAccessChecking(true);
        const token=localStorage.getItem("external_access_token");
        const res=await fetch(`${API_BASE}/external-share-info?prefix=${encodeURIComponent(prefix)}`,{headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"}});
        if (res.status===403){
          const d=await res.json();
          ["external_access_token","external_token_expiry","external_user_email"].forEach(k=>localStorage.removeItem(k));
          if ((d.error||d.message||"").toLowerCase().includes("expired")){setIsExpired(true);}
          else {setIsAccessDenied(true);}
          return;
        }
        if (!res.ok) throw new Error("Access denied");
        setIsAccessDenied(false);
      } catch {
        ["external_access_token","external_token_expiry","external_user_email"].forEach(k=>localStorage.removeItem(k));
        setIsAccessDenied(true);
      } finally { setIsAccessChecking(false); }
    };
    validate();
  },[isAuthenticated,prefix]);

  const extractCaseNumber=(p:string|null)=>p?.match(/(\d{4}-\d{7})/)?.[1]||p?.split("/").filter(Boolean).find(x=>/^\d{4}-\d{7}$/.test(x))||null;
  const caseNumber=extractCaseNumber(prefix);

  useEffect(()=>{
    const fetch_=async()=>{
      if (!caseNumber||!isAuthenticated||!prefix) return;
      const token=localStorage.getItem("external_access_token");
      if (!token) return;
      try{
        const res=await fetch(`${API_BASE}/external-share-info?prefix=${encodeURIComponent(prefix)}`,{headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"}});
        if (res.ok){
          const d=await res.json();
          setCaseMetadata({
            case_number:d.case_number||caseNumber,case_title:d.case_title||"",
            case_agents:d.case_agents||"",jurisdiction:d.jurisdiction||[],
            email:d.owner_email||"",user_name:d.owner||"",updated_at:d.updated_at||"",
            source_key:d.file||"",size:0,shared_to:d.shared_to||[],
            division:d.division||"",unit:d.unit||"",squad:d.squad||"",
            created_by_role:d.created_by_role||"",created_at:d.created_at||"",created_by:d.created_by||"",
          });
        }
      } catch {}
    };
    fetch_();
  },[caseNumber,isAuthenticated,API_BASE,prefix]);

  // Tree state: path -> { items, loaded, expanded, loading }
  type TreeNode = { items: FileItem[]; loaded: boolean; expanded: boolean; loading: boolean };
  const [tree, setTree] = useState<Record<string, TreeNode>>({});

  const fetchPath = async (path: string): Promise<FileItem[]> => {
    const token = localStorage.getItem("external_access_token");
    const res = await fetch(
      `${API_BASE}/external-list-objects?prefix=${encodeURIComponent(path)}`,
      { headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" } }
    );
    if (res.status === 403) {
      const data = await res.json();
      if ((data.message || data.error || "").toLowerCase().includes("expired")) {
        setIsExpired(true);
      } else {
        setIsAccessDenied(true);
      }
      throw new Error("Access denied");
    }
    if (!res.ok) throw new Error("Failed");
    const data: any[] = await res.json();
    // Update evidence map with any new files
    setEvidenceMetadata(prev => {
      const next = new Map(prev);
      data.forEach((ev: any) => {
        if (ev.name && ev.type !== "FOLDER") next.set(ev.name, ev);
      });
      return next;
    });
    return data.map((ev: any) => ({
      name: ev.name,
      key: ev.s3_key || ev.file_name_path,
      s3_key: ev.s3_key || "",
      size: Number(ev.size) || 0,
      lastModified: ev.last_modified || ev.created_at || null,
      type: (ev.type === "FOLDER" || ev.type === "folder") ? "folder" : "file",
      folder: undefined,
    }));
  };

  useEffect(() => {
    const load = async () => {
      if (!isAuthenticated || !prefix) return;
      try {
        setLoading(true);
        const items = await fetchPath(prefix);
        setTree({ [prefix]: { items, loaded: true, expanded: true, loading: false } });
        const firstFile = items.find(f => f.type === "file");
        if (firstFile) setSelectedFile(firstFile);
      } catch (err) { console.error(err); }
      finally { setLoading(false); }
    };
    load();
  }, [isAuthenticated, prefix, API_BASE]);

  const toggleFolder = async (folderPath: string) => {
    const node = tree[folderPath];
    if (node?.loaded) {
      // Just toggle expand/collapse
      setTree(prev => ({ ...prev, [folderPath]: { ...prev[folderPath], expanded: !prev[folderPath].expanded } }));
      return;
    }
    // Load on demand
    setTree(prev => ({
      ...prev,
      [folderPath]: { items: [], loaded: false, expanded: true, loading: true }
    }));
    try {
      const items = await fetchPath(folderPath);
      setTree(prev => ({ ...prev, [folderPath]: { items, loaded: true, expanded: true, loading: false } }));
    } catch {
      setTree(prev => ({ ...prev, [folderPath]: { items: [], loaded: true, expanded: false, loading: false } }));
      toast.error("Failed to load folder");
    }
  };

  const generatePreview=async(file:FileItem)=>{
    try{
      setPreviewUrl(null);
      const token=localStorage.getItem("external_access_token");
      const objectKey=file.s3_key||file.key;
      if (!objectKey) { toast.error("Cannot preview — missing file key."); return; }
      const res=await fetch(`${API_BASE}/objects/generate-link`,{method:"POST",headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"},body:JSON.stringify({mode:"sign-single",objectKey})});
      if (res.status===403){
        const d=await res.json();
        if ((d.message||d.error||"").toLowerCase().includes("expired")){setIsExpired(true);}
        else {setIsAccessDenied(true);}
        return;
      }
      if (!res.ok) throw new Error("Failed");
      setPreviewUrl((await res.json()).url);
    } catch{toast.error("Failed to generate preview.");}
  };

  useEffect(()=>{if(!selectedFile)return;setPreviewUrl(null);generatePreview(selectedFile);},[selectedFile?.key]);

  const downloadFromSignedUrl=async(url:string,name:string)=>{
    const blob=await(await fetch(url)).blob();
    const blobUrl=window.URL.createObjectURL(blob);
    const a=Object.assign(document.createElement("a"),{href:blobUrl,download:name});
    document.body.appendChild(a);a.click();document.body.removeChild(a);
    window.URL.revokeObjectURL(blobUrl);
  };

  const signedDownload=async(body:object,fileName:string,setLoad:(v:boolean)=>void)=>{
    setLoad(true);
    try{
      const token=localStorage.getItem("external_access_token");
      const res=await fetch(`${API_BASE}/objects/generate-link`,{method:"POST",headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"},body:JSON.stringify(body)});
      if (res.status===403){
        const d=await res.json();
        if ((d.message||d.error||"").toLowerCase().includes("expired")){setIsExpired(true);}
        else {setIsAccessDenied(true);}
        return;
      }
      if (!res.ok) throw new Error("failed");
      await downloadFromSignedUrl((await res.json()).url,fileName);
      toast.success("Download started");
    } catch{toast.error("Download failed");}
    finally{setLoad(false);}
  };

  const handleDownloadCurrent=()=>{
    if (!selectedFile) return;
    const objectKey=selectedFile.s3_key||selectedFile.key;
    signedDownload({mode:"sign-single",objectKey},selectedFile.name,setDownloadingCurrent);
  };

  const handleDownloadSelected=()=>{
    if (selectedFiles.size===0) return;
    const keys=Array.from(selectedFiles).map(name=>{
      const ev=evidenceMetadata.get(name);
      return ev?.s3_key||name;
    });
    signedDownload({objectKeys:keys},"selected_files.zip",setDownloadingSelected);
  };

  const handleDownloadFolder=()=>prefix&&signedDownload({folderPrefix:prefix},`${folderName}.zip`,setDownloadingFolder);

  const toggleFileSelection=(name:string)=>{
    setSelectedFiles(prev=>{const next=new Set(prev);next.has(name)?next.delete(name):next.add(name);return next;});
  };

  // Total file count across all loaded nodes
  const totalFileCount = Object.values(tree).reduce((sum, node) =>
    sum + node.items.filter(f => f.type === "file").length, 0
  );

  const cf:React.CSSProperties={display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:"1rem"};

  // ── Rich viewer state ──────────────────────────────────────────────────────
  const [xlsxData, setXlsxData]     = useState<{sheets:string[];active:string;html:Record<string,string>}|null>(null);
  const [docxHtml, setDocxHtml]     = useState<string|null>(null);
  const [txtContent, setTxtContent] = useState<string|null>(null);
  const [viewerLoading, setViewerLoading] = useState(false);

  // Reset rich viewers when file changes
  useEffect(()=>{ setXlsxData(null); setDocxHtml(null); setTxtContent(null); },[selectedFile?.key]);

  // Fetch & parse Excel / DOCX / TXT once previewUrl is ready
  useEffect(()=>{
    if (!previewUrl||!selectedFile) return;
    const fn=selectedFile.name.toLowerCase();
    const isXlsx = fn.match(/\.(xlsx?|xls|xlsm|xlsb|ods)$/);
    const isCsv  = fn.endsWith(".csv");
    const isDocx = fn.match(/\.(docx?|doc|odt|rtf)$/);
    const isTxt  = fn.match(/\.(txt|log|md|nfo|ini|cfg|conf|env|yaml|yml|toml|json|xml|sql|py|js|ts|tsx|jsx|css|html|sh|bat)$/);
    if (!isXlsx && !isCsv && !isDocx && !isTxt) return;

    let cancelled=false;
    const load=async()=>{
      setViewerLoading(true);
      try{
        const blob=await(await fetch(previewUrl)).blob();
        if (cancelled) return;

        if (isXlsx||isCsv){
          const ab=await blob.arrayBuffer();
          const wb=XLSX.read(ab,{type:"array"});
          const htmlMap:Record<string,string>={};
          wb.SheetNames.forEach(name=>{
            htmlMap[name]=XLSX.utils.sheet_to_html(wb.Sheets[name],{id:"xlsx-tbl",editable:false});
          });
          setXlsxData({sheets:wb.SheetNames,active:wb.SheetNames[0],html:htmlMap});
        } else if (isDocx){
          const ab=await blob.arrayBuffer();
          const result=await mammoth.convertToHtml({arrayBuffer:ab});
          setDocxHtml(result.value);
        } else if (isTxt){
          setTxtContent(await blob.text());
        }
      } catch(e){ console.error("Viewer parse error",e); }
      finally{ if(!cancelled) setViewerLoading(false); }
    };
    load();
    return ()=>{ cancelled=true; };
  },[previewUrl,selectedFile?.key]);

  const renderPreview=()=>{
    if (loading) return <div style={cf}><Spinner size={40} color={t.spinnerColor}/><p style={{margin:0,color:t.previewCaption,fontSize:"0.88rem"}}>Loading files…</p></div>;
    if (!selectedFile) return <div style={cf}><Eye size={56} color="#d1d5db"/><p style={{margin:0,color:t.previewCaption,fontSize:"0.88rem"}}>Select a file to preview</p></div>;
    if (!previewUrl) return <div style={cf}><Spinner size={40} color={t.spinnerColor}/><p style={{margin:0,color:t.previewCaption,fontSize:"0.88rem"}}>Generating secure preview…</p></div>;

    const fn=selectedFile.name.toLowerCase();

    // ── Images ──────────────────────────────────────────────────────────────
    if (fn.match(/\.(jpg|jpeg|png|gif|webp|svg|bmp|tiff?|heic)$/))
      return <div style={{padding:"1.5rem",display:"flex",alignItems:"center",justifyContent:"center",width:"100%",height:"100%"}}><img key={selectedFile.key} src={previewUrl} alt={selectedFile.name} style={{maxWidth:"100%",maxHeight:"100%",objectFit:"contain",borderRadius:6}}/></div>;

    // ── Video ───────────────────────────────────────────────────────────────
    if (fn.match(/\.(mp4|webm|ogg|mov|m4v|3gp|ts|mkv|avi|flv|wmv|divx|mpg|mpeg)$/))
      return (
        <div style={{padding:"1.5rem",display:"flex",alignItems:"center",justifyContent:"center",width:"100%",height:"100%"}}>
          <video key={selectedFile.key} controls style={{width:"100%",maxHeight:"100%",borderRadius:8,background:"#000"}}>
            <source src={previewUrl}/>
            Your browser does not support this video format.
          </video>
        </div>
      );

    // ── Audio ───────────────────────────────────────────────────────────────
    if (fn.match(/\.(mp3|wav|aac|flac|m4a|ogg|opus|wma|aiff?|wv|mka|amr)$/))
      return (
        <div style={{...cf,width:"100%",padding:"2.5rem 2rem"}}>
          <div style={{width:80,height:80,borderRadius:"50%",backgroundColor:t.goldBg,border:`1px solid ${t.goldBorder}`,display:"flex",alignItems:"center",justifyContent:"center",marginBottom:"0.5rem"}}>
            <Music size={36} color={t.gold}/>
          </div>
          <p style={{margin:"0 0 0.25rem",fontSize:"0.95rem",fontWeight:700,color:t.textPrimary,textAlign:"center",maxWidth:"100%",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{selectedFile.name}</p>
          <p style={{margin:"0 0 1.5rem",fontSize:"0.75rem",color:t.textMuted}}>{fn.split(".").pop()?.toUpperCase()} · {formatFileSize(selectedFile.size)}</p>
          <audio key={selectedFile.key} controls style={{width:"100%",maxWidth:"100%",minWidth:0}}>
            <source src={previewUrl}/>
            Your browser does not support this audio format.
          </audio>
        </div>
      );

    // ── PDF ─────────────────────────────────────────────────────────────────
    if (fn.endsWith(".pdf"))
      return <iframe key={selectedFile.key} src={previewUrl} style={{width:"100%",height:"100%",minHeight:580,border:"none",borderRadius:8}} title={selectedFile.name}/>;

    // ── Excel / CSV ─────────────────────────────────────────────────────────
    if (fn.match(/\.(xlsx?|xls|xlsm|xlsb|ods|csv)$/)){
      if (viewerLoading) return <div style={cf}><Spinner size={40} color={t.spinnerColor}/><p style={{margin:0,color:t.previewCaption,fontSize:"0.88rem"}}>Parsing spreadsheet…</p></div>;
      if (!xlsxData) return <div style={cf}><Table size={56} color="#d1d5db"/><p style={{margin:0,color:t.previewCaption,fontSize:"0.88rem"}}>Loading spreadsheet…</p></div>;
      return (
        <div style={{width:"100%",height:"100%",display:"flex",flexDirection:"column",position:"absolute",inset:0}}>
          {xlsxData.sheets.length>1&&(
            <div style={{display:"flex",gap:"0.25rem",padding:"0.5rem 0.75rem",borderBottom:`1px solid ${t.border}`,flexWrap:"wrap",flexShrink:0}}>
              {xlsxData.sheets.map(s=>(
                <button key={s} onClick={()=>setXlsxData(p=>p?{...p,active:s}:p)}
                  style={{padding:"0.25rem 0.75rem",fontSize:"0.75rem",fontWeight:600,fontFamily:"inherit",borderRadius:5,border:`1px solid ${s===xlsxData.active?t.gold:t.border}`,background:s===xlsxData.active?t.goldBg:"transparent",color:s===xlsxData.active?t.gold:t.textMuted,cursor:"pointer"}}>
                  {s}
                </button>
              ))}
            </div>
          )}
          <div style={{flex:1,overflow:"auto",padding:"0.5rem"}}
            dangerouslySetInnerHTML={{__html:`<style>
              #xlsx-tbl{border-collapse:collapse;width:100%;font-family:'DM Sans',system-ui,sans-serif;font-size:0.78rem;}
              #xlsx-tbl td,#xlsx-tbl th{border:1px solid ${t.border};padding:5px 10px;white-space:nowrap;color:${t.textPrimary};}
              #xlsx-tbl tr:first-child td,#xlsx-tbl th{background:${t.casePanelBg};font-weight:600;color:${t.textSecondary};}
              #xlsx-tbl tr:hover td{background:rgba(180,83,9,0.03);}
            </style>${xlsxData.html[xlsxData.active]||""}`}}
          />
        </div>
      );
    }

    // ── DOCX / DOC ──────────────────────────────────────────────────────────
    if (fn.match(/\.(docx?|doc|odt|rtf)$/)){
      if (viewerLoading) return <div style={cf}><Spinner size={40} color={t.spinnerColor}/><p style={{margin:0,color:t.previewCaption,fontSize:"0.88rem"}}>Parsing document…</p></div>;
      if (!docxHtml) return <div style={cf}><FileType size={56} color="#d1d5db"/><p style={{margin:0,color:t.previewCaption,fontSize:"0.88rem"}}>Loading document…</p></div>;
      return (
        <div style={{width:"100%",height:"100%",overflow:"auto",position:"absolute",inset:0}}>
          <div style={{maxWidth:820,margin:"0 auto",padding:"2rem 2.5rem",background:"#fff",fontFamily:"Georgia,serif",fontSize:"0.9rem",lineHeight:1.75,color:t.textPrimary}}
            dangerouslySetInnerHTML={{__html:`<style>
              .docx-wrap h1,.docx-wrap h2,.docx-wrap h3{font-family:'DM Sans',sans-serif;color:${t.textPrimary};margin:1.2em 0 0.4em;}
              .docx-wrap table{border-collapse:collapse;width:100%;margin:1em 0;}
              .docx-wrap td,.docx-wrap th{border:1px solid ${t.border};padding:6px 10px;font-size:0.85rem;}
              .docx-wrap p{margin:0.5em 0;}
            </style><div class="docx-wrap">${docxHtml}</div>`}}
          />
        </div>
      );
    }

    // ── Plain text / code / logs ─────────────────────────────────────────────
    if (fn.match(/\.(txt|log|md|nfo|ini|cfg|conf|env|yaml|yml|toml|json|xml|sql|py|js|ts|tsx|jsx|css|html|sh|bat)$/)){
      if (viewerLoading) return <div style={cf}><Spinner size={40} color={t.spinnerColor}/><p style={{margin:0,color:t.previewCaption,fontSize:"0.88rem"}}>Loading file…</p></div>;
      if (txtContent===null) return <div style={cf}><FileText size={56} color="#d1d5db"/><p style={{margin:0,color:t.previewCaption,fontSize:"0.88rem"}}>Loading…</p></div>;
      const isCode=fn.match(/\.(json|xml|sql|py|js|ts|tsx|jsx|css|html|sh|bat|yaml|yml|toml|ini|cfg|conf|env)$/);
      return (
        <div style={{width:"100%",height:"100%",overflow:"auto",position:"absolute",inset:0}}>
          <pre style={{margin:0,padding:"1.25rem 1.5rem",fontFamily:isCode?"'JetBrains Mono','Fira Code',monospace":"'DM Sans',system-ui,sans-serif",fontSize:isCode?"0.78rem":"0.88rem",lineHeight:1.7,color:t.textPrimary,background:isCode?"#f8f9fb":"#fff",whiteSpace:"pre-wrap",wordBreak:"break-word",minHeight:"100%",borderRadius:6}}>
            {txtContent}
          </pre>
        </div>
      );
    }

    // ── Unsupported — offer download ─────────────────────────────────────────
    return (
      <div style={cf}>
        <div style={{width:72,height:72,borderRadius:"50%",backgroundColor:"rgba(107,114,128,0.08)",display:"flex",alignItems:"center",justifyContent:"center"}}>
          <File size={32} color="#9ca3af"/>
        </div>
        <p style={{margin:"0 0 0.25rem",fontSize:"0.9rem",fontWeight:600,color:t.textSecondary}}>{selectedFile.name}</p>
        <p style={{margin:"0 0 1rem",fontSize:"0.78rem",color:t.textMuted}}>Preview not available for this file type</p>
        <button style={{display:"inline-flex",alignItems:"center",gap:"0.4rem",padding:"0.5rem 1.25rem",fontSize:"0.82rem",fontWeight:600,color:t.btnPrimaryText,backgroundColor:t.btnPrimaryBg,border:"none",borderRadius:6,cursor:"pointer",fontFamily:"inherit"}} onClick={handleDownloadCurrent}>
          <Download size={14}/> Download File
        </button>
      </div>
    );
  };

  // Recursive tree renderer
  const renderTree = (nodePath: string, depth: number = 0): React.ReactNode => {
    const node = tree[nodePath];
    if (!node) return null;
    const indent = depth * 14;
    return (
      <>
        {node.items.map(item => {
          if (item.type === "folder") {
            const folderPath = `${nodePath}${item.name}/`;
            const folderNode = tree[folderPath];
            const isExp = folderNode?.expanded ?? false;
            const isLoading = folderNode?.loading ?? false;
            return (
              <div key={folderPath}>
                <button
                  style={{display:"flex",alignItems:"center",gap:"0.45rem",padding:"0.45rem 1rem",paddingLeft:`${1 + indent/16}rem`,background:"none",border:"none",cursor:"pointer",width:"100%",fontFamily:"inherit"}}
                  onClick={() => toggleFolder(folderPath)}
                >
                  {isLoading
                    ? <Spinner size={13} color={t.chevron}/>
                    : isExp
                      ? <ChevronDown size={13} color={t.chevron}/>
                      : <ChevronRight size={13} color={t.chevron}/>
                  }
                  <Folder size={14} color={t.gold} style={{flexShrink:0}}/>
                  <span style={{fontSize:"0.82rem",fontWeight:600,color:t.folderName,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
                    {item.name}
                  </span>
                </button>
                {isExp && folderNode?.loaded && renderTree(folderPath, depth + 1)}
              </div>
            );
          }
          return (
            <div key={item.key} style={{paddingLeft:`${indent}px`}}>
              <FileRow
                file={item} t={t}
                isActive={selectedFile?.key === item.key}
                isChecked={selectedFiles.has(item.name)}
                hasEvidence={evidenceMetadata.has(item.name)}
                onSelect={() => setSelectedFile(item)}
                onToggle={() => toggleFileSelection(item.name)}
              />
            </div>
          );
        })}
      </>
    );
  };

  const currentEvidence=selectedFile?evidenceMetadata.get(selectedFile.name)??null:null;

  const btnPrimary:React.CSSProperties={display:"inline-flex",alignItems:"center",gap:"0.4rem",padding:"0.45rem 1rem",fontSize:"0.8rem",fontWeight:600,color:t.btnPrimaryText,backgroundColor:t.btnPrimaryBg,border:"none",borderRadius:"6px",cursor:"pointer",letterSpacing:"0.02em",fontFamily:"inherit"};
  const btnSecondary:React.CSSProperties={display:"inline-flex",alignItems:"center",gap:"0.4rem",padding:"0.45rem 1rem",fontSize:"0.8rem",fontWeight:600,color:t.btnSecText,backgroundColor:t.btnSecBg,border:`1px solid ${t.btnSecBorder}`,borderRadius:"6px",cursor:"pointer",letterSpacing:"0.02em",fontFamily:"inherit"};

  if (isAccessChecking) return <OverlayScreen t={t} icon={<Spinner size={48} color={t.spinnerColor}/>} title="Validating Access" message="Please wait while we verify your credentials…"/>;
  if (isAccessDenied) return <OverlayScreen t={t} icon={<img src={logo} alt="Logo" style={{height:70,objectFit:"contain"}}/>}title="Access Restricted" message="The link has either expired or you do not have permission to access this content. Please contact the file owner for a new link." action={<button style={btnPrimary} onClick={()=>navigate("/external-login")}>Return to Login</button>}/>;
  if (isExpired) return <OverlayScreen t={t} icon={<img src={logo} alt="Logo" style={{height:70,objectFit:"contain"}}/>} title="Access Restricted" message="The link has either expired or you do not have permission to access this content. Please contact the file owner for a new link." action={<button style={btnPrimary} onClick={()=>navigate("/external-login")}>Return to Login</button>}/>;
  if (!isAuthenticated) return <OverlayScreen t={t} icon={<Spinner size={48} color={t.spinnerColor}/>} title="" message=""/>;

  const rootNode = prefix ? tree[prefix] : null;

  return (
    <>
      <style>{buildGlobalStyles(t)}</style>
      <div style={{display:"flex",flexDirection:"column",height:"100vh",minHeight:"100vh",width:"100%",overflow:"hidden",backgroundColor:t.pageBg,fontFamily:"'DM Sans','IBM Plex Sans',system-ui,sans-serif",color:t.textPrimary}}>
        <header style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 1.5rem",height:"58px",borderBottom:`1px solid ${t.topBarBorder}`,backgroundColor:t.surfaceBg,flexShrink:0,gap:"1rem"}}>
          <div style={{display:"flex",alignItems:"center",gap:"0.875rem",overflow:"hidden"}}>
            <img src={logo} alt="Logo" title="TBI" style={{height:42,objectFit:"contain"}}/>
            <div style={{width:1,height:22,backgroundColor:t.divider,flexShrink:0}}/>
            <div style={{display:"flex",alignItems:"center",gap:"0.4rem",overflow:"hidden"}}>
              <Shield size={13} color={t.gold}/>
              <span style={{fontSize:"0.88rem",fontWeight:600,color:t.textSecondary,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{folderName}</span>
            </div>
            {/* {caseNumber&&<span style={{fontSize:"0.7rem",fontWeight:700,letterSpacing:"0.07em",color:t.gold,backgroundColor:t.goldBg,border:`1px solid ${t.goldBorder}`,borderRadius:"4px",padding:"2px 8px",flexShrink:0}}>{caseNumber}</span>} */}
          </div>
          <div style={{display:"flex",alignItems:"center",gap:"0.75rem",flexShrink:0}}>
            {selectedFiles.size>0&&<button style={btnSecondary} onClick={handleDownloadSelected} disabled={downloadingSelected}>{downloadingSelected?<Spinner size={14} color={t.gold}/>:<CheckSquare size={14} color={t.gold}/>}Download Selected ({selectedFiles.size})</button>}
            {totalFileCount>0&&<button style={btnPrimary} onClick={handleDownloadFolder} disabled={downloadingFolder}>{downloadingFolder?<Spinner size={14} color={t.btnPrimaryText}/>:<Archive size={14}/>}Download Case Folder</button>}
          </div>
        </header>

        <div style={{display:"flex",flex:1,overflow:"hidden"}}>
          <aside style={{width:"310px",flexShrink:0,display:"flex",flexDirection:"column",borderRight:`1px solid ${t.border}`,backgroundColor:t.sidebarBg,overflow:"auto"}}>
            {caseMetadata&&(
              <div style={{borderBottom:`1px solid ${t.border}`,padding:"1rem",backgroundColor:t.casePanelBg}}>
                <div style={{display:"flex",alignItems:"center",gap:"0.4rem",marginBottom:"0.875rem"}}>
                  <Briefcase size={13} color={t.gold}/>
                  <span style={{fontSize:"0.65rem",fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",color:t.caseLabelColor}}>Case Information</span>
                </div>
                <div style={{display:"flex",flexDirection:"column",gap:"0.5rem"}}>
                  {caseMetadata.case_title&&<div style={{display:"flex",gap:"0.5rem"}}><span style={{color:t.caseKeyColor,fontWeight:600,minWidth:"80px",fontSize:"0.72rem",letterSpacing:"0.02em",textTransform:"uppercase",flexShrink:0}}>Title</span><span style={{color:t.caseValColor,lineHeight:"1.4",fontSize:"0.82rem"}}>{caseMetadata.case_title}</span></div>}
                  {caseMetadata.jurisdiction&&<div style={{display:"flex",gap:"0.5rem"}}><span style={{display:"flex",alignItems:"center",color:t.caseKeyColor,fontWeight:600,minWidth:"80px",fontSize:"0.72rem",textTransform:"uppercase",flexShrink:0}}><MapPin size={10} style={{marginRight:3}}/>Jurisdiction</span><span style={{color:t.caseValColor,fontSize:"0.82rem"}}>{Array.isArray(caseMetadata.jurisdiction)?caseMetadata.jurisdiction.join(", "):caseMetadata.jurisdiction}</span></div>}
                  {caseMetadata.case_agents&&<div style={{display:"flex",gap:"0.5rem"}}><span style={{display:"flex",alignItems:"center",color:t.caseKeyColor,fontWeight:600,minWidth:"80px",fontSize:"0.72rem",textTransform:"uppercase",flexShrink:0}}><Users size={10} style={{marginRight:3}}/>Agents</span><span style={{color:t.caseValColor,fontSize:"0.82rem"}}>{caseMetadata.case_agents}</span></div>}
                  {caseMetadata.division&&<div style={{display:"flex",gap:"0.5rem"}}><span style={{color:t.caseKeyColor,fontWeight:600,minWidth:"80px",fontSize:"0.72rem",textTransform:"uppercase",flexShrink:0}}>Division</span><span style={{color:t.caseValColor,fontSize:"0.82rem"}}>{caseMetadata.division}</span></div>}
                  {caseMetadata.unit&&<div style={{display:"flex",gap:"0.5rem"}}><span style={{color:t.caseKeyColor,fontWeight:600,minWidth:"80px",fontSize:"0.72rem",textTransform:"uppercase",flexShrink:0}}>Unit</span><span style={{color:t.caseValColor,fontSize:"0.82rem"}}>{caseMetadata.unit}</span></div>}
                  {caseMetadata.squad&&<div style={{display:"flex",gap:"0.5rem"}}><span style={{color:t.caseKeyColor,fontWeight:600,minWidth:"80px",fontSize:"0.72rem",textTransform:"uppercase",flexShrink:0}}>Squad</span><span style={{color:t.caseValColor,fontSize:"0.82rem"}}>{caseMetadata.squad}</span></div>}
                </div>
              </div>
            )}
            <div style={{flex:1,display:"flex",flexDirection:"column"}}>
              <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"1rem 1rem 0.5rem"}}>
                <span style={{fontSize:"0.65rem",fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",color:t.gold}}>Files</span>
                <span style={{fontSize:"0.68rem",color:t.textTiny,fontWeight:600}}>{totalFileCount} items</span>
              </div>
              {loading
                ? <div style={{padding:"2rem",display:"flex",justifyContent:"center"}}><Spinner color={t.spinnerColor}/></div>
                : !rootNode?.loaded
                  ? <div style={{padding:"2rem",display:"flex",justifyContent:"center"}}><Spinner color={t.spinnerColor}/></div>
                  : rootNode.items.length === 0
                    ? <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:"0.75rem",padding:"3rem 1rem"}}><FileText size={36} color={t.emptyIconColor}/><p style={{color:t.emptyTextColor,fontSize:"0.82rem",margin:0}}>No files available</p></div>
                    : <div style={{padding:"0.5rem 0"}}>{prefix && renderTree(prefix)}</div>
              }
            </div>
          </aside>

          <main style={{flex:1,overflow:"hidden",padding:"1.5rem",display:"flex",flexDirection:"column",gap:"1.25rem",backgroundColor:t.pageBg}}>
            {selectedFile&&(
              <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",gap:"1rem",flexShrink:0}}>
                <div style={{display:"flex",alignItems:"center",gap:"0.6rem",overflow:"hidden"}}>
                  {getFileIcon(selectedFile.name,18,t.gold)}
                  <h2 style={{margin:0,fontSize:"1.05rem",fontWeight:700,color:t.textPrimary,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{selectedFile.name}</h2>
                </div>
                <button style={btnPrimary} onClick={handleDownloadCurrent} disabled={downloadingCurrent}>{downloadingCurrent?<Spinner size={14} color={t.btnPrimaryText}/>:<Download size={14}/>}Download</button>
              </div>
            )}
            <div style={{display:"flex",gap:"1.25rem",flex:1,alignItems:"stretch",overflow:"hidden",minHeight:0}}>
              <div style={{flex:1,backgroundColor:"#ffffff",border:`1px solid ${t.border}`,borderRadius:"10px",display:"flex",alignItems:"center",justifyContent:"center",overflow:"hidden",minHeight:0,position:"relative"}}>
                {renderPreview()}
              </div>
              {selectedFile&&(
                <div style={{width:"280px",flexShrink:0,display:"flex",flexDirection:"column",gap:"1rem"}}>
                  {currentEvidence&&(
                    <div style={{backgroundColor:t.evidenceCardBg,border:`1px solid ${t.evidenceBorder}`,borderRadius:"10px",overflow:"hidden"}}>
                      <div style={{display:"flex",alignItems:"center",gap:"0.5rem",padding:"0.75rem 1rem",borderBottom:`1px solid ${t.evidenceBorder}`}}>
                        <FileCheck size={14} color={t.green}/>
                        <span style={{fontSize:"0.65rem",fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",color:t.evidenceLabelColor}}>Evidence Record</span>
                      </div>
                      <div style={{display:"flex",flexDirection:"column",padding:"0.5rem 0"}}>
                        {currentEvidence.evidence_number&&<InfoRow t={t} label="Evidence No." value={currentEvidence.evidence_number}/>}
                        {currentEvidence.description&&<InfoRow t={t} label="Description" value={currentEvidence.description}/>}
                        {currentEvidence.user_name&&<InfoRow t={t} label="Uploaded By" value={currentEvidence.user_name}/>}
                        {currentEvidence.created_at&&<InfoRow t={t} label="Uploaded" value={formatDate(currentEvidence.created_at)}/>}
                        {currentEvidence.last_modified&&<InfoRow t={t} label="Last Modified" value={formatDate(currentEvidence.last_modified)}/>}
                        {currentEvidence.modified_by&&currentEvidence.modified_by!==currentEvidence.user_name&&<InfoRow t={t} label="Modified By" value={currentEvidence.modified_by}/>}
                      </div>
                    </div>
                  )}
                  <div style={{backgroundColor:t.evidenceCardBg,border:`1px solid ${t.evidenceBorder}`,borderRadius:"10px",overflow:"hidden"}}>
                    <div style={{display:"flex",alignItems:"center",gap:"0.5rem",padding:"0.75rem 1rem",borderBottom:`1px solid ${t.evidenceBorder}`}}>
                      <HardDrive size={14} color={t.green}/>
                      <span style={{fontSize:"0.65rem",fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",color:t.evidenceLabelColor}}>File Details</span>
                    </div>
                    <div style={{display:"flex",flexDirection:"column",padding:"0.5rem 0"}}>
                      <InfoRow t={t} label={<span style={{display:"inline-flex",alignItems:"center",gap:"0.4rem"}}><HardDrive size={13} color={t.metaKey}/><span>Size</span></span>} value={formatFileSize(selectedFile.size)}/>
                      <InfoRow t={t} label={<span style={{display:"inline-flex",alignItems:"center",gap:"0.4rem"}}>{getFileIcon(selectedFile.name,13,t.metaKey)}<span>Type</span></span>} value={selectedFile.name.split(".").pop()?.toUpperCase()||"—"}/>
                      {selectedFile.lastModified&&<InfoRow t={t} label={<span style={{display:"inline-flex",alignItems:"center",gap:"0.4rem"}}><Clock size={13} color={t.metaKey}/><span>Modified</span></span>} value={formatDate(selectedFile.lastModified)}/>}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </main>
        </div>
      </div>
    </>
  );
};