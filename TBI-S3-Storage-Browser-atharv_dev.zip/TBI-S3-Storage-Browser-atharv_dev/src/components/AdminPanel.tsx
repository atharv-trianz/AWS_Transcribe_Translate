import { useState, useEffect, useRef } from 'react';
import { Box, CircularProgress, Typography, Button } from '@mui/material';
import { createEmbeddingContext } from 'amazon-quicksight-embedding-sdk';
import { apiClient } from '../api/client';

export const ADMIN_GROUP_NAME = 'admin';

const fetchEmbedUrl = (): Promise<string> =>
  apiClient.get('/admin/embed-url').then(res => res.data.embed_url);

export const AdminPanel = () => {
  const [embedUrl, setEmbedUrl] = useState<string | null>(null);
  const [fetchError, setFetchError] = useState(false);
  const [iframeLoading, setIframeLoading] = useState(false);
  const [iframeError, setIframeError] = useState(false);

  const dashboardRef = useRef<HTMLDivElement | null>(null);

  const loadEmbedUrl = async () => {
    setFetchError(false);
    setEmbedUrl(null);
    setIframeLoading(false);
    setIframeError(false);
    try {
      const url = await fetchEmbedUrl();
      setEmbedUrl(url);
    } catch {
      setFetchError(true);
    }
  };

  useEffect(() => {
    loadEmbedUrl();
  }, []);

  useEffect(() => {
    if (!embedUrl || !dashboardRef.current) return;

    let active = true;

    const embed = async () => {
      try {
        setIframeLoading(true);
        const embeddingContext = await createEmbeddingContext();
        await embeddingContext.embedDashboard(
          {
            url: embedUrl,
            container: dashboardRef.current!,
            resizeHeightOnSizeChangedEvent: true,
          },
          {
            toolbarOptions: {
              export: true,
              undoRedo: true,
              reset: true,
            },
          }
        );
        if (active) setIframeLoading(false);
      } catch {
        if (active) {
          setIframeLoading(false);
          setIframeError(true);
        }
      }
    };

    embed();

    return () => {
      active = false;
      if (dashboardRef.current) {
        dashboardRef.current.innerHTML = '';
      }
    };
  }, [embedUrl]);

  if (!embedUrl && !fetchError) {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', gap: 2, p: 4 }}>
        <CircularProgress size={36} />
        <Typography variant="body2" color="text.secondary">
          Loading dashboard...
        </Typography>
      </Box>
    );
  }

  if (fetchError) {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', gap: 2, p: 4 }}>
        <Typography variant="body1" color="error" fontWeight={600}>
          Failed to load dashboard
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Could not retrieve the embed URL from the server.
        </Typography>
        <Button variant="outlined" onClick={loadEmbedUrl}>
          Retry
        </Button>
      </Box>
    );
  }

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%', p: 2 }}>
      <Typography variant="h6" fontWeight={600} mb={2}>
        Admin Dashboard
      </Typography>

      <Box
        sx={{
          position: 'relative',
          flex: 1,
          border: '1px solid',
          borderColor: 'divider',
          borderRadius: 2,
          overflow: 'auto',
          minHeight: 600,
        }}
      >
        {iframeLoading && !iframeError && (
          <Box
            sx={{
              position: 'absolute',
              inset: 0,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 2,
              background: '#fafafa',
              zIndex: 1,
            }}
          >
            <CircularProgress size={36} />
            <Typography variant="body2" color="text.secondary">
              Loading dashboard...
            </Typography>
          </Box>
        )}

        {iframeError && (
          <Box
            sx={{
              position: 'absolute',
              inset: 0,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 2,
              background: '#fafafa',
              zIndex: 1,
            }}
          >
            <Typography variant="body1" color="error" fontWeight={600}>
              Failed to render dashboard
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Please check that your domain is whitelisted in QuickSight.
            </Typography>
            <Button variant="outlined" onClick={loadEmbedUrl}>
              Retry
            </Button>
          </Box>
        )}

        <div
          ref={dashboardRef}
          style={{
            width: '100%',
            height: '100%',
            minHeight: 600,
            display: iframeError ? 'none' : 'block',
          }}
        />
      </Box>
    </Box>
  );
};