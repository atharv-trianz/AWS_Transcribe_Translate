import { useEffect, useState } from "react";
import { fetchAuthSession } from "aws-amplify/auth";
import { Tabs } from "@aws-amplify/ui-react";
import { Personal } from "./tabs/Personal";
import { Shared } from "./tabs/Shared";
import { AdminCasesControl } from './tabs/AdminCasesControl'
import Received from "./tabs/Received";
import  {Temp } from "./tabs/Temp";
import {AdminPanel} from "./AdminPanel";
import FullScreenLoader from "./utils/FullScreenLoader";
import { useLocation, useNavigate } from "react-router-dom";
import Box from "@mui/material/Box";

import { useUser } from "../context/UserContext";
// import ShieldIcon from '@mui/icons-material/Shield';
import AdminPanelSettingsIcon from '@mui/icons-material/AdminPanelSettings';
import { Typography } from "@mui/material";

export const MyStorageBrowser = () => {

  const location = useLocation();
  const navigate = useNavigate();
  const { userInfo } = useUser()

  const getTabFromPath = () => {
    if (location.pathname.includes("shared")) return "shared";
    if (location.pathname.includes("received")) return "received";
    if (location.pathname.includes("temp")) return "temp";
    if (location.pathname.includes("admin-cases-control")) return "admin-cases-control";

    if (location.pathname.includes("admin")) return "admin";

    return "private";
  };

  const [identityId, setIdentityId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState(getTabFromPath());

  useEffect(() => {
    if (location.pathname.includes("shared")) {
      setActiveTab("shared");
    } else if (location.pathname.includes("received")) {
      setActiveTab("received");
    } else if (location.pathname.includes("temp")) {
      setActiveTab("temp");
    }
    else if(location.pathname.includes("admin-cases-control")){
      setActiveTab("admin-cases-control")
    }
    else if (location.pathname.includes("admin")) {
      setActiveTab("admin");
    } 
    else {
      setActiveTab("private");
    }
  }, [location.pathname]);

  useEffect(() => {
    async function loadSession() {
      const session = await fetchAuthSession();
      setIdentityId(session.identityId ?? null);
    }
    loadSession();
  }, []);

  if (!identityId) {
    return <FullScreenLoader text="Loading..." />;
  }
  // console.log('user roleee: ', userInfo.customRoles)
  
const isAdmin = Array.isArray(userInfo?.customRoles) && userInfo.customRoles.includes("DEM-Administrator");

const tabs = [
  {
    label: "Personal",
    value: "private",
    content: <Personal />,
  },
  {
    label: "Shared",
    value: "shared",
    content: <Shared />,
  },
  {
    label: "Received",
    value: "received",
    content: <Received />,
  },
  {
    label: "Temp",
    value: "temp",
    content: <Temp />,
  },
  ...(isAdmin
    ? [
        {
          label: 
          (
            <Box
              sx={{
                
                display: "flex",
                alignItems: "center",
                gap: 1,
                color: "#334155",        
                fontWeight: 600,

              }}
            >
              <AdminPanelSettingsIcon fontSize="medium" />
              <Typography fontWeight={600}>Admin Dashboard</Typography>
            </Box>
          ),
          value: "admin",
          content: <AdminPanel />,
        },
        {
          label: 
          (
            <Box
              sx={{
                
                display: "flex",
                alignItems: "center",
                gap: 1,
                color: "#334155",        
                fontWeight: 600,

              }}
            >
              <AdminPanelSettingsIcon fontSize="medium" />
              <Typography fontWeight={600}>Admin Case Control</Typography>
            </Box>
          ),
          value: "admin-cases-control",
          content: <AdminCasesControl />,
        },
      ]
    : [])
   
    // {
    //   label: "Admin Case Control",
    //   value: "admin_cases_control",
    //   content: <AdminCasesControl/>
    // }
];

return (
    <>  

      <Box sx={{ mt: 3, px: 3 }}>
        <Tabs
          isLazy
          value={activeTab}
          onValueChange={(value) => {
            setActiveTab(value);
            navigate(`/${value}`);
          }}
          items={ tabs }
        />
      </Box>
    </>
  );
};
