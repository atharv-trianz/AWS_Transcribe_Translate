import { Button, Flex } from "@aws-amplify/ui-react";
import { useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Typography,
} from "@mui/material";
import { fetchAuthSession } from "aws-amplify/auth";
import { useUser } from "../../context/UserContext";
import { useQueryClient } from "@tanstack/react-query";
import { useDeleteEvidence } from "../../hooks/useDeleteEvidence";

type DeleteObjectsProps = {
  selectedPaths: string[];
  currentCaseNumber?: string | null;
  onDeleted: () => void;
  disabled?: boolean;
  selectedEvidenceItems?: { case_number: string; file_name_path: string }[];
};

export const DeleteObjects = ({
  selectedPaths,
  currentCaseNumber,
  onDeleted,
  disabled,
  selectedEvidenceItems,
}: DeleteObjectsProps) => {
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [errorOpen, setErrorOpen] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const { userInfo } = useUser();
  const queryClient = useQueryClient();
  const { mutateAsync: deleteEvidence } = useDeleteEvidence();
  const selectedFolders = selectedPaths.filter(p => p.endsWith('/'));
  const hasFolders = selectedFolders.length > 0;

  const deleteCase = async (paths: string[]) => {
    const session = await fetchAuthSession();
    const token = session.tokens?.idToken?.toString();
    const apiBaseUrl = import.meta.env.VITE_API_BASE_URL;

    const payload = {
      user_name: userInfo.user_id,
      selectedPaths: paths,
    };

    const res = await fetch(`${apiBaseUrl}/cases`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      throw new Error(`Case delete failed: ${res.status}`);
    }

    return await res.json();
  };

  const handleDeleteClick = () => {
    if (selectedPaths.length === 0) return;
    setConfirmOpen(true);
  };

  const performDelete = async () => {
    try {
      setIsDeleting(true);

      if (currentCaseNumber && selectedEvidenceItems && selectedEvidenceItems.length > 0) {
        await deleteEvidence({ items: selectedEvidenceItems });
        queryClient.invalidateQueries({ queryKey: ['evidence'] });
      } else if (!currentCaseNumber) {
        // Hard delete cases
        await deleteCase(selectedPaths);
        queryClient.invalidateQueries({ queryKey: ["cases"] });
      }

      onDeleted();
      setConfirmOpen(false);
    } catch (err) {
      console.error("Delete failed:", err);
      setErrorMsg("Failed to delete one or more items.");
      setErrorOpen(true);
    } finally {
      setIsDeleting(false);
      setConfirmOpen(false);
    }
  };
  // Build a context-aware confirmation message
  const confirmMessage = () => {
    const count = selectedPaths.length;
    if (hasFolders) {
      const fileCount = count - selectedFolders.length;
      const folderLabel = `${selectedFolders.length} folder${selectedFolders.length > 1 ? 's' : ''}`;
      const fileLabel = fileCount > 0 ? ` and ${fileCount} file${fileCount > 1 ? 's' : ''}` : '';
      return (
        <>
          <Typography gutterBottom>
            Move {folderLabel}{fileLabel} to the recycle bin?
          </Typography>
          <Typography variant="body2" color="error">
            ⚠️ All contents inside the selected folder{selectedFolders.length > 1 ? 's' : ''} will also be moved to the recycle bin.
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            Items are permanently deleted after 30 days.
          </Typography>
        </>
      );
    }
    return (
      <Typography>
        Move {count} item{count > 1 ? 's' : ''} to the recycle bin? Items will be permanently deleted after 30 days.
      </Typography>
    );
  };

  return (
    <>
      <Flex>
        <Button
          size="small"
          variation="destructive"
          isDisabled={disabled || selectedPaths.length === 0}
          onClick={handleDeleteClick}
        >
          Delete
        </Button>
      </Flex>

      {/* CONFIRM DIALOG */}
      <Dialog open={confirmOpen} onClose={() => setConfirmOpen(false)}>
        <DialogTitle>Move to Recycle Bin</DialogTitle>
        <DialogContent>
          {confirmMessage()}
        </DialogContent>
        <DialogActions>
          <Button variation="link" onClick={() => setConfirmOpen(false)}>
            Cancel
          </Button>
          <Button
            variation="destructive"
            onClick={performDelete}
            isLoading={isDeleting}
            loadingText="Deleting..."
          >
            Move to Recycle Bin
          </Button>
        </DialogActions>
      </Dialog>

      {/* ERROR DIALOG */}
      <Dialog open={errorOpen} onClose={() => setErrorOpen(false)}>
        <DialogTitle>Deletion error</DialogTitle>
        <DialogContent>
          <Typography>{errorMsg}</Typography>
        </DialogContent>
        <DialogActions>
          <Button variation="primary" onClick={() => setErrorOpen(false)}>
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};
