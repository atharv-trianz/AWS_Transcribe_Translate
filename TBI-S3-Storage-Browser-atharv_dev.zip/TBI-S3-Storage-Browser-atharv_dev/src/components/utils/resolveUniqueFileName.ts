import { FileUploadAPI } from '../../api/fileupload';
 
export async function resolveUniqueFilename(
  originalName: string,
  path: string
): Promise<string> {
  try {
    const { resolvedName } = await FileUploadAPI.resolveFilename(originalName, path);
    return resolvedName;
  } catch {
    return originalName;
  }
}
