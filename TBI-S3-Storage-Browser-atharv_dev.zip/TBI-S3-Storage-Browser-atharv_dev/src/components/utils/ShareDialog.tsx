import { useEffect, useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Autocomplete,
  TextField,
  Chip,
  Box,
  Checkbox,
  FormControlLabel,
  Stack,
  Typography,
  Divider,
  Switch,
  Alert,
} from '@mui/material';
import toast from 'react-hot-toast';
import { Button } from "@aws-amplify/ui-react";

type User = {
  user_name: string;
  email: string;
};

type Permission = {
  read: boolean;
  write: boolean;
};

type SharedUser = User & Permission;

type ShareMode = 'internal' | 'external';

type SharePayload = {
  mode: ShareMode;
  files: string[];
  users?: {
    user_name: string;
    email: string;
    read: boolean;
    write: boolean;
  }[];
  externalEmails?: {
    email: string;
    read: boolean;
    write: boolean;
  }[];
};

type SharedTo = {
  user_id: string;
  email: string;
  permissions: {
    read: boolean;
    write: boolean;
  };
};

type ShareDialogProps = {
  open: boolean;
  users?: User[];
  selectedFiles: string[];
  sharedTo?: SharedTo[];
  onClose: () => void;
  onShare: (payload: SharePayload) => void;
};

export default function ShareDialog({
  open,
  users,
  selectedFiles,
  sharedTo,
  onClose,
  onShare
}: ShareDialogProps) {
  const [mode, setMode] = useState<ShareMode>('internal');
  const [selectedUsers, setSelectedUsers] = useState<SharedUser[]>([]);
  const [externalEmailsInput, setExternalEmailsInput] = useState('');
  const [inputValue, setInputValue] = useState('');
  const [isSharing, setIsSharing] = useState(false);

  const isValidEmail = (email: string) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const parseEmails = (input: string): string[] =>
    input
      .split(',')
      .map(e => e.trim())
      .filter(e => e.length > 0);

  const externalEmails = parseEmails(externalEmailsInput);
  const invalidEmails = externalEmails.filter(email => !isValidEmail(email));
  const hasInvalidEmails = invalidEmails.length > 0;
  const hasUncommittedEmail = inputValue.trim().length > 0;

  useEffect(() => {
    if (!open) return;

    if (!sharedTo || !users) {
      setSelectedUsers([]);
      return;
    }

    const hydrated = sharedTo
      .map(shared => {
        const user = users.find(u => u.email === shared.email);
        if (!user) return null;
        return {
          user_name: user.user_name,
          email: shared.email,
          read: shared.permissions.read,
          write: shared.permissions.write
        };
      })
      .filter(Boolean) as SharedUser[];

    setSelectedUsers(hydrated);
  }, [open, sharedTo, users]);

  const handleUserChange = (_: any, users: User[]) => {
    setSelectedUsers(prev => {
      const map = new Map(prev.map(u => [u.user_name, u]));
      return users.map(user => {
        const existing = map.get(user.user_name);
        return existing ?? { ...user, read: true, write: false };
      });
    });
  };

  const updatePermission = (
    userId: string,
    permission: keyof Permission,
    value: boolean
  ) => {
    setSelectedUsers(prev =>
      prev.map(user => {
        if (user.user_name !== userId) return user;

        if (permission === 'write' && value) {
          return { ...user, write: true, read: true };
        }

        if (permission === 'read' && !value) {
          return { ...user, read: false, write: false };
        }

        return { ...user, [permission]: value };
      })
    );
  };

  const handleShare = () => {
  
    if (mode === 'external' && hasUncommittedEmail) return;

    if (mode === 'internal') {
      if (selectedUsers.length === 0) return;
    } else {
      if (externalEmails.length === 0 || hasInvalidEmails) return;
    }

    try {
      setIsSharing(true);
      const base = { mode, files: Array.from(selectedFiles) };

      if (mode === 'internal') {
        onShare({
          ...base,
          users: selectedUsers.map(({ user_name, read, write, email }) => ({
            user_name,
            email,
            read,
            write,
          })),
        });
      } else {
        onShare({
          ...base,
          externalEmails: externalEmails.map(email => ({
            email,
            read: true,
            write: false,
          })),
        });
      }
      toast.success('Case Shared Successfully');

      setSelectedUsers([]);
      setExternalEmailsInput('');
      setInputValue('');
      setMode('internal');
      onClose();
    } catch (error) {
      console.log('Error occurred: ', error);
      toast.error('Failed to share');
    } finally {
      setIsSharing(false);
    }
  };

  const handleClose = () => {
    setSelectedUsers([]);
    setExternalEmailsInput('');
    setInputValue('');
    setMode('internal');
    onClose();
  };

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
      <DialogTitle>Share Evidence</DialogTitle>

      <DialogContent>
        <Box
          display="flex"
          alignItems="center"
          justifyContent="space-between"
          mb={2}
        >
          <Typography variant="subtitle2">Share Type</Typography>
          <Stack direction="row" alignItems="center">
            <Typography>Internal</Typography>
            <Switch
              checked={mode === 'external'}
              onChange={() =>
                setMode(prev => prev === 'internal' ? 'external' : 'internal')
              }
            />
            <Typography>External</Typography>
          </Stack>
        </Box>

        <Divider />

        {mode === 'internal' ? (
          <>
            <Autocomplete
              multiple
              options={users || []}
              isOptionEqualToValue={(opt, val) => opt.user_name === val.user_name}
              getOptionLabel={(o) => `${o.email}`}
              value={selectedUsers}
              onChange={handleUserChange}
              renderTags={(value, getTagProps) =>
                value.map((option, index) => (
                  <Chip
                    label={option.email}
                    {...getTagProps({ index })}
                    key={option.user_name}
                  />
                ))
              }
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Select internal users"
                  margin="normal"
                />
              )}
            />

            {selectedUsers.length > 0 && (
              <Box mt={2}>
                <Typography variant="subtitle2">Permissions</Typography>
                <Stack spacing={2} mt={1}>
                  {selectedUsers.map(user => (
                    <Box key={user.user_name}>
                      <Stack
                        direction="row"
                        alignItems="center"
                        justifyContent="space-between"
                      >
                        <Typography>{user.email}</Typography>
                        <Stack direction="row">
                          <FormControlLabel
                            control={
                              <Checkbox
                                checked={user.read}
                                onChange={(e) =>
                                  updatePermission(user.user_name, 'read', e.target.checked)
                                }
                              />
                            }
                            label="Read"
                          />
                          <FormControlLabel
                            control={
                              <Checkbox
                                checked={user.write}
                                onChange={(e) =>
                                  updatePermission(user.user_name, 'write', e.target.checked)
                                }
                              />
                            }
                            label="Update"
                          />
                        </Stack>
                      </Stack>
                      <Divider />
                    </Box>
                  ))}
                </Stack>
              </Box>
            )}
          </>
        ) : (
          <Box mt={2}>
            <Autocomplete
              multiple
              freeSolo
              options={[]}
              value={externalEmails}
              inputValue={inputValue}
              onInputChange={(_, newInputValue) => setInputValue(newInputValue)}
              onChange={(_, newValue) => {
                const cleaned = (newValue as string[]).map(v => v.trim()).filter(Boolean);
                setExternalEmailsInput(cleaned.join(','));
                setInputValue('');
              }}
              renderTags={(value, getTagProps) =>
                value.map((option, index) => (
                  <Chip
                    label={option}
                    color={isValidEmail(option) ? 'default' : 'error'}
                    {...getTagProps({ index })}
                    key={option}
                  />
                ))
              }
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="External Emails"
                  placeholder="Type email and press Enter or comma"
                  error={hasInvalidEmails}
                  helperText={
                    hasInvalidEmails
                      ? `Invalid: ${invalidEmails.join(', ')}`
                      : 'Press Enter or comma to add each email'
                  }
                  margin="normal"
                  onKeyDown={(e) => {
                    if (e.key === ',' || e.key === 'Enter') {
                      e.preventDefault();
                      const val = inputValue.trim().replace(/,$/, '');
                      if (!val) return;
                      const updated = [...externalEmails, val];
                      setExternalEmailsInput(updated.join(','));
                      setInputValue('');
                    }
                  }}
                />
              )}
            />

            {hasUncommittedEmail && (
              <Alert severity="warning" sx={{ mt: 1 }}>
                "{inputValue.trim()}" hasn't been added yet — press <strong>Enter</strong> or <strong>comma</strong> to add it before sharing.
              </Alert>
            )}
          </Box>
        )}
      </DialogContent>

      <DialogActions>
        <Button onClick={handleClose} color="inherit">
          Cancel
        </Button>
        <Button
          onClick={handleShare}
          variation="primary"
          isLoading={isSharing}
          loadingText="Sharing..."
          disabled={
            mode === 'internal'
              ? selectedUsers.length === 0
              : externalEmails.length === 0 || hasInvalidEmails || hasUncommittedEmail
          }
        >
          Share
        </Button>
      </DialogActions>
    </Dialog>
  );
}