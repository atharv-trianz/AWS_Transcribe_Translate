import { Box, Tooltip, Typography } from "@mui/material";

type TooltipCellProps = {
  label: string;
  email?: string;
  role?: string;
};

export function TooltipCell({ label, email, role }: TooltipCellProps) {
  if (!label) return null;

  return (
    <Tooltip
      arrow
      placement="top-start"
      title={
        <Box>
          {email && (
            <Typography fontSize={13}>
              {email}
            </Typography>
          )}
          {role && (
            <Typography fontSize={13} color="warning.main">
              Role: {role}
            </Typography>
          )}
        </Box>
      }
      componentsProps={{
        tooltip: {
          sx: {
            bgcolor: "#1e293b",
            color: "#fff",
            fontSize: "13px",
            maxWidth: 320,
            p: 1.5,
          },
        },
        arrow: {
          sx: {
            color: "#1e293b",
          },
        },
      }}
    >
      <span>{label}</span>
    </Tooltip>
  );
}