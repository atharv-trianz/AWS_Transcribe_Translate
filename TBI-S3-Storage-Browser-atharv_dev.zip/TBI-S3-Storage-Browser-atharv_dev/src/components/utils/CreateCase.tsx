// import { uploadData } from "aws-amplify/storage";
import { Button } from "@aws-amplify/ui-react";
import { useState, useMemo } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Stack,
  MenuItem,
  Box,
  Chip,
  CircularProgress,
  Alert,
} from "@mui/material";
import { useUser } from "../../context/UserContext";
import { useCreateCase, useOrgConfig } from "../../hooks/cases";
import toast from "react-hot-toast";

type CreateCaseProps = {
  basePath: string;
  owner_id?: string;
};

const JURISDICTIONS = [
  "1st Jurisdiction",
  "2nd Jurisdiction",
  "3rd Jurisdiction",
  "4th Jurisdiction",
  "5th Jurisdiction",
  "6th Jurisdiction",
  "7th Jurisdiction",
];

export const CreateCase = ({ basePath, owner_id }: CreateCaseProps) => {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [caseNumber, setCaseNumber] = useState("");
  const [caseNumberError, setCaseNumberError] = useState(false);
  const [caseTitle, setCaseTitle] = useState("");
  const [jurisdiction, setJurisdiction] = useState<string[]>([]);
  const [caseAgents, setCaseAgents] = useState("");
  const [division, setDivision] = useState("");
  const [unit, setUnit] = useState("");
  const [squad, setSquad] = useState("");

  const { userInfo } = useUser();
  const { mutateAsync: createCase } = useCreateCase();
  const {
    data: orgConfig,
    isLoading: orgLoading,
    isError: orgError,
  } = useOrgConfig();

  const divisionsList = useMemo(() => orgConfig?.divisions ?? [], [orgConfig]);

  const availableUnits = useMemo(() => {
    if (!orgConfig || !division) return [];
    return Object.keys(orgConfig.org_structure?.[division]?.units ?? {});
  }, [orgConfig, division]);

  const availableSquads = useMemo(() => {
    if (!orgConfig || !division || !unit) return [];
    return orgConfig.org_structure?.[division]?.units?.[unit]?.squads ?? [];
  }, [orgConfig, division, unit]);

  const divisionValid = !!division && divisionsList.includes(division);

  const divisionHasUnits = divisionValid && availableUnits.length > 0;

  const unitValid = !divisionHasUnits
    ? true 
    : !!unit && availableUnits.includes(unit);

  const squadRequired = divisionHasUnits && unitValid && availableSquads.length > 0;
  const squadValid = !squadRequired || (!!squad && availableSquads.includes(squad));
  const validateCaseNumber = (value: string) => /^\d{4}-\d{7}$/.test(value);

  const resetForm = () => {
    setCaseNumber("");
    setCaseTitle("");
    setJurisdiction([]);
    setCaseAgents("");
    setDivision("");
    setUnit("");
    setSquad("");
    setError(null);
  };

  const handleOpen = () => {
    resetForm();
    setOpen(true);
  };

  const handleDivisionChange = (value: string) => {
    setDivision(value);
    setUnit(""); 
    setSquad(""); 
    setError(null);
  };

  const handleUnitChange = (value: string) => {
    setUnit(value);
    setSquad("");
    setError(null);
  };

  const handleCreate = async () => {
    if (!validateCaseNumber(caseNumber)) {
      setError("Case Number must be in format YYYY-1234567");
      return;
    }
    if (!caseTitle.trim()) {
      setError("Case Title is required");
      return;
    }
    if (jurisdiction.length === 0) {
      setError("At least one Jurisdiction is required");
      return;
    }

    if (!division) {
      setError("Division is required");
      return;
    }
    if (!divisionValid) {
      setError("Please select a valid Division from the dropdown");
      return;
    }

    if (divisionHasUnits) {
      if (!unit) {
        setError("Unit is required for the selected Division");
        return;
      }
      if (!unitValid) {
        setError("Please select a valid Unit from the dropdown");
        return;
      }
    } else {
      if (unit || squad) {
        setUnit("");
        setSquad("");
      }
    }

    if (squadRequired && !squad) {
      setError("Squad is required for the selected unit");
      return;
    }
    if (!squadValid) {
      setError("Please select a valid Squad from the dropdown");
      return;
    }

    const folderPath = `${basePath}${caseNumber}/`;

    const payload: any = {
      user_name: userInfo.user_id,
      owner_id: owner_id,
      email: userInfo.email || "",
      case_number: caseNumber,
      case_title: caseTitle,
      jurisdiction: JSON.stringify(jurisdiction),
      case_agents: caseAgents,
      source_key: folderPath,
      division,
      ...(divisionHasUnits ? { unit } : {}),
      ...(divisionHasUnits && squad ? { squad } : {}),
    };

    try {
      setLoading(true);
      await createCase(payload);
      toast.success("Case created successfully");
      setOpen(false);
      resetForm();
    } catch {

    } finally {
      setLoading(false);
    }
  };
  const createDisabled = loading || orgLoading || orgError;

  
const handleCaseNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
  const value = e.target.value;
  setCaseNumber(value);

  // show error only when user starts typing
  if (value.length > 0) {
    setCaseNumberError(!validateCaseNumber(value));
  } else {
    setCaseNumberError(false);
  }
};


  return (
    <>
      <Button size="small" onClick={handleOpen} isDisabled={loading}>
        Create Case
      </Button>

      <Dialog
        open={open}
        onClose={() => !loading && setOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Create Case Evidence Repository</DialogTitle>

        <DialogContent>
          {orgLoading ? (
            <Box display="flex" justifyContent="center" py={4}>
              <CircularProgress size={28} />
            </Box>
          ) : orgError ? (
            <Alert severity="error" sx={{ mt: 1 }}>
              Failed to load org structure. Please close and try again.
            </Alert>
          ) : (
            <Stack spacing={2} mt={1}>
              <TextField
                required
                label="Kaseware Case Number"
                placeholder="2025-1234567"
                value={caseNumber}
                onChange={handleCaseNumberChange}
                error={caseNumberError}
                helperText={
                      caseNumberError
                        ? 'Format must be YYYY-1234567'
                        : ' '
                }

                disabled={loading}
              />

              <TextField
                required
                label="Kaseware Case Title"
                value={caseTitle}
                onChange={(e) => setCaseTitle(e.target.value)}
                disabled={loading}
              />

              <TextField
                select
                required
                label="Jurisdiction"
                disabled={loading}
                SelectProps={{
                  multiple: true,
                  renderValue: (selected) => (
                    <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5, mt: 0.5 }}>
                      {(selected as string[]).map((value) => (
                        <Chip key={value} label={value} size="small" />
                      ))}
                    </Box>
                  ),
                  MenuProps: {
                    PaperProps: { style: { maxHeight: 240, width: 320 } },
                    anchorOrigin: { vertical: "bottom", horizontal: "left" },
                    transformOrigin: { vertical: "top", horizontal: "left" },
                  },
                }}
                value={jurisdiction}
                onChange={(e) =>
                  setJurisdiction(
                    typeof e.target.value === "string"
                      ? e.target.value.split(",")
                      : (e.target.value as string[])
                  )
                }
              >
                {JURISDICTIONS.map((j) => (
                  <MenuItem key={j} value={j}>
                    {j}
                  </MenuItem>
                ))}
              </TextField>

              <TextField
                select
                required
                label="Division"
                value={division}
                onChange={(e) => handleDivisionChange(e.target.value)}
                disabled={loading}
              >
                {divisionsList.map((d) => (
                  <MenuItem key={d} value={d}>
                    {d}
                  </MenuItem>
                ))}
              </TextField>

              {divisionHasUnits && (
                <TextField
                  select
                  required
                  label="Unit"
                  value={unit}
                  onChange={(e) => handleUnitChange(e.target.value)}
                  disabled={loading}
                >
                  {availableUnits.map((u) => (
                    <MenuItem key={u} value={u}>
                      {u}
                    </MenuItem>
                  ))}
                </TextField>
              )}

              {divisionHasUnits && unitValid && squadRequired && (
                <TextField
                  select
                  required
                  label="Squad"
                  value={squad}
                  onChange={(e) => setSquad(e.target.value)}
                  disabled={loading}
                >
                  {availableSquads.map((s) => (
                    <MenuItem key={s} value={s}>
                      {s}
                    </MenuItem>
                  ))}
                </TextField>
              )}

              <TextField
                label="Case Agent(s)"
                placeholder="Agent Smith, Agent Doe"
                value={caseAgents}
                onChange={(e) => setCaseAgents(e.target.value)}
                disabled={loading}
              />

              {error && <span style={{ color: "red" }}>{error}</span>}
            </Stack>
          )}
        </DialogContent>

        <DialogActions>
          <Button
            variation="link"
            onClick={() => {
              setOpen(false);
              resetForm();
            }}
            isDisabled={loading}
          >
            Cancel
          </Button>
          <Button variation="primary" onClick={handleCreate} isDisabled={createDisabled}>
            {loading ? "Creating..." : "Create Case"}
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};