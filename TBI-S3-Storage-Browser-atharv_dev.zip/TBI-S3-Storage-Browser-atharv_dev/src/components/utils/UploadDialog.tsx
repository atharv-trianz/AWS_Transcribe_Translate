import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Stack,
  LinearProgress,
  Typography,
  IconButton,
  Box,
  InputAdornment,
  MenuItem,
  CircularProgress,
} from "@mui/material";
import { Pause, PlayArrow } from "@mui/icons-material";
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { useState, useEffect, useRef } from "react";
import { useFileUploader } from "../../hooks/useMultipartUpload";
import { useUploadManager } from '../../context/UploadContext'
import DisabledByDefaultIcon from '@mui/icons-material/DisabledByDefault';
import toast from "react-hot-toast";
import { EvidenceAPI } from '../../api/evidence/evidence.api';

interface Case {
  case_number: string;
  case_title?: string;
}

type Props = {
  open: boolean;
  onClose: () => void;
  prefix: string;
  onUploaded?: (uploadedName: string, originalName: string) => void;
  initialFile?: File | null;
  resolveFilename?: (originalName: string) => Promise<string>;
  cases?: Case[];
};

type UploadFileItem = {
  file: File,
  evidenceNumber: string,
  description: string,
  selected?: boolean
}
type CheckedEntry = { number: string; duplicate: boolean } | null;

export function UploadDialog({
  open,
  onClose,
  prefix,
  onUploaded,
  resolveFilename,
  cases,
}: Props) {
  const [files, setFiles] = useState<UploadFileItem[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [selectedCase, setSelectedCase] = useState('');
  const isTemptab = location.pathname.includes("temp");
  const evidencePrefix = selectedCase ? `${selectedCase}-E` : (isTemptab ? '' : `${prefix.split('/')[2]}-E`);
  const caseNumber = prefix.split('/')[1] ?? '';
  const [loading, setLoading] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [stepMode, setStepMode] = useState(false);
  const [duplicateEvidenceIndex, setDuplicateEvidenceIndex] = useState<Set<number>>(new Set());
  const [checkingIndex, setCheckingIndex] = useState<Set<number>>(new Set());
  const [availableIndex, setAvailableIndex] = useState<Set<number>>(new Set());
  const lastCheckedRef = useRef<Map<number, CheckedEntry>>(new Map());
  const { addFiles } = useUploadManager();
  const {
    uploadMutation,
    progress,
    pause,
    resume,
    cancelUpload,
    retryUpload,
    isPaused,
    isNetworkError
  } = useFileUploader();

  useEffect(() => {
    if (!open) {
      setFiles([]);
      setError(null);
      setDuplicateEvidenceIndex(new Set());
      setCheckingIndex(new Set());
      setAvailableIndex(new Set());
      setSelectedCase('');
      setStepMode(false);
      setCurrentIndex(0);
      lastCheckedRef.current = new Map();
    } else {
      setSelectedCase(prefix.split('/')[1]);
    }
  }, [open]);

  const validateEvidenceNumber = (value: string) =>
    /^\d{4}-\d{7}-E\d{5}$/.test(value);
  const setIsDuplicateAt = (i: number, val: boolean) =>
    setDuplicateEvidenceIndex(prev => { const n = new Set(prev); val ? n.add(i) : n.delete(i); return n; });

  const setIsAvailableAt = (i: number, val: boolean) =>
    setAvailableIndex(prev => { const n = new Set(prev); val ? n.add(i) : n.delete(i); return n; });
  console.log('prefixcxxxxxxxx',prefix);
  const runDuplicateCheck = async (evNumber: string, fileIndex: number): Promise<boolean> => {
    const caseToCheck = isTemptab ? selectedCase : caseNumber;
    const currentFilePath = files[fileIndex]?.file?.name ?? '';
    console.log(`Checking evidence number "${evNumber}" against case "${caseToCheck}" and other temp files (excluding "${currentFilePath}")`);
    try {
      let existsInCase = false;
      if (caseToCheck) {
        const caseItems = await EvidenceAPI.getEvidence(`${caseToCheck}/`);
        existsInCase = caseItems.some(
          (ev: any) => ev.evidence_number === evNumber
        );
      }
      const tempItems = await EvidenceAPI.getEvidence('temp/');
      const existsInOtherTempFile = tempItems.some(
        (ev: any) =>
          ev.evidence_number === evNumber &&
          ev.file_name_path !== currentFilePath
      );

      return existsInCase || existsInOtherTempFile;
    } catch {
      return true;
    }
  };
  const checkDuplicateEvidenceNumber = async (evNumber: string, fileIndex: number) => {
    if (!validateEvidenceNumber(evNumber)) return;
    setCheckingIndex(prev => new Set(prev).add(fileIndex));
    setIsDuplicateAt(fileIndex, false);
    setIsAvailableAt(fileIndex, false);
    lastCheckedRef.current.set(fileIndex, null);
    try {
      const duplicate = await runDuplicateCheck(evNumber, fileIndex);
      setIsDuplicateAt(fileIndex, duplicate);
      setIsAvailableAt(fileIndex, !duplicate);
      lastCheckedRef.current.set(fileIndex, { number: evNumber, duplicate });
    } finally {
      setCheckingIndex(prev => { const n = new Set(prev); n.delete(fileIndex); return n; });
    }
  };

  useEffect(() => {
    if (uploadMutation.isSuccess) {
      onUploaded?.('', '');
      onClose();
    }
  }, [uploadMutation.isSuccess]);
  const isFileValid = (fileIndex: number): boolean => {
    const f = files[fileIndex];
    if (!f) return false;
    if (f.evidenceNumber && validateEvidenceNumber(f.evidenceNumber)) {
      if (duplicateEvidenceIndex.has(fileIndex)) return false;
      if (checkingIndex.has(fileIndex)) return false;
      if (!availableIndex.has(fileIndex)) return false;
      const checked = lastCheckedRef.current.get(fileIndex);
      if (!checked || checked.number !== f.evidenceNumber || checked.duplicate) return false;
      const isDuplicateInBatch = files.some((other, i) => i !== fileIndex && other.evidenceNumber === f.evidenceNumber);
      if (isDuplicateInBatch) return false;
    }
    if (isTemptab) {
      if (!validateEvidenceNumber(f.evidenceNumber)) return false;
      if (f.description.trim() === '') return false;
    }

    return true;
  };
  const isCurrentValid = () => isFileValid(currentIndex);
  const isAllValid = () => files.every((_, i) => isFileValid(i));

  const handleUpload = async () => {
    const filesToUpload = files.filter((f) => f.selected !== false);
    if (!filesToUpload.length) {
      setError("Please select at least one file to upload.");
      return;
    }

    setError(null);
    setLoading(true);
    try {
      for (let i = 0; i < files.length; i++) {
        const f = files[i];
        if (f.selected === false) continue;
        if (!f.evidenceNumber || !validateEvidenceNumber(f.evidenceNumber)) continue;
        setCheckingIndex(prev => new Set(prev).add(i));
        setIsAvailableAt(i, false);
        try {
          const duplicate = await runDuplicateCheck(f.evidenceNumber, i);
          setIsDuplicateAt(i, duplicate);
          setIsAvailableAt(i, !duplicate);
          lastCheckedRef.current.set(i, { number: f.evidenceNumber, duplicate });
          if (duplicate) {
            setCurrentIndex(i);
            setError(`Evidence number "${f.evidenceNumber}" is already in use. Please choose a different number.`);
            setLoading(false);
            return;
          }
        } finally {
          setCheckingIndex(prev => { const n = new Set(prev); n.delete(i); return n; });
        }
      }
    } catch {
      setError("Failed to verify evidence numbers. Please try again.");
      setLoading(false);
      return;
    }
    try {
      const resolvedFiles = await Promise.all(
        filesToUpload.map(async (item) => {
          const originalName = item.file.name;
          const resolvedName = resolveFilename ? await resolveFilename(originalName) : originalName;
          const renamedFile =
            resolvedName !== originalName
              ? new File([item.file], resolvedName, { type: item.file.type })
              : item.file;
          return { ...item, file: renamedFile, _originalName: originalName, _resolvedName: resolvedName };
        })
      );

      addFiles(resolvedFiles, prefix);
      setLoading(false);
      setStepMode(false);

      const renamedFiles = resolvedFiles.filter(f => f._resolvedName !== f._originalName);
      const totalCount = resolvedFiles.length;
      const renamedCount = renamedFiles.length;

      if (renamedCount === totalCount) {
        if (renamedCount === 1) {
          toast.success(`"${renamedFiles[0]._originalName}" already exists — uploaded as "${renamedFiles[0]._resolvedName}"`);
        } else {
          toast.success(`${renamedCount} files already existed and were auto-renamed`);
          renamedFiles.forEach(f => toast(`"${f._originalName}" → "${f._resolvedName}"`, { icon: '📄' }));
        }
      } else if (renamedCount > 0) {
        toast.success(`${totalCount} files uploading — ${renamedCount} auto-renamed`);
        renamedFiles.forEach(f => toast(`"${f._originalName}" → "${f._resolvedName}"`, { icon: '📄' }));
      } else {
        toast.success(totalCount === 1 ? `1 file upload in progress...` : `${totalCount} files upload in progress...`);
      }

      const first = resolvedFiles[0];
      onUploaded?.(first._resolvedName, first._originalName);
      onClose();
    } catch (err) {
      setLoading(false);
      console.error(err);
      setError("Upload failed");
    }
  };

  const togglePause = () => { if (isPaused) resume(); else pause(); };

  const handleFieldChange = (field: "evidenceNumber" | "description", value: string) => {
    const updated = [...files];
    if (field === 'evidenceNumber') {
      updated[currentIndex]['evidenceNumber'] = evidencePrefix + value;
    } else {
      updated[currentIndex]['description'] = value;
    }
    setFiles(updated);
  };

  const removeFileAt = (idx: number) => {
    setFiles((prev) => {
      const next = prev.filter((_, i) => i !== idx);
      if (!isTemptab && stepMode && currentIndex >= next.length) {
        setCurrentIndex(Math.max(0, next.length - 1));
      }
      lastCheckedRef.current.delete(idx);
      return next;
    });
  };

  const selectedCount = files.filter((f) => f.selected !== false).length;

  useEffect(() => {
    if (selectedCount === 0) setStepMode(false);
  }, [selectedCount]);

  const evidenceHelperText = () => {
    if (checkingIndex.has(currentIndex)) return 'Checking availability...';
    if (duplicateEvidenceIndex.has(currentIndex)) return 'This evidence number is already in use';
    const currentNumber = files[currentIndex]?.evidenceNumber;
    if (currentNumber && validateEvidenceNumber(currentNumber)){
      const isDuplicateInBatch = files.some((other, i) => i !== currentIndex && other.evidenceNumber === currentNumber);
      if (isDuplicateInBatch) return 'This evidence number is duplicated in the current batch';
    }
    if (availableIndex.has(currentIndex)) return 'Evidence number is available';
    return 'Format: YYYY-XXXXXXX-EXXXXX';
  };

  const evidenceEndAdornment = () => {
    if (checkingIndex.has(currentIndex)) {
      return (
        <InputAdornment position="end">
          <CircularProgress size={16} thickness={5} />
        </InputAdornment>
      );
    }
    if (availableIndex.has(currentIndex)) {
      return (
        <InputAdornment position="end">
          <CheckCircleIcon fontSize="small" color="success" />
        </InputAdornment>
      );
    }
    return undefined;
  };

  return (
    <Dialog
      open={open}
      onClose={(reason) => {
        if (reason === 'backdropClick') return;
        setFiles([]);
        setError(null);
        setStepMode(false);
        onClose();
      }}
      maxWidth="sm"
      fullWidth
    >
      <DialogTitle sx={{ fontWeight: 600 }}>
        Upload Evidence
      </DialogTitle>

      <DialogContent>
        <Stack spacing={3} mt={1}>
          {!stepMode && files.length === 0 && (
            <Button variant="outlined" component="label" disabled={loading}>
              Select File
              <input
                type="file"
                hidden
                multiple
                onChange={(e) => {
                  const selected = e.target.files ? Array.from(e.target.files) : [];
                  setFiles(selected.map((file) => ({ file, evidenceNumber: "", description: "", selected: true })));
                  setCurrentIndex(0);
                  lastCheckedRef.current = new Map();
                }}
              />
            </Button>
          )}
          {files.length > 0 && (
            <Box sx={{ fontFamily: "inherit", fontSize: 20 }}>
              Total files selected {files.length}
            </Box>
          )}

          {files.length > 0 && files.map((item, index) => (
            <Box
              key={item.file.name + index}
              sx={{
                fontFamily: "inherit",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: 1,
                border: "1px solid",
                borderColor: "divider",
                borderRadius: 1,
                px: 1.5,
                py: 1,
                minWidth: 20,
              }}
            >
              <Stack direction="row" alignItems="center" spacing={1} sx={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis' }}>
                <Box sx={{ flex: 1, minWidth: 0 }}>
                  <Typography fontWeight={300} noWrap title={item.file.name}>
                    {item.file.name}
                  </Typography>
                </Box>
              </Stack>
              <IconButton
                aria-label="remove-file"
                color="error"
                onClick={() => removeFileAt(index)}
                title="Remove from list"
                size="small"
                sx={{ borderColor: "divider" }}
              >
                <DisabledByDefaultIcon />
              </IconButton>
            </Box>
          ))}

          {stepMode && files.length > 0 && (
            <Box>
              <Typography fontWeight={600}>
                File {currentIndex + 1} of {files.length}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {files[currentIndex].file.name}
              </Typography>
              {isTemptab && cases && cases.length > 0 && (
                <TextField
                  select
                  label="Case"
                  value={selectedCase}
                  onChange={(e) => {
                    setSelectedCase(e.target.value);
                    setError('');
                    setDuplicateEvidenceIndex(new Set());
                    setAvailableIndex(new Set());
                    lastCheckedRef.current = new Map();
                  }}
                  fullWidth
                  sx={{ mt: 3 }}
                  helperText="Select a case to auto-prefix the evidence number"
                >
                  <MenuItem value="">— No case selected —</MenuItem>
                  {cases.map(c => (
                    <MenuItem key={c.case_number} value={c.case_number}>
                      {c.case_number}{c.case_title ? ` — ${c.case_title}` : ''}
                    </MenuItem>
                  ))}
                </TextField>
              )}
              <TextField
                required={isTemptab}
                disabled={isTemptab && !selectedCase}
                sx={{ mt: 3 }}
                label="Kaseware Evidence Number"
                placeholder={isTemptab ? "00001" : "00001 (Optional)"}
                slotProps={{
                  input: {
                    startAdornment: (
                      <InputAdornment sx={{ fontWeight: 600 }} position="start">
                        {evidencePrefix}
                      </InputAdornment>
                    ),
                    endAdornment: evidenceEndAdornment(),
                  },
                  formHelperText: {
                    sx: {
                      color: availableIndex.has(currentIndex)
                        ? 'success.main'
                        : checkingIndex.has(currentIndex)
                        ? 'text.secondary'
                        : undefined,
                    },
                  },
                }}
                value={files[currentIndex].evidenceNumber?.replace(`${evidencePrefix}`, "")}
                onChange={(e) => {
                  handleFieldChange("evidenceNumber", e.target.value);
                  setIsDuplicateAt(currentIndex, false);
                  setIsAvailableAt(currentIndex, false);
                  lastCheckedRef.current.set(currentIndex, null);
                  const fullNumber = `${evidencePrefix}${e.target.value}`;
                  if (validateEvidenceNumber(fullNumber)) {
                    checkDuplicateEvidenceNumber(fullNumber, currentIndex);
                  }
                }}
                error={
                  (files[currentIndex].evidenceNumber !== "" && !validateEvidenceNumber(files[currentIndex].evidenceNumber)) ||
                  duplicateEvidenceIndex.has(currentIndex) ||
                  (validateEvidenceNumber(files[currentIndex].evidenceNumber) && files.some((other, i) => i !== currentIndex && other.evidenceNumber === files[currentIndex].evidenceNumber))
                }
                helperText={evidenceHelperText()}
                fullWidth
              />

              <TextField
                required={isTemptab}
                sx={{ mt: 3 }}
                label="Description"
                placeholder={isTemptab ? "Required - describe this evidence..." : "Optional - describe this evidence..."}
                multiline
                rows={2}
                value={files[currentIndex].description}
                onChange={(e) => handleFieldChange("description", e.target.value)}
                fullWidth
              />
            </Box>
          )}
          {uploadMutation.isPending && (
            <Box>
              <LinearProgress variant="determinate" value={progress} sx={{ height: 8, borderRadius: 5 }} />
              <Stack direction="row" justifyContent="space-between" alignItems="center" mt={1}>
                <Typography variant="caption">
                  {isNetworkError ? "Paused — Network disconnected" : isPaused ? "Paused" : `${progress}% uploaded`}
                </Typography>
                <IconButton
                  size="small"
                  disabled={isNetworkError && !navigator.onLine}
                  onClick={togglePause}
                  sx={{ border: "1px solid", borderColor: "divider" }}
                >
                  {isPaused ? <PlayArrow fontSize="small" /> : <Pause fontSize="small" />}
                </IconButton>
              </Stack>
            </Box>
          )}
          {uploadMutation.isError && (
            <Button variant="contained" color="warning" onClick={() => { setError(null); retryUpload(); }}>
              Retry
            </Button>
          )}

          {error && <Typography color="error">{error}</Typography>}
        </Stack>
      </DialogContent>

      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button
          onClick={async () => {
            await cancelUpload();
            setFiles([]);
            setStepMode(false);
            setError(null);
            onClose();
          }}
        >
          Cancel
        </Button>

        {files.length > 0 && !stepMode && (
          <>
            <Button onClick={() => handleUpload()}>
              Skip Metadata and Upload
            </Button>
            <Button
              variant="contained"
              onClick={() => setStepMode(true)}
              sx={{ borderRadius: 3 }}
            >
              Add Metadata and Upload
            </Button>
          </>
        )}
        {stepMode && currentIndex > 0 && (
          <Button onClick={() => setCurrentIndex((prev) => prev - 1)}>
            Previous
          </Button>
        )}
        {stepMode && currentIndex < files.length - 1 && (
          <Button
            variant="contained"
            disabled={!isCurrentValid()}
            onClick={() => setCurrentIndex((prev) => prev + 1)}
          >
            Next
          </Button>
        )}

        {stepMode && currentIndex === files.length - 1 && (
          <Button
            variant="contained"
            disabled={loading || checkingIndex.size > 0 || !isAllValid()}
            onClick={handleUpload}
            sx={{ borderRadius: 3 }}
          >
            {loading ? 'Checking...' : 'Upload All'}
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
}
