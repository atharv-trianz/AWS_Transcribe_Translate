import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Stack,
  Typography,
  MenuItem,
  InputAdornment,
  CircularProgress,
} from "@mui/material";
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { useState, useEffect, useRef } from "react";
import { EvidenceAPI } from '../../api/evidence/evidence.api';

interface Case {
  case_number: string;
  case_title?: string;
}

interface MetadataDialogProps {
  open: boolean;
  files: string[];
  initialMetadata?: {
    evidence_number?: string;
    description?: string;
  };
  cases?: Case[];
  caseNumber?: string;
  existingEvidenceNumbers?: Set<string>;
  onClose: () => void;
  onSave: (metadata: { evidence_number: string; description: string }) => Promise<void>;
}

export const MetadataDialog = ({
  open,
  files,
  initialMetadata,
  cases,
  caseNumber,
  onClose,
  onSave,
}: MetadataDialogProps) => {
  const [selectedCase, setSelectedCase] = useState('');
  const [evidenceSuffix, setEvidenceSuffix] = useState('');
  const [description, setDescription] = useState('');
  const [saving, setSaving] = useState(false);
  const [isDuplicate, setIsDuplicate] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [isAvailable, setIsAvailable] = useState(false);
  const lastCheckedRef = useRef<{ number: string; duplicate: boolean } | null>(null);
  const evidencePrefix = selectedCase ? `${selectedCase}-E` : '';
  const evidenceNumber = evidencePrefix
    ? `${evidencePrefix}${evidenceSuffix}`
    : evidenceSuffix;

  const isFromTemp = !!cases && cases.length > 0;
  useEffect(() => {
    if (open) {
      setDescription(initialMetadata?.description ?? '');
      setIsDuplicate(false);
      setIsChecking(false);
      setIsAvailable(false);
      lastCheckedRef.current = null;

      const existing = initialMetadata?.evidence_number ?? '';

      if (isFromTemp) {
        if (existing && cases) {
          const matchedCase = cases.find(c =>
            existing.startsWith(`${c.case_number}-E`)
          );
          if (matchedCase) {
            setSelectedCase(matchedCase.case_number);
            setEvidenceSuffix(existing.replace(`${matchedCase.case_number}-E`, ''));
          } else {
            setSelectedCase('');
            setEvidenceSuffix(existing);
          }
        } else if (!existing && caseNumber) {
          setSelectedCase(caseNumber);
          setEvidenceSuffix('');
        } else {
          setSelectedCase('');
          setEvidenceSuffix('');
        }
      } else {
        if (!existing && caseNumber) {
          setSelectedCase(caseNumber);
          setEvidenceSuffix('');
        } else {
          setSelectedCase('');
          setEvidenceSuffix(existing);
        }
      }
    }
  }, [open, initialMetadata, caseNumber, isFromTemp, cases]);

  const validateEvidenceNumber = (value: string) =>
    /^\d{4}-\d{7}-E\d{5}$/.test(value);
  const runDuplicateCheck = async (evNumber: string): Promise<boolean> => {
    const caseToCheck = isFromTemp ? selectedCase : caseNumber;
    const currentFilePath = files[0];
    console.log(`Checking metadata evidence number "${evNumber}" against case "${caseToCheck}" and other temp files (excluding "${currentFilePath}")`);
    try {
      let existsInCase = false;
      if (caseToCheck) {
        const caseItems = await EvidenceAPI.getEvidence(`${caseToCheck}/`);
        existsInCase = caseItems.some(
          (ev: any) => ev.evidence_number === evNumber
        );
      }
      const tempItems = await EvidenceAPI.getEvidence('temp/');
      const existsInOtherTempFile = tempItems.some(
        (ev: any) =>
          ev.evidence_number === evNumber &&
          ev.file_name_path !== currentFilePath
      );

      return existsInCase || existsInOtherTempFile;
    } catch {
      return true;
    }
  };

  const checkDuplicateEvidenceNumber = async (evNumber: string) => {
    if (!validateEvidenceNumber(evNumber)) return;
    setIsChecking(true);
    setIsDuplicate(false);
    setIsAvailable(false);
    lastCheckedRef.current = null;

    try {
      const duplicate = await runDuplicateCheck(evNumber);
      setIsDuplicate(duplicate);
      setIsAvailable(!duplicate);
      lastCheckedRef.current = { number: evNumber, duplicate };
    } finally {
      setIsChecking(false);
    }
  };

  const isFormValid = () => {
    const finalEvidenceNumber = evidencePrefix && !evidenceSuffix.trim() ? '' : evidenceNumber;
    const evidenceValid = finalEvidenceNumber === '' || validateEvidenceNumber(finalEvidenceNumber);
    if (finalEvidenceNumber && finalEvidenceNumber !== initialMetadata?.evidence_number) {
      if (!lastCheckedRef.current || lastCheckedRef.current.number !== finalEvidenceNumber) {
        return false;
      }
      if (lastCheckedRef.current.duplicate) return false;
    }

    return (
      evidenceValid &&
      description.trim() !== '' &&
      !isDuplicate &&
      !isChecking
    );
  };

  const handleSave = async () => {
    const finalEvidenceNumber = evidencePrefix && !evidenceSuffix.trim() ? '' : evidenceNumber;
    const isValid = finalEvidenceNumber === '' || validateEvidenceNumber(finalEvidenceNumber);
    if (!isValid || !description.trim()) return;
    if (finalEvidenceNumber && finalEvidenceNumber !== initialMetadata?.evidence_number) {
      setSaving(true);
      setIsChecking(true);
      try {
        const duplicate = await runDuplicateCheck(finalEvidenceNumber);
        setIsDuplicate(duplicate);
        setIsAvailable(!duplicate);
        lastCheckedRef.current = { number: finalEvidenceNumber, duplicate };
        if (duplicate) {
          return;
        }
      } finally {
        setIsChecking(false);
        setSaving(false);
      }
    }

    setSaving(true);
    try {
      await onSave({ evidence_number: finalEvidenceNumber, description });
      onClose();
    } finally {
      setSaving(false);
    }
  };
  const evidenceEndAdornment = () => {
    if (isChecking) {
      return (
        <InputAdornment position="end">
          <CircularProgress size={16} thickness={5} />
        </InputAdornment>
      );
    }
    if (isAvailable) {
      return (
        <InputAdornment position="end">
          <CheckCircleIcon fontSize="small" color="success" />
        </InputAdornment>
      );
    }
    return undefined;
  };
  const evidenceHelperText = () => {
    if (isChecking) return 'Checking availability...';
    if (isDuplicate) return 'This evidence number is already in use';
    if (isAvailable) return 'Evidence number is available';
    if (evidenceNumber && !validateEvidenceNumber(evidenceNumber) && evidenceSuffix.trim())
      return 'Format: YYYY-XXXXXXX-EXXXXX';
    if (evidencePrefix && evidenceSuffix.trim()) return `Full number: ${evidenceNumber}`;
    if (evidencePrefix && !evidenceSuffix.trim())
      return 'Enter the postfix number (e.g. 00001) or leave blank to skip';
    return 'Format: YYYY-XXXXXXX-EXXXXX';
  };
  const endAdornment = evidenceEndAdornment();
  return (
    <Dialog
      open={open}
      onClose={(reason) => {
        if (reason === 'backdropClick') return;
        onClose();
      }}
      maxWidth="sm"
      fullWidth
    >
      <DialogTitle sx={{ fontWeight: 600 }}>
        Edit Metadata
        {files.length === 1 && (
          <Typography variant="body2" color="text.secondary" fontWeight={400}>
            {files[0].split('/').pop()}
          </Typography>
        )}
        {files.length > 1 && (
          <Typography variant="body2" color="text.secondary" fontWeight={400}>
            {files.length} files selected
          </Typography>
        )}
      </DialogTitle>
      <DialogContent>
        <Stack spacing={3} mt={1}>

          {/* Case picker — only shown in Temp tab */}
          {isFromTemp && (
            <TextField
              select
              label="Case"
              value={selectedCase}
              onChange={(e) => {
                setSelectedCase(e.target.value);
                setEvidenceSuffix('');
                setIsDuplicate(false);
                setIsAvailable(false);
                lastCheckedRef.current = null;
              }}
              fullWidth
              helperText="Select a case to auto-prefix the evidence number"
            >
              <MenuItem value="">— No case selected —</MenuItem>
              {cases.map(c => (
                <MenuItem key={c.case_number} value={c.case_number}>
                  {c.case_number}{c.case_title ? ` — ${c.case_title}` : ''}
                </MenuItem>
              ))}
            </TextField>
          )}
          {/* Evidence number field */}
          <TextField
            label="Evidence Number"
            placeholder={evidencePrefix ? "00001" : "e.g. 2024-0000001-E00001"}
            value={evidenceSuffix}
            onChange={(e) => {
              const newSuffix = e.target.value;
              setEvidenceSuffix(newSuffix);
              setIsDuplicate(false);
              setIsAvailable(false);
              lastCheckedRef.current = null;
              const fullNumber = evidencePrefix ? `${evidencePrefix}${newSuffix}` : newSuffix;
              if (validateEvidenceNumber(fullNumber)) {
                checkDuplicateEvidenceNumber(fullNumber);
              }
            }}
            slotProps={{
              input: {
                ...(evidencePrefix ? {
                  startAdornment: (
                    <InputAdornment position="start" sx={{ fontWeight: 600 }}>
                      {evidencePrefix}
                    </InputAdornment>
                  ),
                } : {}),
                ...(endAdornment ? { endAdornment } : {}),
              },
              formHelperText: {
                sx: {
                  color: isAvailable
                    ? 'success.main'
                    : isChecking
                    ? 'text.secondary'
                    : undefined,
                },
              },
            }}
            helperText={evidenceHelperText()}
            error={
              isDuplicate ||
              (!!evidenceNumber && !validateEvidenceNumber(evidenceNumber) && evidenceSuffix.trim() !== '')
            }
            fullWidth
          />
          <TextField
            label="Description"
            placeholder="Describe this evidence..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            multiline
            rows={3}
            fullWidth
            error={description !== '' && description.trim() === ''}
          />
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onClose} disabled={saving}>
          Cancel
        </Button>
        <Button
          variant="contained"
          onClick={handleSave}
          disabled={saving || isChecking || !isFormValid()}
          sx={{ borderRadius: 3 }}
        >
          {saving ? 'Saving...' : 'Save'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};