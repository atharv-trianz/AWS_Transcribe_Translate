import { Button } from "@aws-amplify/ui-react";
import { useState, useEffect } from "react";
import { UploadDialog } from "./UploadDialog";
interface Case {
  case_number: string;
  case_title?: string;
}
type UploadButtonProps = {
  prefix: string; // MUST be full path ending with /
  onUploaded?: (uploadedName: string, originalName: string) => void;
  droppedFile?: File | null;
  onClearDroppedFile?: () => void;
  /** Optional async fn to resolve a unique filename before upload */
  resolveFilename?: (originalName: string) => Promise<string>;
  cases?: Case[];
};

export const UploadButton = ({
  prefix,
  onUploaded,
  droppedFile,
  onClearDroppedFile,
  resolveFilename,
  cases,
}: UploadButtonProps) => {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (droppedFile) {
      setOpen(true);
    }
  }, [droppedFile]);
  return (
    <>
      <Button size="small" variation="primary" onClick={() => setOpen(true)}>
        Upload
      </Button>

      <UploadDialog
        open={open}
        onClose={() => {
          onClearDroppedFile?.();
          setOpen(false);
        }}
        prefix={prefix}
        initialFile={droppedFile}
        resolveFilename={resolveFilename}
        cases={cases}
        onUploaded={(uploadedName: string, originalName: string) => {
          onUploaded?.(uploadedName, originalName);
          onClearDroppedFile?.();
          setOpen(false);
        }}
      />
    </>
  );
};