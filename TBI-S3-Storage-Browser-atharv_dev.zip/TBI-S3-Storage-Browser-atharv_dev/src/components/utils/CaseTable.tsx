import { DataGrid, GridColDef, GridRenderCellParams } from "@mui/x-data-grid";
import {
  Box,
  Chip,
  IconButton,
  Tooltip,
  Typography,
  Menu,
  MenuItem,
  CircularProgress,
  Divider,
} from "@mui/material";

import FolderIcon from "@mui/icons-material/Folder";
import InsertDriveFileIcon from "@mui/icons-material/InsertDriveFile";
import DownloadIcon from "@mui/icons-material/Download";
import VisibilityIcon from "@mui/icons-material/Visibility";
import RecordVoiceOverIcon from "@mui/icons-material/RecordVoiceOver";
import GTranslateIcon from "@mui/icons-material/GTranslate";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";

import { useMemo, useRef, useState } from "react";
import { User } from "../../api/users/users.types";
import PersonIcon from "@mui/icons-material/Person";
import AdminPanelSettingsIcon from "@mui/icons-material/AdminPanelSettings";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";

import { Case, ShareCaseToPayload } from "../../api/cases/cases.types";
import toast from "react-hot-toast";

import { FileViewDownloadAPI } from "../../api/viewdownload";
import { TooltipCell } from "./TooltipCell";

export interface S3BaseObject {
  Key: string;
  type?: "folder";
}

interface Evidence {
  case_number: string;
  created_at: string;
  description: string;
  email: string;
  evidence_number: string;
  file_name_path: string;
  last_modified: string;
  modified_by: string;
  modified_by_email: string;
  name: string;
  size: string;
  type: string;
  user_id: string;
  user_name: string;
  user_role: string;

  s3_key?: string;

  transcribeStatus?: "NOT_REQUESTED" | "IN_PROGRESS" | "COMPLETED" | "FAILED";
  transcribe_latest_version?: number;
  transcribe_versions?: any;

  translateStatus?: "NOT_REQUESTED" | "IN_PROGRESS" | "COMPLETED" | "FAILED";
  translateTarget?: string;
  translate?: any;
  translateError?: string;
}

interface CommonGridProps {
  loading: boolean;
  handleRowClick: (params: unknown) => void;
  handleSelected?: (params: unknown) => void;
  onFileDrop?: (file: File) => void;

  // Promise supported so buffering waits for API completion
  onTranscribe?: (row: any, force: boolean, enhanced?: boolean) => Promise<any> | void;
  onTranslate?: (row: any, targetLang: string, force: boolean) => Promise<any> | void;

  translateLanguageOptions?: { code: string; label: string }[];
  owner_id?: string;
}

interface UsersModeProps extends CommonGridProps {
  viewMode: "users";
  data: User[];
}

interface CasesModeProps extends CommonGridProps {
  viewMode: "cases";
  data: Case[];
}

interface FilesModeProps extends CommonGridProps {
  viewMode: "files";
  data: Evidence[];
}

interface ReceivedModeProps extends CommonGridProps {
  viewMode: "received";
  data: ShareCaseToPayload[];
}

type GridProps = CasesModeProps | FilesModeProps | ReceivedModeProps | UsersModeProps;

// function formatHumanTime(isoString: string | null | undefined, locale: string = "en-IN"): string {
//   if (!isoString) return "—";
//   const normalized = normalizeIsoToMillis(isoString);
//   const d = new Date(normalized);
//   if (Number.isNaN(d.getTime())) return isoString;

//   return d.toLocaleString(locale, {
//     timeZone: "Asia/Kolkata",
//     year: "numeric",
//     month: "2-digit",
//     day: "2-digit",
//     hour: "2-digit",
//     minute: "2-digit",
//     second: "2-digit",
//     hour12: true,
//   });
// }

function formatYMDHMS(isoString: string | null | undefined): string {
  if (!isoString) return "—";

  const d = new Date(isoString);
  if (Number.isNaN(d.getTime())) return "—";

  const pad = (n: number) => String(n).padStart(2, "0");

  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ` +
         `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

// function normalizeIsoToMillis(iso: string): string {
//   return iso.replace(/(\.\d{1,})(Z)$/i, (_m, frac: string, z: string) =>
//     `.${frac.slice(1, 4).padEnd(3, "0")}${z}`
//   );
// }

// infer type by extension
function getExt(name?: string) {
  if (!name) return "";
  const clean = name.split("?")[0].trim().toLowerCase();
  const parts = clean.split(".");
  return parts.length > 1 ? parts.pop() || "" : "";
}

function isAudioVideoByExt(name?: string) {
  const ext = getExt(name);
  const audio = ["mp3", "wav", "m4a", "aac", "flac", "ogg", "opus"];
  const video = ["mp4", "mov", "avi", "mkv", "webm", "m4v"];
  return audio.includes(ext) || video.includes(ext);
}

function isPdfOrImageByExt(name?: string) {
  const ext = getExt(name);
  const pdf = ["pdf"];
  const img = ["png", "jpg", "jpeg", "tiff", "tif", "bmp"];
  return pdf.includes(ext) || img.includes(ext);
}


type TooltipConfig = {
  labelField: string;
  emailField?: string;
  roleField?: string;
};


const renderTooltipCell =
  ({ labelField, emailField, roleField }: TooltipConfig) =>
  (params: GridRenderCellParams) => {
    const row = params.row;

    return (
      <TooltipCell
        label={row[labelField]}
        email={emailField ? row[emailField] : undefined}
        role={roleField ? row[roleField] : undefined}
      />
    );
  };
  
export default function CasesGrid(props: GridProps) {
  const {
    viewMode,
    data,
    loading,
    handleRowClick,
    handleSelected,
    onFileDrop,
    owner_id,

    onTranscribe,
    onTranslate,
    translateLanguageOptions,
  } = props;

  const [isDragging, setIsDragging] = useState(false);
  const ids = useRef<string[]>([]);
  const admin_group_name = import.meta.env.VITE_DEMS_ADMIN_GROUP_NAME;
  console.log("admin_group_name: ", admin_group_name);

  /**
   * ✅ DIFFERENT APPROACH (FIX):
   * Render ONE global Menu outside DataGrid and anchor by mouse position.
   * This avoids DataGrid virtualization issues when Menu is inside renderCell.
   */
  const [translateMenuPos, setTranslateMenuPos] = useState<{ mouseX: number; mouseY: number } | null>(null);
  const [translateRow, setTranslateRow] = useState<any>(null);
  const [translateRowId, setTranslateRowId] = useState<string | null>(null);

  // buffering state for translate per row
  const [translateBusyRowId, setTranslateBusyRowId] = useState<string | null>(null);

  const defaultLangOptions = useMemo(
    () => [
      { code: "en", label: "English (en)" },
      { code: "es", label: "Spanish (es)" },
      // { code: "hi", label: "Hindi (hi)" },        // ✅ new
      { code: "fr", label: "French (fr)" },      // new 
      { code: "de", label: "German (de)" },      // new
      // { code: "ar", label: "Arabic (ar)" },
      { code: "zh", label: "Chinese (zh)" },
      { code: "vi", label: "Vietnamese (vi)" },
    ],
    []
  );

  const langOptions = translateLanguageOptions?.length ? translateLanguageOptions : defaultLangOptions;

  const handleDragOver = (e: React.DragEvent) => {
    if (viewMode !== "files") return;
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => setIsDragging(false);

  const handleDrop = (e: React.DragEvent) => {
    if (viewMode !== "files") return;
    e.preventDefault();
    setIsDragging(false);

    const files = e.dataTransfer.files;
    if (files && files.length > 0) onFileDrop?.(files[0]);
  };

  const closeTranslateMenu = () => {
    setTranslateMenuPos(null);
    setTranslateRow(null);
    setTranslateRowId(null);
  };

  const chooseTranslateLang = async (langCode: string) => {
    if (!onTranslate || !translateRow || !translateRowId) return;

    // optional local rerun guard
    const map = translateRow.translate || {};
    const node = map?.[langCode];
    const latest = node?.latest_version || 0;
    const vkey = `v${latest}`;
    const lastObj = node?.versions?.[vkey];
    const lastStatus = (lastObj?.status || "").toUpperCase();

    if (lastStatus === "COMPLETED") {
      toast(`Already translated to ${langCode}`, { icon: "✅" });
      closeTranslateMenu();
      return;
    }
    if (lastStatus === "IN_PROGRESS") {
      toast(`Translation already running (${langCode})`, { icon: "⏳" });
      closeTranslateMenu();
      return;
    }

    try {
      setTranslateBusyRowId(translateRowId);
      closeTranslateMenu();

      const maybePromise = onTranslate(translateRow, langCode, false);
      if (maybePromise && typeof (maybePromise as any).then === "function") {
        await (maybePromise as Promise<any>);
      } else {
        // fallback to show spinner even if handler doesn't return promise
        await new Promise((r) => setTimeout(r, 800));
      }
    } finally {
      setTranslateBusyRowId(null);
    }
  };

  const caseColumns: GridColDef[] = [
    {
      field: "case_number",
      headerName: "Case Number",
      minWidth: 160,
      renderCell: (params) => (
        <Box sx={{ display: "flex", alignItems: "center", gap: 1, cursor: "pointer" }}>
          <FolderIcon sx={{ fontSize: 20, color: "#f59e0b" }} />
          {params.value}
        </Box>
      ),
    },
    { field: "case_title", headerName: "Case Title", minWidth: 150  },
    { field: "case_agents", headerName: "Case Agent", minWidth: 150  },
    { field: "jurisdiction", headerName: "Jurisdiction", minWidth: 180  },
    { field: "division", headerName: "Division", minWidth: 150  },
    { field: "unit", headerName: "Unit", minWidth: 150 },
    {
      field: "squad",
      headerName: "Squad",
      minWidth: 150,
      renderCell: (params) => params.value || "—",
    },
    {
      field: "size",
      headerName: "Size",
      minWidth: 120,
      valueFormatter: (params) => formatBytes(params),
    },
    { field: "created_at", headerName: "Created At", minWidth: 200 },
    {
      field: "created_by",
      headerName: "Created By",
      minWidth: 170,
      // renderCell: (params) => {
      //   console.log("paramsssqqqqqqqqq: ", params);
      //   const email = params.row.email;
      //   const created_by = params.row.created_by;
      //   const created_by_role = params.row.created_by_role;
      //   return (
      //     <>
      //       <Tooltip
      //         arrow
      //         placement="top-start"
      //         title={
      //           <Box>
      //             <Typography fontSize={13}>{email}</Typography>
      //             <Typography fontSize={13} color="warning.main">
      //               Role: {created_by_role}
      //             </Typography>
      //           </Box>
      //         }
      //         componentsProps={{
      //           tooltip: {
      //             sx: {
      //               bgcolor: "#1e293b",
      //               color: "#fff",
      //               fontSize: "13px",
      //               maxWidth: 320,
      //               p: 1.5,
      //             },
      //           },
      //           arrow: { sx: { color: "#1e293b" } },
      //         }}
      //       >
      //         <span>{created_by}</span>
      //       </Tooltip>
      //     </>
      //   );
      // },

      
      renderCell: renderTooltipCell({
          labelField: 'created_by',
          emailField: 'email',
          roleField: 'created_by_role',
        }),

    },
    { field: "updated_at", headerName: "Last Updated", minWidth: 200 },
  ];

  const fileColumns: GridColDef[] = [
    {
      field: "name",
      headerName: "Name",
      minWidth: 250,
      renderCell: (params) => {
        const isFolder = params.row.isFolder;
        return (
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 1,
              minWidth: 0,
              width: "100%",
              cursor: "pointer",
            }}
          >
            {isFolder ? (
              <FolderIcon sx={{ fontSize: 20, color: "#f59e0b" }} />
            ) : (
              <InsertDriveFileIcon sx={{ fontSize: 20, color: "#64748b" }} />
            )}
            <Box
              sx={{
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
                minWidth: 0,
                flexGrow: 1,
              }}
            >
              {params.value}
            </Box>
          </Box>
        );
      },
    },
    { field: "evidence_number", headerName: "Evidence", minWidth: 150 },
    { field: "description", headerName: "Description", minWidth: 150},
    {
      field: "size",
      headerName: "Size",
      minWidth: 120,
      valueFormatter: (params) => formatBytes(params),
    },
    {
      field: "actions",
      headerName: "Actions",
      minWidth: 180,
      sortable: false,
      filterable: false,
      disableColumnMenu: true,
      renderCell: (params) => {
        const isFolder = params.row.isFolder;
        const id = String(params.row.id);
        const filename = params.row.name as string;

        const isAudioOrVideo = isAudioVideoByExt(filename);
        const isPdfOrImage = isPdfOrImageByExt(filename);

        const tStatus = (params.row.transcribeStatus || "NOT_REQUESTED") as string;
        const trStatus = (params.row.translateStatus || "NOT_REQUESTED") as string;

        const isTranscribeRunning = tStatus === "IN_PROGRESS";
        // const isTranscribeDone = tStatus === "COMPLETED";
        // const isTranscribeFailed = tStatus === "FAILED";

        const isTranslateRunning = trStatus === "IN_PROGRESS";
        const isTranslateBusy = translateBusyRowId === id;

        const handleTranscribe = (e: React.MouseEvent, force: boolean) => {
          e.stopPropagation();
          if (!onTranscribe) {
            toast.error("Transcribe action not configured");
            return;
          }

          if (!force && (isTranscribeRunning || isTranscribeDone)) {
            toast("Transcription already exists. Use Re-Transcribe.", { icon: "ℹ️" });
            return;
          }

          onTranscribe(params.row, force, false);
        };
      //  const handleTranscribe = (e: React.MouseEvent, force: boolean) => {
      //     e.stopPropagation();
      //     if (!onTranscribe) {
      //       toast.error("Transcribe action not configured");
      //       return;
      //     }
      //     if (!force && (isTranscribeRunning || isTranscribeDone)) {
      //       toast("Transcription already exists. Use Re-Transcribe.", { icon: "ℹ️" });
      //       return;
      //     }
      //     onTranscribe(params.row, force, false);
      //   };

        // ✅ open translate menu using mouse position anchor
        const openTranslateMenu = (e: React.MouseEvent) => {
          e.stopPropagation();
          if (!onTranslate) {
            toast.error("Translate action not configured");
            return;
          }

          setTranslateRow(params.row);
          setTranslateRowId(id);

          setTranslateMenuPos({
            mouseX: e.clientX - 2,
            mouseY: e.clientY - 4,
          });
        };

        const handleView = async (e: React.MouseEvent) => {
          e.stopPropagation();
          try {
            // keeping your signature (3rd param owner_id)
            const url = await FileViewDownloadAPI.getSignedUrl([id], "view", owner_id);
            window.open(url, "_blank");
          } catch (err: any) {
            toast.error(err.message);
          }
        };

        const handleDownload = async (e: React.MouseEvent) => {
          e.stopPropagation();
          try {
            const urls = await FileViewDownloadAPI.getSignedUrl(
              ids.current.length !== 0 ? ids.current : [id],
              "download",
              owner_id
            );

            for (let i = 0; i < urls.length; i++) {
              const link = document.createElement("a");
              link.href = urls[i];
              link.setAttribute("download", "");
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
              await new Promise((resolve) => setTimeout(resolve, 2000));
            }
          } catch (err: any) {
            toast.error(err.message);
          }
        };

        return (
          <>
            {!isFolder && (
              <Tooltip title="View">
                <IconButton size="small" onClick={handleView}>
                  <VisibilityIcon fontSize="small" color="primary" />
                </IconButton>
              </Tooltip>
            )}

            {!isFolder && (
              <Tooltip title="Download">
                <IconButton size="small" onClick={handleDownload}>
                  <DownloadIcon fontSize="small" color="secondary" />
                </IconButton>
              </Tooltip>
            )}
            {/* TRANSCRIBE (audio/video) */}
            {!isFolder && isAudioOrVideo && (
            <Tooltip
                title={
                  isTranscribeRunning
                    ? "Transcribing..."
                    : (params.row.transcribe_latest_version ?? 0) >= 1
                    ? "Enhanced Re-Transcribe (Noise reduction)"
                    : "Start Transcription"
                }
            >
            <span>
            <IconButton
                    size="small"
                    disabled={isTranscribeRunning}
                    onClick={(e) => {
                      e.stopPropagation();
                      if (!onTranscribe) {
                        toast.error("Transcribe action not configured");
                        return;
                      }
                      const alreadyTranscribed = (params.row.transcribe_latest_version ?? 0) >= 1;
                      const force = alreadyTranscribed;        // v2+ requires rerun
                      const enhanced = alreadyTranscribed;     // after first run, always enhanced
                      onTranscribe(params.row, force, enhanced);
                    }}
            >
                    {isTranscribeRunning ? (
            <CircularProgress size={18} />
                    ) : (
            <RecordVoiceOverIcon
                        fontSize="small"
                        sx={{
                          color:
                            (params.row.transcribe_latest_version ?? 0) >= 1
                              ? "#7c3aed"   // purple when it's enhanced mode
                              : "inherit",
                        }}
                      />
                    )}
            </IconButton>
            </span>
            </Tooltip>
            )}
            {/* TRANSLATE split button (pdf/image) */}
            {!isFolder && isPdfOrImage && (
              <Tooltip title="Translate">
                <span>
                  <Box
                    sx={{
                      display: "inline-flex",
                      alignItems: "center",
                      border: "1px solid rgba(0,0,0,0.12)",
                      borderRadius: 1,
                      overflow: "hidden",
                      ml: 0.5,
                    }}
                  >
                    <IconButton
                      size="small"
                      onClick={openTranslateMenu}
                      disabled={isTranslateRunning || isTranslateBusy}
                      sx={{ borderRadius: 0 }}
                    >
                      {isTranslateBusy ? (
                        <CircularProgress size={18} />
                      ) : (
                        <GTranslateIcon fontSize="small" />
                      )}
                    </IconButton>

                    <Divider orientation="vertical" flexItem />

                    <IconButton
                      size="small"
                      onClick={openTranslateMenu}
                      disabled={isTranslateRunning || isTranslateBusy}
                      sx={{ borderRadius: 0, px: 0.5 }}
                    >
                      <ArrowDropDownIcon fontSize="small" />
                    </IconButton>
                  </Box>
                </span>
              </Tooltip>
            )}

            


          </>
        );
      },
      },
      { field: "createdAt", headerName: "Created At", minWidth: 200 },
      {
        field: "created_by",
        headerName: "Created By",
        minWidth: 150,
        // renderCell: (params) => {
        //   const email = params.row.email;
        //   const created_by = params.row.created_by;
        //   return (
        //     <>
        //       <Tooltip title={email}>
        //         <span>{created_by}</span>
        //       </Tooltip>
        //     </>
        //   );
        // },
        // renderCell: (params) => {
        //   console.log('paramsss: ', params)
        //   // const shared_by_email = params.row.shared_by_email
        //   const email = params.row.email
        //   const created_by = params.row.created_by
        //   const created_by_role = params.row.user_role
        //   // const shared_by = params.row.shared_by
        //   // const shared_by_role = params.row.shared_by_role
        //   return (
        //     <>
        //       <Tooltip arrow placement="top-start" title={
                  
        //         <Box>
        //           <Typography fontSize={13}>
        //             {email}
        //           </Typography>
        //           <Typography fontSize={13} color="warning.main">
        //             Role: {created_by_role}
        //           </Typography>
        //         </Box>

        //         }
        //       componentsProps={{
        //           tooltip: {
        //             sx: {
        //               bgcolor: "#1e293b",      // dark slate
        //               color: "#fff",
        //               fontSize: "13px",
        //               maxWidth: 320,
        //               p: 1.5,
        //             },
        //           },
        //           arrow: {
        //             sx: {
        //               color: "#1e293b",
        //             },
        //           },
        //         }}

        //       >
        //         {created_by}
        //       </Tooltip>
        //     </>
        //   )
        // }


        renderCell: renderTooltipCell({
          labelField: 'created_by',
          emailField: 'email',
          roleField: 'user_role',
        }),
      },
      {
        field: "modified_by",
        headerName: "Modified By",
        minWidth: 150,
        // renderCell: (params) => {
        //   const modified_by_email = params.row.modified_by_email;
        //   const modified_by = params.row.modified_by;
        //   return (
        //     <>
        //       <Tooltip title={modified_by_email}>
        //         <span>{modified_by}</span>
        //       </Tooltip>
        //     </>
        //   );
        // },
        // renderCell: (params) => {
        //   console.log('paramsss: ', params)
        //   // const shared_by_email = params.row.shared_by_email
        //   const modified_by_email = params.row.modified_by_email
        //   const modified_by = params.row.modified_by
        //   const modified_by_role = params.row.user_role
        //   // const shared_by = params.row.shared_by
        //   // const shared_by_role = params.row.shared_by_role
        //   return (
        //     <>
        //       <Tooltip arrow placement="top-start" title={
                  
        //         <Box>
        //           <Typography fontSize={13}>
        //             {modified_by_email}
        //           </Typography>
        //           <Typography fontSize={13} color="warning.main">
        //             Role: {modified_by_role}
        //           </Typography>
        //         </Box>

        //         }
        //       componentsProps={{
        //           tooltip: {
        //             sx: {
        //               bgcolor: "#1e293b",      // dark slate
        //               color: "#fff",
        //               fontSize: "13px",
        //               maxWidth: 320,
        //               p: 1.5,
        //             },
        //           },
        //           arrow: {
        //             sx: {
        //               color: "#1e293b",
        //             },
        //           },
        //         }}

        //       >
        //         {modified_by}
        //       </Tooltip>
        //     </>
        //   )
        // }

        renderCell: renderTooltipCell({
          labelField: 'modified_by',
          emailField: 'modified_by_email',
          roleField: 'modified_by_role',
        }),
      },
      { field: "last_modified", headerName: "Last Modified", minWidth: 200},
    ];

    const receivedCaseColumns: GridColDef[] = [
      {
        field: "case_number",
        headerName: "Case Number",
        minWidth: 160,
        renderCell: (params) => (
          <Box sx={{ display: "flex", alignItems: "center", gap: 1, cursor: "pointer" }}>
            <FolderIcon sx={{ fontSize: 20, color: "#f59e0b" }} />
            {params.value}
          </Box>
        ),
      },
      { field: "case_title", headerName: "Case Title", minWidth: 150 },
      { field: "case_agents", headerName: "Case Agent(s)", minWidth: 150 },
      { field: "jurisdiction", headerName: "Jurisdiction", minWidth: 180 },
      { field: "division", headerName: "Division", minWidth: 150 },
      { field: "unit", headerName: "Unit", minWidth: 150 },
      { field: "squad", headerName: "Squad", minWidth: 150 },
      {
        field: "size",
        headerName: "Size",
        minWidth: 120,
        valueFormatter: (params) => formatBytes(params),
      },
      { field: "permissions", headerName: "Access", minWidth: 150 },
      { field: "owner_email", headerName: "Created By", minWidth: 170 },
      { 
        field: "shared_by", 
        headerName: "Shared By", 
        minWidth: 170,
        renderCell: renderTooltipCell({
          labelField: 'shared_by',
          emailField: 'shared_by_email',
          roleField: 'shared_by_role',
        }),
      },
      { field: "shared_at", headerName: "Shared At", minWidth: 200 },
      { field: "updated_at", headerName: "Last Updated", minWidth: 200 },
    ];

  const userColumns: GridColDef[] = [
    {
      field: "name",
      headerName: "Name",
      flex: 1,
      renderCell: (params) => (
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 1,
            "&:hover .name": { textDecoration: "underline" },
          }}
        >
          <PersonIcon fontSize="small" sx={{ color: "#64748b" }} />
          {params.value}
        </Box>
      ),
    },
    {
      field: "user_role",
      headerName: "Role",
      flex: 1,
      renderCell: (params) => {
        const isAdmin = params.value === admin_group_name;
        return (
          <Chip
            icon={isAdmin ? <AdminPanelSettingsIcon /> : undefined}
            label={params.value}
            size="small"
            sx={{
              fontWeight: 600,
              bgcolor: isAdmin ? "#e0f2fe" : "#f1f5f9",
              color: isAdmin ? "#075985" : "#334155",
            }}
          />
        );
      },
    },
    {
      field: "email",
      headerName: "Email",
      flex: 1,
      renderCell: (params) => {
        const fullId = params.value as string;
        return (
          <Box sx={{ display: "flex", alignItems: "center", gap: 0.5, height: "100%" }} onClick={(e) => e.stopPropagation()}>
            <Tooltip title={fullId} arrow>
              <Typography sx={{ fontSize: 15, color: "#334155", cursor: "default" }}>{fullId}</Typography>
            </Tooltip>
            <Tooltip title="Copy User ID">
              <IconButton
                size="small"
                onClick={(e) => {
                  e.stopPropagation();
                  navigator.clipboard.writeText(fullId);
                }}
              >
                <ContentCopyIcon sx={{ fontSize: 18 }} />
              </IconButton>
            </Tooltip>
          </Box>
        );
      },
    },
  ];

  function formatBytes(bytes?: number) {
    if (!bytes) return "—";
    const sizes = ["B", "KB", "MB", "GB", "TB"];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${sizes[i]}`;
  }

  const rows = useMemo(() => {
    if (viewMode === "users") {
      return (data as any[]).map((item: any) => ({
        id: item.user_name,
        name: item.name,
        email: item.email,
        user_role: item.user_role,
        user_id: item.user_name,
      }));
    }

    if (viewMode === "cases") {
      console.log("ddddddddddd: ", data);
      return (data as any[]).map((item: any) => ({
        id: item.source_key,
        case_number: item.case_number,
        case_title: item.case_title,
        case_agents: item.case_agents,
        jurisdiction: Array.isArray(item.jurisdiction) ? item.jurisdiction.join(", ") : item.jurisdiction,
        size: item.size,
        division: item.division || "—",
        unit: item.unit || "—",
        squad: item.squad || "—",
        updated_at: formatYMDHMS(item.updated_at),
        created_at: formatYMDHMS(item.created_at),
        created_by: item.created_by,
        email: item.email,
        created_by_role: item.created_by_role,
      }));
    }

    if (viewMode === "received") {
      return (data as any[]).map((item: any) => {
        const { read, write } = item.permissions || {};
        let access = "No Access";
        if (read && write) access = "Read / Update";
        else if (read) access = "Read Only";

        return {
          id: item.case_number,
          case_number: item.case_number,
          case_title: item.case_title,
          case_agents: item.case_agents,
          jurisdiction: Array.isArray(item.jurisdiction) ? item.jurisdiction.join(", ") : item.jurisdiction,
          size: item.size,
          division: item.division || "—",
          unit: item.unit || "—",
          squad: item.squad || "—",
          shared_at: formatYMDHMS(item.shared_at),
          source_key: item.source_key,
          shared_by: item.shared_by,
          shared_by_email: item.shared_by_email,
          shared_by_role: item.shared_by_role,
          updated_at: formatYMDHMS(item.updated_at),
          permissions: access,
          owner_id: item.owner_user,
          owner_email: item.owner_email
        };
      });
    }

    // files
    return (data as any[]).map((item: any) => ({
      id: item?.file_name_path,
      name: item?.name,
      isFolder: item?.type === "FOLDER",
      evidence_number: item?.evidence_number || "—",
      description: item?.description || "—",
      createdAt: formatYMDHMS(item?.created_at),
      created_by: item?.user_name,
      size: item?.size || 0,
      role: item?.user_role,
      email: item?.email,
      last_modified: formatYMDHMS(item?.last_modified),
      modified_by: item?.modified_by,
      modified_by_email: item?.modified_by_email,
      modified_by_role: item.modified_by_role,

      transcribeStatus: item?.transcribeStatus || "NOT_REQUESTED",
      transcribe_latest_version: item?.transcribe_latest_version || 0,
      transcribe_versions: item?.transcribe_versions || {},

      translateStatus: item?.translateStatus || "NOT_REQUESTED",
      translateTarget: item?.translateTarget || "",
      translate: item?.translate || {},
      translateError: item?.translateError || "",
    }));
  }, [data, viewMode]);

  const columns = useMemo(() => {
    if (viewMode === "cases") return caseColumns;
    if (viewMode === "received") return receivedCaseColumns;
    if (viewMode === "users") return userColumns;
    return fileColumns;
  }, [viewMode]);

  return (
    <Box
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      sx={{
        height: 520,
        width: "100%",
        backgroundColor: isDragging ? "#f0f8ff" : "#fff",
        borderRadius: 2,
        border: isDragging ? "2px dashed #1976d2" : "2px solid transparent",
        transition: "0.2s ease",
      }}
    >
      <DataGrid
        key={viewMode}
        loading={loading}
        rows={rows}
        columns={columns}
        onRowClick={(params) => {
          if (viewMode === "files" && !params.row?.isFolder) return;
          handleRowClick(params);
        }}
        onRowSelectionModelChange={(model: any) => {
          let selectedIds: string[] = [];
          if (model.type === "include") {
            selectedIds = Array.from(model.ids).map(String);
          } else {
            const excludedIds = model.ids;
            selectedIds = (rows as any[]).map((row: any) => row.id).filter((rid: any) => !excludedIds.has(rid));
          }
          handleSelected?.(selectedIds);
          ids.current = selectedIds;
        }}
        disableRowSelectionOnClick
        checkboxSelection
        pageSizeOptions={[5, 10, 25]}
        initialState={{
          pagination: { paginationModel: { pageSize: 10, page: 0 } },
        }}
        slotProps={{
          loadingOverlay: { variant: "skeleton", noRowsVariant: "skeleton" },
        }}
        sx={{
          boxShadow: 3,
          borderRadius: 2,
          "& .MuiDataGrid-row:hover": { color: "chocolate" },
          "& .MuiDataGrid-columnHeaderTitle": { fontWeight: 600, fontSize: "18px" },
          "& .MuiDataGrid-row.even":{ backgroundColor: "#fafafa"}
        }}
        
        getRowClassName={(params) =>
          params.indexRelativeToCurrentPage % 2 === 0 ? "even" : "odd"
        }

      />

      {/* ✅ ONE GLOBAL MENU (always opens) */}
      <Menu
        open={Boolean(translateMenuPos)}
        onClose={closeTranslateMenu}
        anchorReference="anchorPosition"
        anchorPosition={
          translateMenuPos !== null
            ? { top: translateMenuPos.mouseY, left: translateMenuPos.mouseX }
            : undefined
        }
        sx={{ zIndex: 4000 }}
      >
        {langOptions.map((l) => (
          <MenuItem
            key={l.code}
            onClick={() => chooseTranslateLang(l.code)}
            sx={{ fontSize: "12px", py: 0.7 }}
          >
            {l.label}
          </MenuItem>
        ))}
      </Menu>
    </Box>
  );
}
