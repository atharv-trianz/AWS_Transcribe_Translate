export async function generateChecksum(chunk: any) {

    const buffer = await chunk.arrayBuffer();
    const hashBuffer = await crypto.subtle.digest('SHA-256', buffer)
    const hashArray = Array.from(new Uint8Array(hashBuffer))

    const binary = hashArray.map(b => String.fromCharCode(b)).join('')
    return btoa(binary)
    
}