import { useState, useEffect, useMemo } from 'react';
import { fetchAuthSession } from 'aws-amplify/auth';
import {
  Flex,
  Heading,
  Button,
} from '@aws-amplify/ui-react';
import { UploadButton } from '../utils/UploadButton';
import { DeleteObjects } from '../utils/DeleteObjects';
import CasesGrid from '../utils/CaseTable';
import { MoveDialog } from '../utils/MoveDialog';
import { MetadataDialog } from '../utils/MetadataDialog';
import { useCases } from '../../hooks/cases';
import { useCreateEvidence } from '../../hooks/useCaseEvidence';
import toast from 'react-hot-toast';
import { IconButton } from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import { resolveUniqueFilename } from '../utils/resolveUniqueFileName';
import { useEvidence } from '../../hooks/useEvidence';
import { useUser } from '../../context/UserContext';

const TEMP_PATH = 'temp/';

export const Temp = () => {
  const [identityId, setIdentityId] = useState<string | null>(null);
  const [files, setFiles] = useState<any[]>([]);
  const [selectedRows, setSelectedRows] = useState<string[]>([]);
  const [droppedFile, setDroppedFile] = useState<File | null>(null);
  const [moveOpen, setMoveOpen] = useState(false);
  const [metaOpen, setMetaOpen] = useState(false);
  const { userInfo } = useUser()
  const { data: cases } = useCases();

  const { data: evidences, refetch: refetchEvidences, isLoading: loadingEvidence } = useEvidence(TEMP_PATH);

  const { mutateAsync: createEvidence } = useCreateEvidence('temp');

  const tempPrefix =`temp/`;

  useEffect(() => {
    if (evidences) setFiles(evidences);
  }, [evidences]);

  const existingEvidenceNumbers = useMemo(() =>
    new Set<string>(
      evidences?.map((ev: any) => ev.evidence_number).filter(Boolean)
    ),
  [evidences]);

  useEffect(() => {
    fetchAuthSession().then(session => {
      setIdentityId(session.identityId ?? null);
    });
  }, []);
  const selectedSingleMeta =
    selectedRows.length === 1
      ? evidences?.find((item) => item.file_name_path === selectedRows[0]) ?? null
      : null;

  const handleSaveMetadata = async (metadata: {
    evidence_number: string;
    description: string;
  }) => {
    if (selectedRows.length !== 1) {
      toast.error('Select exactly one file to edit metadata.');
      return;
    }
    const key = selectedRows[0];
    await createEvidence({
      source_key: key,
      evidence_number: metadata.evidence_number,
      description: metadata.description,
      user_id: userInfo.user_id
    });
    toast.success('Metadata saved');
    await refetchEvidences();
  };

  // Bind cases into the resolver so UploadButton just calls resolveFilename(name)
  const handleResolveFilename = (originalName: string) =>
    resolveUniqueFilename(originalName, TEMP_PATH);

  // Show toast if file was auto-renamed
  const handleUploaded = (uploadedName: string, originalName: string) => {
    if (uploadedName !== originalName) {
      toast(`"${originalName}" already exists — uploaded as "${uploadedName}"`, {
        icon: 'ℹ️',
        duration: 5000,
      });
    }
    setDroppedFile(null);
    setTimeout(() => {
      refetchEvidences();
    }, 1000);
  };

  return (
    <>
      <Flex justifyContent="space-between" alignItems="center" padding="0.75rem 0">
        <Heading level={5}>Temp Files</Heading>
        <Flex gap="0.5rem" alignItems="center">
          {selectedRows.length > 0 && (
            <>
              <Button
                size="small"
                onClick={() => {
                  if (selectedRows.length !== 1) {
                    toast.error('Please select exactly one file to edit metadata.');
                    return;
                  }
                  setMetaOpen(true);
                }}
                isDisabled={selectedRows.length !== 1}
                title={selectedRows.length !== 1 ? 'Select exactly one file to edit metadata' : ''}
              >
                Edit Metadata
              </Button>
              <Button
                size="small"
                variation="primary"
                onClick={() => setMoveOpen(true)}
              >
                Move to Case
              </Button>
            </>
          )}
          <IconButton>
            <RefreshIcon onClick={() => setTimeout(() => refetchEvidences(), 20)} />
          </IconButton>

          <DeleteObjects
            selectedPaths={[...selectedRows]}
            currentCaseNumber="temp"
            selectedEvidenceItems={
              selectedRows
                .map(fp => evidences?.find(ev => ev.file_name_path === fp))
                .filter((Boolean))
                .map(ev => ({ case_number: ev!.case_number, file_name_path: ev!.file_name_path }))
            }
            onDeleted={() => {
              setTimeout(() => refetchEvidences(), 20);
            }}
          />
          {tempPrefix && (
            <UploadButton
              prefix={`${userInfo.user_id}/${tempPrefix}`}
              droppedFile={droppedFile}
              onClearDroppedFile={() => setDroppedFile(null)}
              resolveFilename={handleResolveFilename}
              onUploaded={handleUploaded}
              cases={cases ?? []}
            />
          )}
        </Flex>
      </Flex>
      <CasesGrid
        data={files}
        loading={loadingEvidence}
        handleRowClick={() => {}}
        viewMode="files"
        handleSelected={(selected: any) => setSelectedRows(selected)}
        onFileDrop={(file) => setDroppedFile(file)}
      />
      {moveOpen && identityId && (
        <MoveDialog
          open={moveOpen}
          files={selectedRows}
          identityId={identityId}
          cases={cases ?? []}
          tempEvidence={(evidences ?? []).map(ev => ({
            source_key: ev.file_name_path,
            file_name_path: ev.file_name_path,
            evidence_number: ev.evidence_number,
        
            description: ev.description,
          }))}
          onClose={() => setMoveOpen(false)}
          onMoved={() => {
            setSelectedRows([]);
            setTimeout(() => refetchEvidences(), 20);
          }}
        />
      )}
      {metaOpen && selectedRows.length === 1 && (
        <MetadataDialog
          open={metaOpen}
          files={selectedRows}
          initialMetadata={selectedSingleMeta ? {
            evidence_number: selectedSingleMeta.evidence_number,
            description: selectedSingleMeta.description,
          } : undefined}
          cases={cases ?? []}
          existingEvidenceNumbers={existingEvidenceNumbers}
          onClose={() => setMetaOpen(false)}
          onSave={handleSaveMetadata}
        />
      )}
    </>
  );
};