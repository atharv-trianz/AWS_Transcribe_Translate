import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Flex,
  Heading,
  Divider,
  Button,
} from "@aws-amplify/ui-react";
import { UploadButton } from "../utils/UploadButton";
import Breadcrumbs from "../utils/Breadcrumbs"
import { useReceivedCases, useCases } from '../../hooks/cases';
import { useUser } from '../../context/UserContext';
// import { useListS3Objects } from '../../hooks/lists3objects';
import { useCreateEvidence } from '../../hooks/useCaseEvidence';
import { resolveUniqueFilename } from '../utils/resolveUniqueFileName';
import CasesGrid from '../utils/CaseTable';
import { CreateFolder } from '../utils/CreateFolder';
import { MetadataDialog } from '../utils/MetadataDialog';
import { IconButton } from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import toast from 'react-hot-toast';
import { useLocation } from 'react-router-dom';
import { useEvidence } from '../../hooks/useEvidence';

export const Received = () => {
  const { userInfo } = useUser()
  // const [filesLoading, setFilesLoading] = useState(true);
  const {data: receivedCases, refetch: refetchReceivedCases, isLoading: casesLoading} = useReceivedCases(userInfo.user_id)
  const cases = receivedCases?.cases;
  const [currentUserId, setCurrentUserId] = useState<string>('')

  const { data: allCases } = useCases();
  const [files, setFiles] = useState<any[]>([]);
  const [baseKey, setBaseKey] = useState<string | null>(null);
  const [activeCase, setActiveCase] = useState<null | {
    caseNumber: string;
    canWrite: boolean;
  }>(null);
  const isInsideCase = activeCase !== null;
  const [pathStack, setPathStack] = useState<string[]>([]);
  const currentPath = pathStack.join('');
  const [selectedRows, setSelectedRows] = useState<string[]>([]);
  const [droppedFile, setDroppedFile] = useState<File | null>(null);
  const [metaOpen, setMetaOpen] = useState(false);
  const currentCaseNumber = pathStack.length > 0 ? pathStack[0].replace('/', '') : null;
  // const {
  //   data: evidenceData,
  //   // refetch: refetchEvidence,
  // } = useCaseEvidence(currentCaseNumber ?? '');
  const { mutateAsync: createEvidence } = useCreateEvidence(currentCaseNumber ?? '');

  // const evidenceByKey = useMemo(() => {
  //   const map = new Map<string, any>();
  //   evidenceData?.items?.forEach(ev => {
  //     map.set(ev.source_key, ev);
  //     const filename = ev.source_key?.split('/').pop();
  //     if (filename) map.set(filename, ev);
  //   });
  //   return map;
  // }, [evidenceData]);

  const location = useLocation()
  const caseToOpenThroughLink = location.state?.case_number
  useEffect(() => {
    if(!caseToOpenThroughLink) return;
    const row = receivedCases?.cases.filter(item => item.case_number === `${caseToOpenThroughLink}`)
    
    if(row && row.length > 0){
      handleRowClick({row: row[0]})
    }
  }, [receivedCases, caseToOpenThroughLink])

  const existingEvidenceNumbers = useMemo(() =>
    new Set<string>(
      files?.map((ev: any) => ev.evidence_number).filter(Boolean)
    ),
  [files]);

  // const normalizedBaseKey = baseKey
  //   ? baseKey.endsWith('/') ? baseKey : `${baseKey}/`
  //   : null;
  // const currentPrefix = normalizedBaseKey
  //   ? `${normalizedBaseKey}${pathStack.length ? pathStack.join('') : ''}`
  //   : null;
  
    console.log('currentPath in received tab: ', currentPath)
  const { data: evidences, refetch: refetchEvidences, isLoading: loadingEvidence } = useEvidence(currentPath)
  console.log('evidences in received tab: ', evidences)
  useEffect(() => {
    if(evidences)
      setFiles(evidences)
  }, [evidences])
  // const { data: receivedFiles, refetch: refetchS3Objects } = useListS3Objects(currentPrefix);
  const isRoot = baseKey === null;
  const viewMode = isRoot ? "received" : "files";
  // useEffect(() => {
  //   if (!receivedFiles) return;
  //   setFilesLoading(true);
  //   try {
  //     const mergedItems = receivedFiles.map((item) => {
  //       if (item.type === "folder") return item;
  //       const fullKey = item.Key;
  //       const fileName = fullKey.split("/").pop() || '';
  //       const metadata =
  //         evidenceByKey.get(fullKey) ||
  //         evidenceByKey.get(fileName) ||
  //         null;
  //       return { ...item, ...metadata };
  //     });
  //     setFiles(mergedItems);
  //   } catch (err) {
  //     console.error("Error listing files", err);
  //   } finally {
  //     setFilesLoading(false);
  //   }
  // }, [receivedFiles, evidenceByKey, currentPath]);

  const removeLastPathSegment = (key: string) => {
    if (!key) return key;
    const normalized = key.endsWith('/') ? key.slice(0, -1) : key;
    return normalized.substring(0, normalized.lastIndexOf('/') + 1);
  };

  // function handleRowClick(params: any) {
  //   const row = params.row;
  //   // setFilesLoading(true);
  //   if (viewMode === 'received') {
  //     setBaseKey(removeLastPathSegment(row.source_key));
  //     setPathStack([`${row.case_number}/`]);
  //     setActiveCase({
  //       caseNumber: row.case_number,
  //       canWrite: row.permissions === "Read / Update" ? true : false,
  //     });
  //     setCurrentUserId(row.owner_id)
  //   } else {
  //     setPathStack(prev => [...prev, `${row.name}/`]);
  //   }
  // }

  const clickLockedRef = useRef(false);
 
function handleRowClick(params: any) {
  if (clickLockedRef.current) return;
  clickLockedRef.current = true;
 
  const row = params.row;
 
  setTimeout(() => {
    if (viewMode === 'received') {
      setBaseKey(removeLastPathSegment(row.source_key));
      setPathStack([`${row.case_number}/`]);
      setActiveCase({
        caseNumber: row.case_number,
        canWrite: row.permissions === 'Read / Update'? true : false,
      });
      setCurrentUserId(row.owner_id);
    } else {
      setPathStack(prev => [...prev, `${row.name}/`]);
    }
  }, 0);
 
  setTimeout(() => {
    clickLockedRef.current = false;
  }, 300);
}
 
  // const selectedSingleMeta =
  //   selectedRows.length === 1
  //     ? evidenceByKey.get(selectedRows[0]) ?? null
  //     : null;
  const selectedSingleMeta = selectedRows.length === 1
      ? evidences?.filter((item) => item.file_name_path === selectedRows[0])[0] ?? null: null

    
  const handleSaveMetadata = async (metadata: {
    evidence_number: string;
    description: string;
  }) => {
    if (selectedRows.length !== 1) {
      toast.error('Select exactly one file to edit metadata.');
      return;
    }
    const key = selectedRows[0];
    await createEvidence({
      source_key: key,
      evidence_number: metadata.evidence_number,
      description: metadata.description,
      user_id: userInfo.user_id
    });
    toast.success('Metadata saved');
    refetchEvidences();
    // setTimeout(() => refetchS3Objects(), 100);
  };
  const handleResolveFilename = (originalName: string) =>
    resolveUniqueFilename(originalName, currentPath);
  const handleUploaded = (uploadedName: string, originalName: string) => {
    if (uploadedName !== originalName) {
      toast(`"${originalName}" already exists — uploaded as "${uploadedName}"`, {
        icon: 'ℹ️',
        duration: 5000,
      });
    }
    setDroppedFile(null);
    if (currentCaseNumber) {
      setTimeout(() => {
        refetchEvidences();
        // refetchS3Objects();
      }, 500);
    }
  };

  return (
    <>
      <Flex justifyContent="space-between" alignItems="center" padding="0.75rem 0">
        <Heading level={5}>Files</Heading>

        <Flex gap="0.5rem">
          {isRoot && (
            <IconButton>
              <RefreshIcon onClick={() => {
                console.log('refreshingg...')
                refetchReceivedCases()
              }} />
            </IconButton>
          )}
          {!isRoot && (
            <IconButton>
              <RefreshIcon onClick={() => {
                // refetchS3Objects();
                setTimeout(() => refetchEvidences(), 20);
              }} />
            </IconButton>
          )}
          {isInsideCase && activeCase.canWrite && selectedRows.length === 1 && (
            <Button
              size="small"
              onClick={() => setMetaOpen(true)}
            >
              Edit Metadata
            </Button>
          )}
          {isInsideCase && activeCase.canWrite && (
            <CreateFolder
              basePath={`${baseKey}${pathStack.join('')}`}
              receivedTab={true}
              onCreated={() => refetchEvidences()}
            />
          )}
          {isInsideCase && activeCase.canWrite && (
            <UploadButton
              prefix={`${currentUserId}/${pathStack.join('')}`}
              droppedFile={droppedFile}
              onClearDroppedFile={() => setDroppedFile(null)}
              resolveFilename={handleResolveFilename}
              onUploaded={handleUploaded}
              cases={allCases ?? []}
            />
          )}
        </Flex>
      </Flex>

      <Divider />

      <Breadcrumbs
        pathStack={pathStack}
        onNavigate={(x: string[]) => {
          // setFilesLoading(true);
          setPathStack(x);
        }}
        onExitCase={() => {
          setActiveCase(null);
          setFiles([]);
          setBaseKey(null);
          // setFilesLoading(true);
          setPathStack([]);
          setSelectedRows([]);
          setCurrentUserId('')
        }}
      />

      <CasesGrid
        data={viewMode === "received" ? cases || [] : files || []}
        loading={viewMode === "received" ? casesLoading : loadingEvidence}
        handleRowClick={handleRowClick}
        viewMode={viewMode}
        handleSelected={(selected: any) => setSelectedRows(selected)}
        onFileDrop={(file) => {
          if (isInsideCase && activeCase.canWrite) setDroppedFile(file);
        }}
      />
      {isInsideCase && activeCase.canWrite && metaOpen && selectedRows.length === 1 && (
        <MetadataDialog
          open={metaOpen}
          files={selectedRows}
          initialMetadata={selectedSingleMeta ?? undefined}
          caseNumber={currentCaseNumber ?? ''}
          existingEvidenceNumbers={existingEvidenceNumbers}
          onClose={() => setMetaOpen(false)}
          onSave={handleSaveMetadata}
        />
      )}
    </>
  );
};

export default Received;