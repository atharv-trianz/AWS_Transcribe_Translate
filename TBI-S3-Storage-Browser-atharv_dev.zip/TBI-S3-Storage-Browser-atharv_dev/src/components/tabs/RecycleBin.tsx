import { useState } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Typography, Chip, Tooltip,
} from '@mui/material';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import { Button } from '@aws-amplify/ui-react';
import { useQuery } from '@tanstack/react-query';
import { EvidenceAPI } from '../../api/evidence/evidence.api';
import { useRestoreEvidence } from '../../hooks/useDeleteEvidence';
import toast from 'react-hot-toast';
import FolderIcon from '@mui/icons-material/Folder';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import { Box } from '@mui/material';

export const RecycleBin = () => {
  const [selectedRows, setSelectedRows] = useState<string[]>([]);
  const [restoreOpen, setRestoreOpen] = useState(false);
  // Items the backend said cannot be restored due to missing source path
  const [notRestorableItems, setNotRestorableItems] = useState<{ item: string; reason: string }[]>([]);
  const [resultOpen, setResultOpen] = useState(false);

  const { data: deletedItems, isLoading, refetch } = useQuery({
    queryKey: ['recycle-bin'],
    queryFn: () => EvidenceAPI.getDeletedEvidence(),
    refetchOnMount: 'always',
  });

  const { mutateAsync: restoreEvidence, isPending: restoring } = useRestoreEvidence();

  const rows = (deletedItems ?? []).map(item => ({
    id: item.file_name_path,
    name: item.name,
    isFolder: item.type === 'FOLDER',
    case_number: item.case_number,
    evidence_number: item.evidence_number || '—',
    description: item.description || '—',
    deleted_at: item.deleted_at ? new Date(item.deleted_at).toLocaleString() : '—',
    file_name_path: item.file_name_path,
    daysLeft: item.deleted_at
      ? Math.max(0, 30 - Math.floor((Date.now() - new Date(item.deleted_at).getTime()) / (1000 * 60 * 60 * 24)))
      : 30,
  }));

  const columns: GridColDef[] = [
    {
      field: 'name',
      headerName: 'File Name',
      flex: 1.5,
      renderCell: (params) => {
        const isFolder = params.row.isFolder;
        return (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            {isFolder
              ? <FolderIcon sx={{ fontSize: 18, color: '#f59e0b' }} />
              : <InsertDriveFileIcon sx={{ fontSize: 18, color: '#64748b' }} />
            }
            {params.value}
          </Box>
        );
      },
    },
    { field: 'case_number', headerName: 'Case', flex: 1 },
    { field: 'evidence_number', headerName: 'Evidence No.', flex: 1 },
    { field: 'description', headerName: 'Description', flex: 1 },
    { field: 'deleted_at', headerName: 'Deleted At', flex: 1 },
    {
      field: 'daysLeft',
      headerName: 'Expires In',
      flex: 0.8,
      renderCell: (params) => (
        <Chip
          label={`${params.value}d`}
          size="small"
          color={params.value <= 7 ? 'error' : params.value <= 14 ? 'warning' : 'default'}
        />
      ),
    },
  ];

  const handleRestore = async () => {
    const itemsToRestore = selectedRows.map(fp => {
      const item = deletedItems?.find(i => i.file_name_path === fp);
      return { case_number: item!.case_number, file_name_path: fp };
    });
    try {
      const result = await restoreEvidence({ items: itemsToRestore });

      if (result.restored.length > 0) {
        toast.success(`${result.restored.length} item(s) restored successfully`);
      }

      // Some items could not be restored because their source path is gone
      if (result.not_restorable && result.not_restorable.length > 0) {
        setNotRestorableItems(result.not_restorable);
        setResultOpen(true);
      }

      if (result.failed && result.failed.length > 0) {
        toast.error(`${result.failed.length} item(s) failed to restore`);
      }

      setSelectedRows([]);
      setRestoreOpen(false);
      refetch();
    } catch {
      toast.error('Failed to restore items');
    }
  };

  return (
    <>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
        <Typography variant="body2" color="text.secondary">
          Items are permanently deleted after 30 days.
        </Typography>
        <Tooltip
          title={selectedRows.length === 0 ? 'Select items to restore' : ''}
          arrow
        >
          <span>
            <Button
              size="small"
              variation="primary"
              isDisabled={selectedRows.length === 0}
              onClick={() => setRestoreOpen(true)}
            >
              Restore ({selectedRows.length})
            </Button>
          </span>
        </Tooltip>
      </div>

      <div style={{ height: 480, width: '100%' }}>
        <DataGrid
          loading={isLoading}
          rows={rows}
          columns={columns}
          checkboxSelection
          disableRowSelectionOnClick
          // No row navigation in RecycleBin — clicking a row does nothing
          onRowClick={() => {}}
          onRowSelectionModelChange={(model) => {
            if (model.type === 'include') {
              setSelectedRows(Array.from(model.ids).map(String));
            } else if (model.type === 'exclude') {
              const allIds = rows
                .filter(row => !model.ids.has(row.id))
                .map(r => String(r.id));
              setSelectedRows(allIds);
            }
          }}
          pageSizeOptions={[10, 25]}
          initialState={{ pagination: { paginationModel: { pageSize: 10 } } }}
          slotProps={{
            loadingOverlay: { variant: 'skeleton', noRowsVariant: 'skeleton' },
          }}
          sx={{
            boxShadow: 3,
            borderRadius: 2,
            // Remove pointer cursor and hover underline — no navigation here
            '& .MuiDataGrid-row': { cursor: 'default' },
            '& .MuiDataGrid-columnHeaderTitle': { fontWeight: 600, fontSize: '16px' },
          }}
        />
      </div>

      {/* Restore confirm dialog */}
      <Dialog open={restoreOpen} onClose={() => setRestoreOpen(false)}>
        <DialogTitle>Restore Items</DialogTitle>
        <DialogContent>
          <Typography>
            Restore {selectedRows.length} item(s) back to their original location?
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            Items whose source folder has been deleted cannot be restored and will be reported after the operation.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button variation="link" onClick={() => setRestoreOpen(false)}>Cancel</Button>
          <Button
            variation="primary"
            onClick={handleRestore}
            isLoading={restoring}
            loadingText="Restoring..."
          >
            Restore
          </Button>
        </DialogActions>
      </Dialog>
      {/* Not-restorable result dialog */}
      <Dialog open={resultOpen} onClose={() => setResultOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Some Items Could Not Be Restored</DialogTitle>
        <DialogContent>
          <Typography variant="body2" color="text.secondary" gutterBottom>
            The following items could not be restored because their source folder no longer exists:
          </Typography>
          <Box sx={{ mt: 1, display: 'flex', flexDirection: 'column', gap: 1 }}>
            {notRestorableItems.map(({ item, reason }) => (
              <Box
                key={item}
                sx={{
                  p: 1.5,
                  borderRadius: 1,
                  bgcolor: '#fff4e5',
                  border: '1px solid #f59e0b',
                }}
              >
                <Typography variant="body2" fontWeight={600} noWrap>
                  {item.split('/').filter(Boolean).pop()}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {reason}
                </Typography>
              </Box>
            ))}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button variation="primary" onClick={() => setResultOpen(false)}>
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};
