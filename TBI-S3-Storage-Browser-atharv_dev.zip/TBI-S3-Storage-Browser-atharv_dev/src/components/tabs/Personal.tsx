import { useEffect, useState, useMemo, useRef } from 'react';
import { fetchAuthSession } from 'aws-amplify/auth';
import { Flex, Heading, Button } from "@aws-amplify/ui-react";
import { UploadButton } from "../utils/UploadButton";
import { DeleteObjects } from "../utils/DeleteObjects";
import { CreateCase } from '../utils/CreateCase';
import { CreateFolder } from '../utils/CreateFolder';
import Breadcrumbs from "../utils/Breadcrumbs";
import { useCases, useShareCaseTo, useShareExternal } from '../../hooks/cases';
import { useCreateEvidence } from '../../hooks/useCaseEvidence';
import CasesGrid from '../utils/CaseTable';
import ShareDialog from '../utils/ShareDialog';
import { MetadataDialog } from '../utils/MetadataDialog';
import { useUser } from '../../context/UserContext';
import { useCognitoUser } from '../../hooks/users';
import toast from 'react-hot-toast';
import { IconButton } from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import { resolveUniqueFilename } from '../utils/resolveUniqueFileName';
import { useLocation } from "react-router-dom";
import { useEvidence } from '../../hooks/useEvidence';

import { apiClient } from "../../api/client";

/** ✅ Minimal type for polling + status checks */
type EvidenceItem = {
  case_number?: string;
  file_name_path: string;
  name?: string;
  evidence_number?: string;
  description?: string;
  transcribeStatus?: string;
  transcribeError?: string;
  transcribe_latest_version?: number;
  transcribe_versions?: Record<string, any>;

  translateStatus?: string;
  translateError?: string;
};

export const Personal = () => {
  const [files, setFiles] = useState<any[]>([]);
  const [identityId, setIdentityId] = useState<string | null>(null);
  const [pathStack, setPathStack] = useState<string[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const [selectedRows, setSelectedRows] = useState<string[]>([]);
  const [casesLoading, setCasesLoading] = useState(true);

  const [droppedFile, setDroppedFile] = useState<File | null>(null);
  const [metaOpen, setMetaOpen] = useState(false);
  const [open, setOpen] = useState(false);
  const [isGeneratingLink, setIsGeneratingLink] = useState(false);

  const { mutateAsync: shareExternal } = useShareExternal();
  const { userInfo } = useUser();

  const currentPath = pathStack.join('');
  const currentCaseNumber =
    pathStack.length > 0 ? pathStack[0].replace('/', '') : null;

  const { data: evidences, refetch: refetchEvidences, isLoading: loadingEvidence } =
    useEvidence(currentPath) as {
      data: EvidenceItem[] | undefined;
      refetch: () => Promise<any>;
      isLoading: boolean;
    };

  /** ✅ Fix stale closure: polling loop always reads latest evidences */
  const evidencesRef = useRef<EvidenceItem[]>([]);
  useEffect(() => {
    evidencesRef.current = evidences ?? [];
  }, [evidences]);

  useEffect(() => {
    if (evidences) setFiles(evidences);
  }, [evidences]);

  const { mutateAsync: createEvidence } = useCreateEvidence(currentCaseNumber ?? '');
  const isRoot = pathStack.length === 0;
  const viewMode = isRoot ? "cases" : "files";

  const selectedFiles = [...selected].filter(p => !p.endsWith("/"));
  const selectedFolders = [...selected].filter(p => p.endsWith("/"));

  const { data: cases, refetch: refetchCases, isLoading } = useCases();
  const { mutate: shareCaseTo } = useShareCaseTo();

  const location = useLocation();
  const caseToOpenThroughLink = location.state?.case_number;

  useEffect(() => {
    if (!caseToOpenThroughLink) return;
    const row = cases?.filter(item => item.case_number === `${caseToOpenThroughLink}`);
    if (row && row.length > 0) handleRowClick({ row: row[0] });
  }, [cases]);

  useEffect(() => {
    if (!isLoading) setCasesLoading(false);
    if (cases && cases?.length > 0) setCasesLoading(false);
  }, [cases, isLoading]);

  const { data: cognitoUsers } = useCognitoUser();
  const filteredUsers = cognitoUsers?.filter(item => item.email != userInfo.email);
  const users = filteredUsers;

  const existingEvidenceNumbers = useMemo(() =>
    new Set<string>(
      (evidences ?? []).map((ev: any) => ev.evidence_number).filter(Boolean)
    ),
  [evidences]);

  const currentFolderPrefix = identityId ? `private/${identityId}/${currentPath}` : null;
  const rootFolderPrefix = identityId ? `private/${identityId}/` : null;
  const canGenerateLink =
    selectedFiles.length > 0 ||
    selectedFolders.length === 1 ||
    !!currentFolderPrefix ||
    !!rootFolderPrefix;

  useEffect(() => {
    async function init() {
      const session = await fetchAuthSession();
      setIdentityId(session.identityId ?? null);
    }
    init();
  }, []);

const clickLockedRef = useRef(false);
function handleRowClick(params: any) {
  if (clickLockedRef.current) return;
  clickLockedRef.current = true;
  const row = params.row;
  setTimeout(() => {
    let name: string;

    if (viewMode === 'cases') {
      name = row.case_number;
      setPathStack([`${name}/`]);
    } else {
      name = row.name;
      setPathStack(prev => [...prev, `${name}/`]);
    }
    setSelected(new Set());
  }, 0);
  setTimeout(() => {
    clickLockedRef.current = false;
  }, 300);
}

  const extractCaseNumber = (path: string) => {
    const parts = path.split("/");
    return parts[parts.length - 2];
  };

  const selectedSingleMeta =
    selectedRows.length === 1
      ? (evidencesRef.current.find((item) => item.file_name_path === selectedRows[0]) ?? null)
      : null;

  const handleSaveMetadata = async (metadata: {
    evidence_number: string;
    description: string;
  }) => {
    if (selectedRows.length !== 1) {
      toast.error('Select exactly one file to edit metadata.');
      return;
    }

    const key = selectedRows[0];
    await createEvidence({
      source_key: key,
      evidence_number: metadata.evidence_number,
      description: metadata.description,
      user_id: userInfo.user_id
    });

    toast.success('Metadata saved');
    refetchEvidences();
  };
  console.log("currrrrrrrrrentPath", currentPath);
  const handleResolveFilename = (originalName: string) =>
    resolveUniqueFilename(originalName, currentPath);

  const handleUploaded = (uploadedName: string, originalName: string) => {
    if (uploadedName !== originalName) {
      toast(`"${originalName}" already exists — uploaded as "${uploadedName}"`, {
        icon: 'ℹ️',
        duration: 5000,
      });
    }
    setDroppedFile(null);
    setTimeout(() => refetchEvidences(), 1000);
  };

  /** ✅ Optimistic update: start spinner immediately */
  const setRowTranscribeInProgress = (fileNamePath: string) => {
    setFiles((prev: any[]) =>
      prev.map((r: any) =>
        (r.file_name_path === fileNamePath || r.id === fileNamePath)
          ? { ...r, transcribeStatus: "IN_PROGRESS" }
          : r
      )
    );
  };

  /**
   * ✅ Poll until THIS EXACT version's pdfKey exists.
   * This prevents "generated" toast from old versions.
   */
  const waitForTranscribePdfForVersion = async (opts: {
    fileNamePath: string;
    expectedVersion: number;
    maxAttempts?: number;
    intervalMs?: number;
  }) => {
    const { fileNamePath, expectedVersion, maxAttempts = 100, intervalMs = 3000 } = opts;
    const vkey = `v${expectedVersion}`;

    const getRow = (): EvidenceItem | undefined =>
      evidencesRef.current.find((x) => x.file_name_path === fileNamePath);

    for (let i = 0; i < maxAttempts; i++) {
      await refetchEvidences();

      const row = getRow();
      const status = String(row?.transcribeStatus || "").toUpperCase();

      if (status === "FAILED") {
        return { ok: false, status: "FAILED", error: row?.transcribeError };
      }

      const pdfKey = row?.transcribe_versions?.[vkey]?.pdfKey;
      if (status === "COMPLETED" && pdfKey) {
        return { ok: true, status: "COMPLETED", pdfKey };
      }

      await new Promise((r) => setTimeout(r, intervalMs));
    }

    return { ok: false, status: "TIMEOUT" };
  };

  const handleTranscribe = async (row: any, force: boolean, enhanced: boolean = false) => {
  if (!currentCaseNumber) {
    toast.error("Case number missing");
    return;
  }

  const fileNamePath = row?.file_name_path || row?.id;
  if (!fileNamePath) {
    toast.error("file_name_path missing");
    return;
  }

  const toastId = `transcribe-${fileNamePath}`;

  try {
    toast.loading(enhanced ? "Enhanced re-transcribe started..." : "Transcribe started...", { id: toastId });
    setRowTranscribeInProgress(fileNamePath);

    const resp = await apiClient.post(
      `/cases/${currentCaseNumber}/evidence/transcribe`,
      {
        file_name_path: fileNamePath,
        force: !!force,
        enhanced: !!enhanced,   // ✅ THIS IS THE KEY FIX
      }
    );

    const startedVersion = Number(resp?.data?.version);

    toast.success(enhanced ? "Enhanced re-transcribe started" : "Transcribe started", { id: toastId });

    if (!startedVersion || Number.isNaN(startedVersion)) {
      await refetchEvidences();
      return;
    }
    const result = await waitForTranscribePdfForVersion({
      fileNamePath,
      expectedVersion: startedVersion,
      maxAttempts: 120,
      intervalMs: 3000,
    });
    if (result.ok) {
      toast.success("Transcribed PDF generated. Open Transcribe folder.", { id: toastId });
      await refetchEvidences();
      return;
    }
    if (result.status === "FAILED") {
      toast.error(`Transcribe failed: ${result.error || "Unknown error"}`, { id: toastId });
      await refetchEvidences();
      return;
    }

    toast(`Still processing… please refresh after some time`, { id: toastId });
    await refetchEvidences();

  } catch (err: any) {
    const msg = err?.response?.data?.message || err?.message || "Failed to start transcription";
    toast.error(msg, { id: toastId });
    await refetchEvidences();
  }
};
  /** Translate (kept simple like your existing flow; can also do version-aware later) */
  const handleTranslate = async (row: any, targetLang: string, force: boolean) => {
    try {
      if (!currentCaseNumber) {
        toast.error("Case number missing");
        return;
      }

      const fileNamePath = row?.file_name_path || row?.id;
      if (!fileNamePath) {
        toast.error("file_name_path missing");
        return;
      }

      if (!targetLang) {
        toast.error("Target language required");
        return;
      }

      const toastId = `translate-${fileNamePath}-${targetLang}`;
      toast.loading(`Translate started (${targetLang})...`, { id: toastId });

      await apiClient.post(`/cases/${currentCaseNumber}/evidence/translate`, {
        file_name_path: fileNamePath,
        targetLang,
        force: !!force,
      });

      // ✅ Start notification (same toast id)
      toast.success(`Translate started(${targetLang})`, { id: toastId });

      // Poll until translateStatus becomes COMPLETED or a translate pdf row appears in folder listing
      for (let i = 0; i < 80; i++) {
        await refetchEvidences();
        const list = evidencesRef.current;

        const rowNow = list.find(x => x.file_name_path === fileNamePath);
        const st = String(rowNow?.translateStatus || "").toUpperCase();

        const pdfFound = list.some(x => {
          const n = (x?.name || "").toLowerCase();
          const fnp = (x?.file_name_path || "");
          return n.includes(`_${targetLang.toLowerCase()}_v`) && n.endsWith("_translate.pdf") && fnp.includes("/Translate/");
        });

        if (st === "FAILED") {
          toast.error(`Translation failed: ${rowNow?.translateError || "Unknown error"}`, { id: toastId });
          return;
        }
        if (st === "COMPLETED" || pdfFound) {
          toast.success(`Translation PDF generated. Open Translate folder. (${targetLang})`, { id: toastId });
          return;
        }

        await new Promise(r => setTimeout(r, 3000));
      }

      toast(`⏳ Translation still processing… please refresh after some time`, { id: toastId });

    } catch (err: any) {
      const msg = err?.response?.data?.message || err?.message || "Failed to translate";
      toast.error(msg);
      await refetchEvidences();
    }
  };

  // ✅ Language options (Hindi + more)
  const translateLanguageOptions = useMemo(() => ([
    { code: "en", label: "English (en)" },
    { code: "es", label: "Spanish (es)" },
    // { code: "hi", label: "Hindi (hi)" },
    { code: "fr", label: "French (fr)" },
    { code: "de", label: "German (de)" },
    { code: "ar", label: "Arabic (ar)" },
    { code: "zh", label: "Chinese (zh)" },
    { code: "vi", label: "Vietnamese (vi)" },
  ]), []);

  return (
    <>
      <Flex justifyContent="space-between" alignItems="center" padding="0.75rem 0">
        <Heading level={5}>Files</Heading>

        <Flex gap="0.5rem">
          {isRoot && (
            <Button size='small' onClick={() => setOpen(true)} disabled={selectedRows.length === 0}>
              Share
            </Button>
          )}

          {open && (
            <ShareDialog
              open={open}
              users={users}
              selectedFiles={selectedRows}
              sharedTo={
                selectedRows.length === 1
                  ? cases?.find(c => c.case_number === extractCaseNumber([...selectedRows][0]))?.shared_to
                  : []
              }
              onClose={() => setOpen(false)}
              onShare={async (payload) => {
                try {
                  const now = new Date().toISOString();

                  if (payload.mode === 'internal' && payload.users) {
                    const items: any[] = [];
                    for (const file of payload.files) {
                      const caseNumber = extractCaseNumber(file);
                      const caseMeta = cases?.find(c => c.case_number === caseNumber);
                      if (!caseMeta) continue;

                      for (const user of payload.users) {
                        items.push({
                          receiver_user_id: `RECEIVER#${user.user_name}`,
                          case_number: `${caseNumber}`,
                          gsi1pk: `OWNER#${userInfo.user_id}`,
                          gsi1sk: `CASE#${caseNumber}#RECEIVER#${user.user_name}`,
                          receiver_user: user.user_name,
                          receiver_email: user.email,
                          owner_user: userInfo.user_id,
                          case_title: caseMeta.case_title,
                          jurisdiction: caseMeta.jurisdiction,
                          case_agents: caseMeta.case_agents,
                          source_key: caseMeta.source_key,
                          owner_email: caseMeta.email,
                          permissions: { read: user.read, write: user.write },
                          division: caseMeta.division,
                          unit: caseMeta.unit,
                          squad: caseMeta.squad,
                          shared_at: now
                        });
                      }
                    }
                    await shareCaseTo(items);
                    setOpen(false);
                  }

                  if (payload.mode === 'external' && payload.externalEmails) {
                    for (const file of payload.files) {
                      const caseNumber = extractCaseNumber(file);
                      const caseMeta = cases?.find(c => c.case_number === caseNumber);
                      if (!caseMeta) continue;

                      const frontendUrl = window.location.origin;
                      const secureViewPath = `/secure-view?prefix=${encodeURIComponent(file)}`;
                      const wrappedUrl = `${frontendUrl}/external-login?redirect=${encodeURIComponent(secureViewPath)}`;

                      for (const ext of payload.externalEmails) {
                        await shareExternal({
                          case_number: caseNumber,
                          file,
                          email: ext.email,
                          wrapped_url: wrappedUrl,
                          case_title: caseMeta.case_title,
                          case_agents: caseMeta.case_agents,
                          jurisdiction: caseMeta.jurisdiction,
                          owner: userInfo.user_id,
                          owner_email: caseMeta.email,
                          permissions: { read: true, write: false },
                          shared_at: now
                        });
                      }
                    }
                  }
                } catch (err) {
                  console.error("Share failed:", err);
                }
              }}
            />
          )}

          {isRoot && (
            <Button
              size="small"
              variation="primary"
              isLoading={isGeneratingLink}
              loadingText="Generating link..."
              disabled={isGeneratingLink || !canGenerateLink}
              onClick={async () => {
                try {
                  const selectedArray = Array.from(selectedRows);
                  if (!selectedArray.length) return;
                  const fullPath = selectedArray[0];
                  const trimmedPath = fullPath.replace(/\/$/, "");
                  const parts = trimmedPath.split("/");
                  const case_number = parts[parts.length - 1];
                  const link = `${window.location.origin}/access/${case_number}`;
                  await navigator.clipboard.writeText(link);
                  toast.success("Link copied to clipboard!");
                } catch (err) {
                  console.error(err);
                } finally {
                  setIsGeneratingLink(false);
                }
              }}
            >
              Generate link
            </Button>
          )}

          {!isRoot && (
            <IconButton>
              <RefreshIcon onClick={() => {
                setTimeout(() => refetchEvidences(), 20);
              }} />
            </IconButton>
          )}

          {isRoot && (
            <IconButton>
              <RefreshIcon onClick={() => {
                refetchCases();
              }} />
            </IconButton>
          )}

          {!isRoot && selectedRows.length === 1 && (
            <Button size="small" onClick={() => setMetaOpen(true)}>
              Edit Metadata
            </Button>
          )}

          {isRoot ? (
            <CreateCase basePath={`${currentPath}`} />
          ) : (
            <CreateFolder basePath={`${currentPath}`} onCreated={() => {}} />
          )}
       
          <DeleteObjects
            selectedPaths={[...selectedRows]}
            currentCaseNumber={currentCaseNumber}
            selectedEvidenceItems={
              !isRoot
                ? selectedRows
                    .map(fp => evidences?.find(ev => ev.file_name_path === fp))
                    .filter((ev): ev is EvidenceItem & { case_number: string } => Boolean(ev) && typeof ev?.case_number === 'string')
                    .map(ev => ({ case_number: ev!.case_number, file_name_path: ev!.file_name_path }))
                : undefined
            }
            onDeleted={() => setTimeout(() => refetchEvidences(), 20)}
          />

          {identityId && !isRoot && (
            <UploadButton
              prefix={`${userInfo.user_id}/${currentPath}`}
              droppedFile={droppedFile}
              onClearDroppedFile={() => setDroppedFile(null)}
              resolveFilename={handleResolveFilename}
              onUploaded={handleUploaded}
            />
          )}
        </Flex>
      </Flex>

      <Breadcrumbs
        pathStack={pathStack}
        onNavigate={(x: string[]) => setPathStack(x)}
        onExitCase={() => setPathStack([])}
      />

      <CasesGrid
        data={viewMode === "cases" ? cases || [] : files || []}
        loading={viewMode === "cases" ? casesLoading : loadingEvidence}
        handleRowClick={handleRowClick}
        viewMode={viewMode}
        handleSelected={(selected: any) => setSelectedRows(selected)}
        onFileDrop={(file) => setDroppedFile(file)}
        onTranscribe={handleTranscribe}
        onTranslate={handleTranslate}
        translateLanguageOptions={translateLanguageOptions}
      />

      {metaOpen && selectedRows.length === 1 && (
        <MetadataDialog
          open={metaOpen}
          files={selectedRows}
          initialMetadata={selectedSingleMeta ?? undefined}
          caseNumber={currentCaseNumber ?? ''}
          existingEvidenceNumbers={existingEvidenceNumbers}
          onClose={() => setMetaOpen(false)}
          onSave={handleSaveMetadata}
        />
      )}
    </>
  );
};