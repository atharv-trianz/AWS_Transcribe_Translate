import { useEffect, useState, useRef, useMemo } from 'react';
import { fetchAuthSession } from 'aws-amplify/auth';
import {
  Flex,
  Heading,
  Button,
} from "@aws-amplify/ui-react";
import { UploadButton } from "../utils/UploadButton";
import { DeleteObjects } from "../utils/DeleteObjects";
import { CreateCase } from '../utils/CreateCase';
import { CreateFolder } from '../utils/CreateFolder';
import Breadcrumbs from "../utils/Breadcrumbs"
import { useCases, useShareCaseTo, useShareExternal } from '../../hooks/cases';
import { useCaseEvidence, useCreateEvidence } from '../../hooks/useCaseEvidence';
import CasesGrid from '../utils/CaseTable';
import ShareDialog from '../utils/ShareDialog';
import { MetadataDialog } from '../utils/MetadataDialog';
import { useCognitoUser } from '../../hooks/users';
import toast from 'react-hot-toast';
// import { ListObjectsV2Command } from "@aws-sdk/client-s3";
// import amplifyConfig from '../../../amplify_outputs.json';
import { createS3Client } from '../s3.service'
import { IconButton } from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import { resolveUniqueFilename } from '../utils/resolveUniqueFileName';
import { useLocation } from "react-router-dom";
import { useEvidence } from '../../hooks/useEvidence';
import { Case } from '../../api/cases/cases.types';
import { User } from '../../api/users/users.types';

// interface Users {
//     user_id: string,
//     email: string,
//     user_role: string,
//     user_name: string
// }

export const AdminCasesControl = () => {
  const [files, setFiles] = useState<any[]>([]);
  const [identityId, setIdentityId] = useState<string | null>(null);
  const [pathStack, setPathStack] = useState<string[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const [selectedRows, setSelectedRows] = useState<string[]>([]);
  // const [casesLoading, setCasesLoading] = useState(true);
  // const [filesLoading, setFilesLoading] = useState(false);

  const [droppedFile, setDroppedFile] = useState<File | null>(null);
  const [metaOpen, setMetaOpen] = useState(false);
  const { mutateAsync: shareExternal } = useShareExternal();
  // const { userInfo } = useUser()

  
  const currentPath = pathStack.slice(1).join('');
  console.log('currentPath: ', currentPath)
  console.log('pathStack: ', pathStack)
  const currentCaseNumber = 
    pathStack.length > 1 ? pathStack[1].replace('/', '') : null;

  // const { data: evidences, refetch: refetchEvidences, isLoading: loadingEvidence } = useEvidence((currentPath.split('/').slice(1)).join('/'))
  const { 
    data: evidences, 
    refetch: refetchEvidences, 
    isLoading: isEvidenceLoading,
    isFetching: isEvidenceFetching, 
  } = useEvidence(currentPath)

  console.log('eviiiiiiiiiiiiii: ', evidences)
  
  useEffect(() => {
    if(evidences)
      setFiles(evidences)
  }, [evidences])
  const {
    data: evidenceData,
    refetch: refetchEvidence,
  } = useCaseEvidence(currentCaseNumber ?? '');
  const { mutateAsync: createEvidence } = useCreateEvidence(currentCaseNumber ?? '');
  const currentFolderPrefix = identityId ? `private/${identityId}/${currentPath}` : null;
  const [isGeneratingLink, setIsGeneratingLink] = useState(false);
  const isRoot = pathStack.length === 1;
//   const viewMode = isRoot ?  "cases" : "files";
  
  const viewMode = pathStack.length === 0 ? 'users' : isRoot ? "cases" : "files";
  console.log('viewModeeeeeeeeeeeee: ', viewMode)
  const selectedFiles = [...selected].filter(p => !p.endsWith("/"));
  const selectedFolders = [...selected].filter(p => p.endsWith("/"));
const [currentUserId, setCurrentUserId] = useState<string>('')
  const [allCases, setAllCases] = useState<Case[]>([])
  const { data: cases, refetch: refetchCases, isLoading } = useCases(currentUserId);
  console.log('allllllllllllllllllllll: ', cases)
  useEffect(() => {
    if(cases)
    setAllCases(cases)
  }, [cases])
  console.log('casesxxxxxxxxxxxxxxx: ', cases)
  console.log('currentUserId: ', currentUserId)
  const { mutate: shareCaseTo } = useShareCaseTo();
  // const bucket_name = amplifyConfig.storage.bucket_name

  const s3Ref = useRef<any>(null);
  useEffect(() => {
    createS3Client().then(client => {
      s3Ref.current = client
    })
  }, []);

  const location = useLocation()
  const caseToOpenThroughLink = location.state?.case_number
  useEffect(() => {
    if(!caseToOpenThroughLink) return;
    const row = cases?.filter(item => item.case_number === `${caseToOpenThroughLink}`)
    if(row && row.length > 0){
      handleRowClick({row: row[0]})
    }
  }, [cases])

  // useEffect(() => {
  //   if (!isLoading) setCasesLoading(false)
  //   if (cases && cases?.length > 0) setCasesLoading(false)
  // }, [cases])
  const [azureUsers, setAzureUsers] = useState<User[]>([])
  const { 
    data: cognitoUsers, 
    refetch: refetchUsers, 
    isLoading: isUsersLoading,
    isFetching: isUsersFetching,
  } = useCognitoUser()
  console.log('cognitoUsers: ', cognitoUsers)
  useEffect(() => {
    if(cognitoUsers)
        setAzureUsers(cognitoUsers)
  }, [azureUsers, cognitoUsers])
  const filteredUsers = cognitoUsers?.filter(item => item.user_name != currentUserId)

  // const evidenceByKey = useMemo(() => {
  //   const map = new Map<string, any>();
  //   evidenceData?.items?.forEach(ev => {
  //     map.set(ev.source_key, ev);
  //     const filename = ev.source_key?.split('/').pop();
  //     if (filename) map.set(filename, ev);
  //   });
  //   return map;
  // }, [evidenceData]);
  const existingEvidenceNumbers = useMemo(() =>
    new Set<string>(
      evidenceData?.items?.map((ev: any) => ev.evidence_number).filter(Boolean)
    ),
  [evidenceData]);

  const rootFolderPrefix = identityId ? `private/${identityId}/` : null;
  const canGenerateLink =
    selectedFiles.length > 0 ||
    selectedFolders.length === 1 ||
    !!currentFolderPrefix ||
    !!rootFolderPrefix;

  useEffect(() => {
    async function init() {
      const session = await fetchAuthSession();
      setIdentityId(session.identityId ?? null);
    }
    init();
  }, []);
 
  // const loadFiles = useCallback(async () => {
  //   if (!identityId) return;
  //   setFiles([])
  //   setFilesLoading(true)

  //   try {
  //     const items = []
  //     const basePath = `private/${identityId}/${currentPath}`;
  //     const command = new ListObjectsV2Command({
  //       Bucket: bucket_name,
  //       Prefix: basePath,
  //       Delimiter: '/'
  //     });
  //     const response = await s3Ref.current.send(command);

  //     for (const item of response.CommonPrefixes || []) {
  //       items.push({ Key: item.Prefix, type: "folder" })
  //     }
  //     for (const item of response.Contents || []) {
  //       if (item.Key == basePath) continue
  //       items.push(item)
  //     }
  //     const mergedItems = items.map((item) => {
  //       if (item.type === "folder") return item;
  //       const fullKey = item.Key;
  //       const fileName = fullKey?.split("/").pop();
  //       const metadata =
  //         evidenceByKey.get(fullKey) ||
  //         evidenceByKey.get(fileName) ||
  //         null;
  //       return { ...item, ...metadata };
  //     });
  //     setFiles(mergedItems);
  //   } catch (err) {
  //     console.error('Error listing files', err);
  //   } finally {
  //     setFilesLoading(false);
  //   }
  // }, [identityId, currentPath, evidenceByKey]);

  // useEffect(() => {
  //   loadFiles();
  // }, [loadFiles]);
  
  function handleRowClick(params: any) {
    const row = params.row
    console.log('rowwwwwwwwww: ', row)
    // setFiles([]);
    // setFilesLoading(true);

    let name: string;
    if (viewMode === 'cases') {
      name = row.case_number
      setPathStack(prev => [...prev, `${name}/`]);
    } else if(viewMode === 'files') {
      name = row.name
      setPathStack(prev => [...prev, `${name}/`]);
    } else if(viewMode === 'users'){
        console.log('vvvvvvvvvvvvv: ', viewMode)
        setAzureUsers([])
        setCurrentUserId(row.id)
        name = row.name
        setPathStack(prev => [...prev, `${name}/`])
    }
    setSelected(new Set());
  }

  const [open, setOpen] = useState(false)
  // let users = cognitoUsers

  // useEffect(() => {
  //   users = cognitoUsers?.filter((item) => item.user_name !== currentUserId)
  //   console.log('userssssssssssssss: ', users)
  // }, [currentUserId])
  // console.log('currentUserIddddddddddddd: ', currentUserId)

  const extractCaseNumber = (path: string) => {
    const parts = path.split("/");
    return parts[parts.length - 2];
  };

  // useEffect(() => {
  //   if (viewMode === "files") {
  //     // setFiles([]);
  //     // setFilesLoading(true)
  //   }
  // }, [viewMode]);
  console.log('selectedRows: ', selectedRows)
  // const selectedSingleMeta =
  //   selectedRows.length === 1
  //     ? evidenceByKey.get(selectedRows[0]) ?? null
  //     : null;
  const users = filteredUsers
  const selectedSingleMeta = selectedRows.length === 1
      ? evidences?.filter((item) => item.file_name_path === selectedRows[0])[0] ?? null: null

  const handleSaveMetadata = async (metadata: {
    evidence_number: string;
    description: string;
  }) => {
    
    if (selectedRows.length !== 1) {
      toast.error('Select exactly one file to edit metadata.');
      return;
    }
    const key = selectedRows[0];
    await createEvidence({
      source_key: key,
      evidence_number: metadata.evidence_number,
      description: metadata.description,
      user_id: currentUserId
    });
    toast.success('Metadata saved');
    refetchEvidence();
    // loadFiles();
  };

  // Bind cases into the resolver so UploadButton just calls resolveFilename(name)
  const handleResolveFilename = (originalName: string) =>
    resolveUniqueFilename(originalName, currentPath);

  // Show toast if file was auto-renamed
  const handleUploaded = (uploadedName: string, originalName: string) => {
    if (uploadedName !== originalName) {
      toast(`"${originalName}" already exists — uploaded as "${uploadedName}"`, {
        icon: 'ℹ️',
        duration: 5000,
      });
    }
    // loadFiles();
    setDroppedFile(null);
    setTimeout(() => {
      refetchEvidences();
    }, 1000);
  };

  return (
    <>
      <Flex justifyContent="space-between" alignItems="center" padding="0.75rem 0">
        {/* <Heading level={5} style={{ margin: 0 }}>
          {viewMode == 'users'? `Users: ${cognitoUsers?.length}`: 'Files'}
        </Heading> */}
        
      <Flex alignItems="center" gap="0.5rem">
          <Heading level={5} style={{ margin: 0 }}>
            {viewMode === "users" ? "Users" : "Files"}
          </Heading>

          {viewMode === "users" && (
            <span
              style={{
                background: "#eef2ff",
                color: "#4338ca",
                padding: "2px 8px",
                borderRadius: "999px",
                fontSize: "0.75rem",
                fontWeight: 600,
              }}
            >
              {cognitoUsers?.length ?? 0}
            </span>
          )}
        </Flex>


        <Flex gap="0.5rem">
          {viewMode !== 'users' && isRoot && (
            <Button size='small' onClick={() => setOpen(true)} disabled={selectedRows.length === 0}>
              Share
            </Button>
          )}
          {open && (
            <ShareDialog
              open={open}
              users={users}
              selectedFiles={selectedRows}
              sharedTo={
                selectedRows.length === 1
                  ? cases?.find(
                    c => c.case_number === extractCaseNumber([...selectedRows][0])
                  )?.shared_to
                  : []
              }
              onClose={() => setOpen(false)}
              onShare={async (payload) => {
                try {
                  const now = new Date().toISOString();
                  if (payload.mode === 'internal' && payload.users) {
                    const items: any[] = [];
                    for (const file of payload.files) {
                      const caseNumber = extractCaseNumber(file);
                      const caseMeta = cases?.find(c => c.case_number === caseNumber);
                      if (!caseMeta) continue;
                      for (const user of payload.users) {
                        items.push({
                          receiver_user_id: `RECEIVER#${user.user_name}`,
                          case_number: `${caseNumber}`,

                          gsi1pk: `OWNER#${currentUserId}`,
                          gsi1sk: `CASE#${caseNumber}#RECEIVER#${user.user_name}`,
                          receiver_user: user.user_name,
                          receiver_email: user.email,
                          owner_user: currentUserId,

                          case_title: caseMeta.case_title,
                          jurisdiction: caseMeta.jurisdiction,
                          case_agents: caseMeta.case_agents,
                          source_key: caseMeta.source_key,
                          owner_email: caseMeta.email,
                          permissions: { read: user.read, write: user.write },
                          division: caseMeta.division,
                          unit: caseMeta.unit,
                          squad: caseMeta.squad,
                          shared_at: now
                        });
                      }
                    }
                    await shareCaseTo(items);
                    setOpen(false)
                  }
                  if (payload.mode === 'external' && payload.externalEmails) {
                    for (const file of payload.files) {
                      const caseNumber = extractCaseNumber(file);
                      const caseMeta = cases?.find(c => c.case_number === caseNumber);
                      if (!caseMeta) {
                        console.warn(`Case metadata not found for ${caseNumber}`);
                        continue;
                      }
                      const frontendUrl = window.location.origin;
                      const secureViewPath = `/secure-view?prefix=${encodeURIComponent(file)}`;
                      const wrappedUrl = `${frontendUrl}/external-login?redirect=${encodeURIComponent(secureViewPath)}`;
                      for (const ext of payload.externalEmails) {
                        await shareExternal({
                          case_number: caseNumber,
                          file,
                          email: ext.email,
                          wrapped_url: wrappedUrl,
                          case_title: caseMeta.case_title,
                          case_agents: caseMeta.case_agents,
                          jurisdiction: caseMeta.jurisdiction,
                          owner: currentUserId,
                          owner_email: caseMeta.email,
                          permissions: { read: true, write: false },
                          shared_at: now
                        });
                      }
                    }
                  }
                } catch (err) {
                  console.error("Share failed:", err);
                }
              }}
            />
          )}

          {viewMode !== 'users' && isRoot && (
            <Button
              size="small"
              variation="primary"
              isLoading={isGeneratingLink}
              loadingText="Generating link..."
              disabled={isGeneratingLink || !canGenerateLink}
              onClick={async () => {
                try {
                  const selectedArray = Array.from(selectedRows);
                  if (!selectedArray.length) return;
                  const fullPath = selectedArray[0];
                  const trimmedPath = fullPath.replace(/\/$/, "");
                  const parts = trimmedPath.split("/");
                  const case_number = parts[parts.length - 1];
                  const link = `${window.location.origin}/access/${case_number}`;
                  await navigator.clipboard.writeText(link);
                  toast.success("Link copied to clipboard!");
                } catch (err) {
                  console.error(err);
                } finally {
                  setIsGeneratingLink(false);
                }
              }}
            >
              Generate link
            </Button>
          )}
          {/* {viewMode === 'users'} */}

          {/* {!isRoot && ( */}
            <IconButton>
              <RefreshIcon onClick={() => {
                // loadFiles();
                if(viewMode === 'users'){
                  console.log('videModessss: ', viewMode)
                  refetchUsers()
                }
                else if(viewMode === 'cases'){
                  console.log('viewmode: ', viewMode)
                  refetchCases()
                }
                else if(viewMode == 'files'){
                  refetchEvidences()
                }
                // setTimeout(() => refetchEvidences(), 20);
              }} />
            </IconButton>
          {/* )} */}
          {/* {isRoot && (
            <IconButton>
              <RefreshIcon onClick={() => {
                refetchCases()
              }} />
            </IconButton>
          )} */}
          {viewMode !== 'users' && !isRoot && selectedRows.length === 1 && (
            <Button
              size="small"
              onClick={() => setMetaOpen(true)}
            >
              Edit Metadata
            </Button>
          )}

          {viewMode !== 'users' && isRoot ? (
            <CreateCase 
              basePath={`${currentPath}`} 
              owner_id={currentUserId ?? ''}
              />
          ) : viewMode !== 'users' && (
            <CreateFolder
              basePath={`${currentPath}`}
              onCreated={
                
                () => {
                  console.log('folder created')
                  // loadFiles()
                }
              
              }
            />
          )}
          {viewMode !== 'users' && <DeleteObjects
            selectedPaths={[...selectedRows]}
            currentCaseNumber={currentCaseNumber}
            selectedEvidenceItems={
              !isRoot
                ? selectedRows
                    .map(fp => evidences?.find(ev => ev.file_name_path === fp))
                    .filter(Boolean)
                    .map(ev => ({ case_number: ev!.case_number, file_name_path: ev!.file_name_path }))
                : undefined
            }
            onDeleted={
              () => {
                // loadFiles()
                console.log('object deleted')
              }
            }
          />}
          {viewMode !== 'users' && !isRoot && (
            <UploadButton
              prefix={`${currentUserId}/${currentPath}`}
              droppedFile={droppedFile}
              onClearDroppedFile={() => setDroppedFile(null)}
              resolveFilename={handleResolveFilename}
              onUploaded={handleUploaded}
              cases={cases ?? []}
              // owner_id={currentUserId ?? ''}
            />
          )}
        </Flex>
      </Flex>
      <Breadcrumbs
        pathStack={pathStack}
        onNavigate={(x: string[]) => {
          // setFiles([]);
          // setFilesLoading(true)
          setPathStack(x)
        }}
        onExitCase={() => {
          // setFiles([]);
          // setFilesLoading(true)
          setPathStack([]);
          setAllCases([])
          setCurrentUserId('')
        }}
      />
      <CasesGrid
        data={viewMode === "users" ? azureUsers : viewMode === "cases" ? allCases || [] : files || []}
        // loading={viewMode === "cases" ? isLoading : loadingEvidence}
        loading={
          viewMode === "users"
            ? isUsersLoading || isUsersFetching
            : viewMode === "cases"
            ? isLoading
            : isEvidenceLoading || isEvidenceFetching
        }
        handleRowClick={handleRowClick}
        viewMode={viewMode}
        handleSelected={(selected: any) => setSelectedRows(selected)}
        onFileDrop={(file) => setDroppedFile(file)}
        owner_id={currentUserId}
      />
      {metaOpen && selectedRows.length === 1 && (
        <MetadataDialog
          open={metaOpen}
          files={selectedRows}
          initialMetadata={selectedSingleMeta ?? undefined}
          caseNumber={currentCaseNumber ?? ''}
          existingEvidenceNumbers={existingEvidenceNumbers}
          onClose={() => setMetaOpen(false)}
          onSave={handleSaveMetadata}
        />
      )}
    </>
  );
};