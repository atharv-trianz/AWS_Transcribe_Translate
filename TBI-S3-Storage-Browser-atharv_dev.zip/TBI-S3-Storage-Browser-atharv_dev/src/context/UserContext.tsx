import { createContext, useContext } from 'react';
type UserInfo = {
  email: string;
  user_name: string;
  user_id: string;
  cognitoUsername: string;
  cognitoGroups: string[];
  customRoles: string[]
};

export interface UserContextType {
  userInfo: UserInfo
  signOut?: () => void
}

export const UserContext = createContext<UserContextType | null>(null);

export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within UserContext.Provider');
  }
  return context;
};
